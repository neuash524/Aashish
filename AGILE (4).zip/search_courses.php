<?php
// Start session securely
session_start();

// Database connection
$host = 'localhost';
$db = 'student_record_system';
$user = 'root';
$pass = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $searchResults = [];
    $courseNames = [];

    // Fetch all course names for datalist
    $stmt = $conn->query("SELECT name FROM course WHERE name IS NOT NULL AND name != ''");
    $courseNames = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Handle search
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['search'])) {
        $searchTerm = trim($_POST['search']);

        $stmt = $conn->prepare("SELECT * FROM course WHERE name LIKE :term OR description LIKE :term OR type LIKE :term");
        $stmt->execute(['term' => '%' . $searchTerm . '%']);
        $searchResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

} catch (PDOException $e) {
    echo "Database connection failed: " . $e->getMessage();
    die();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search Courses</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-image: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7)), url("img/build.jpg");
            background-color: #f4f4f4;
            padding: 40px;
            color: #333;
        }

        .container {
            max-width: 700px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
        }

        .search-form {
    display: flex;
    flex-direction: column;  /* stack vertically */
    align-items: center;     /* center horizontally */
    gap: 15px;               /* space between input and button */
    margin-bottom: 20px;
}

.search-input {
    width: 100%;       /* full width inside container */
    max-width: 500px;  /* limit max width */
    padding: 12px 15px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 8px;
    transition: border-color 0.3s ease;
}

.search-button {
    padding: 12px 25px;
    background-color: #007BFF;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    width: 150px;  /* fixed width for button */
}

        .search-button:hover {
            background-color: #0056b3;
        }

        .results {
            margin-top: 30px;
        }

        .course {
            padding: 15px;
            border-bottom: 1px solid #ccc;
        }

        .course:last-child {
            border-bottom: none;
        }

        .course-title {
            font-weight: bold;
            font-size: 18px;
        }

        .course-details {
            margin-top: 6px;
            color: #555;
        }

        .no-results {
            margin-top: 20px;
            color: red;
            text-align: center;
        }
         .back-btn {
      background: none;
      color: #333;
      border: none;
      font-weight: bold;
      cursor: pointer;
      text-decoration: underline;
      font-size: 14px;
      margin-top: 10px;
      
      
    }

    .back-btn:hover {
      text-decoration: none;
      background-color: #0056b3;
      color: white;
      border-radius: 6px;
      padding: 6px 12px;
      
    }
    .back-btn-container {
    text-align: center;
    margin-top: 20px; /* optional spacing */
}
 .header {
      width: 100%;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      position: absolute;
      top: 10px;
      left: 10px;
      z-index: 10;
    }

    .logo {
      height: 60px;
      width: auto;
    }

    </style>
</head>
<body>
    <div class="header">
  <img src="img/logoo.png" alt="School Logo" class="logo">
</div>

<div class="container">
    <h2>Search Courses</h2>

    <form method="POST" class="search-form">
        <input list="course-names" name="search" class="search-input" placeholder="Enter course name." required>
        <datalist id="course-names">
            <?php foreach ($courseNames as $course): ?>
                <option value="<?= htmlspecialchars($course['name']) ?>"></option>
            <?php endforeach; ?>
        </datalist>
        <button type="submit" class="search-button">Search</button>
    </form>

    <?php if (!empty($searchResults)): ?>
        <div class="results">
            <?php foreach ($searchResults as $course): ?>
                <div class="course">
                    <div class="course-title"><?= htmlspecialchars($course['name']) ?></div>
                    <div class="course-details">
                         Code: <?= htmlspecialchars($course['code']) ?><br>
                        Type: <?= htmlspecialchars($course['type']) ?><br>
                        Description: <?= htmlspecialchars($course['description']) ?><br>
                        Credits: <?= htmlspecialchars($course['credits']) ?><br>
                        
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php elseif ($_SERVER["REQUEST_METHOD"] === "POST"): ?>
        <p class="no-results">No courses found for your search.</p>
    <?php endif; ?>
</div>
<form action="student_dashboard.php" method="get" class="back-btn-container">
    <button type="submit" class="back-btn">⬅ Back to Student Dashboard</button>
</form>
</div>

</body>
</html>
