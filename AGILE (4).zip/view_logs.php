<?php
require_once 'db.php'; // This brings in $pdo

// Now you can use $pdo safely
$stmt = $pdo->query("SELECT * FROM activity_log ORDER BY activity_time DESC");
$logs = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head><title>Activity Logs</title></head>
<body>
<h1>Activity Log</h1>
<table border="1" cellpadding="5">
    <tr>
        <th>ID</th>
        <th>User ID</th>
        <th>Role</th>
        <th>Activity</th>
        <th>Details</th>
        <th>Time</th>
    </tr>
    <?php foreach ($logs as $log): ?>
    <tr>
        <td><?= htmlspecialchars($log['id']) ?></td>
        <td><?= htmlspecialchars($log['user_id']) ?></td>
        <td><?= htmlspecialchars($log['role']) ?></td>
        <td><?= htmlspecialchars($log['activity']) ?></td>
        <td><?= htmlspecialchars($log['details']) ?></td>
        <td><?= htmlspecialchars($log['activity_time']) ?></td>
    </tr>
    <?php endforeach; ?>
</table>
</body>
</html>
