
<?php
header('Content-Type: application/json');

require_once 'UserManager.php'; // Your class with updateUser() etc.
require_once 'functions.php';

try {
    $pdo = new PDO('mysql:host=localhost;dbname=student_record_system;charset=utf8', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'DB connection failed']);
    exit;
}

$userManager = new UserManager($pdo);

// Get POST data (assuming all fields sent via POST)
$data = $_POST;

if (empty($data['role'])) {
    echo json_encode(['success' => false, 'message' => 'Missing role']);
    exit;
}

$role = $data['role'];

try {
    $updated = $userManager->updateUser($role, $data);
    if ($updated) {
        echo json_encode(['success' => true, 'message' => ucfirst($role) . ' user updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Update failed or no changes made']);
    }
} catch (Exception $ex) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $ex->getMessage()]);
}
?>