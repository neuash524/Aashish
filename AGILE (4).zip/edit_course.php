<?php
include 'session.php';
include 'db.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin','Department Admin','Course Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();

// Fetch all courses
$coursesStmt = $pdo->query("SELECT code FROM course ORDER BY code");
$courses = $coursesStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch type
$typeStmt = $pdo->query("SELECT DISTINCT type FROM course ORDER BY type");
$types = $typeStmt->fetchAll(PDO::FETCH_ASSOC);

if (isset($_POST['edit'])) {
    $code = $_POST['code'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $type = $_POST['type'];
    $credits = $_POST['credits'];
    logActivity($pdo, $_SESSION['user_id'], 'admin', 'Updated course', "Course Name: $name, Code: $code");



    // Check if course exists
    $check = $pdo->prepare("SELECT 1 FROM course WHERE code = :code");
    $check->execute([':code' => $code]);

    if (!$check->fetch()) {
        $_SESSION['message'] = "<p style='color:red;font-size:1.5rem;'>Course code does not exist.</p>";
        header("Location: edit_course.php");
        exit();
    }

    //  Case-sensitive name duplication check
    $dupCheck = $pdo->prepare("SELECT 1 FROM course WHERE BINARY name = :name AND code != :code");
    $dupCheck->execute([':name' => $name, ':code' => $code]);
    if ($dupCheck->fetch()) {
        $_SESSION['message'] = "<p style='color:red;font-size:1.5rem;'>Course name already exists</p>";
        header("Location: edit_course.php");
        exit();
    }

    // Handle image upload
    $imagePath = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $targetDir = "img/";
        $imageName = basename($_FILES["image"]["name"]);
        $imagePath = $targetDir . $imageName;

        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }

        if (!move_uploaded_file($_FILES["image"]["tmp_name"], $imagePath)) {
            $_SESSION['message'] = "<p style='color:red;font-size:1.5rem;'>Failed to upload image.</p>";
            header("Location: edit_course.php");
            exit();
        }
    }

    try {
        if ($imagePath) {
            $stmt = $pdo->prepare("UPDATE course SET name = :name, image = :image, description = :description, type = :type, credits = :credits WHERE code = :code");
            $stmt->execute([
                ':name' => $name,
                ':image' => $imagePath,
                ':description' => $description,
                ':type' => $type,
                ':credits' => $credits,
                ':code' => $code
            ]);
        } else {
            $stmt = $pdo->prepare("UPDATE course SET name = :name, description = :description, type = :type, credits = :credits WHERE code = :code");
            $stmt->execute([
                ':name' => $name,
                ':description' => $description,
                ':type' => $type,
                ':credits' => $credits,
                ':code' => $code
            ]);
        }

        $_SESSION['message'] = "<p style='color:white;font-size:1.5rem;'>Course updated successfully.</p>";
    } catch (PDOException $e) {
        $_SESSION['message'] = "<p style='color:red;font-size:1.5rem;'>Error editing course: " . $e->getMessage() . "</p>";
    }

    header("Location: edit_course.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Course</title>
    <link rel="stylesheet" href="homepage.css">
    <link href="img/logoo.png" rel="icon" type="image/webp">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="Navigation.js" defer></script>
    <style>
        /* your existing CSS remains unchanged */
        .container { max-width: 500px; width: 90%; margin: auto; background-color: rgba(255, 255, 255, 0.95); padding: 25px; border-radius: 12px; box-shadow: 0 6px 10px rgba(0, 0, 0, 0.1); color: #003366; }
        .container h2 { text-align: center; font-size: 2rem; margin-bottom: 20px; }
        form label { display: flex; flex-direction: column; font-weight: bold; color: #003366; gap: 10px; }
        input, select, button, textarea { padding: 12px; font-size: 1rem; border-radius: 6px; border: 1px solid #ccc; width: 100%; box-sizing: border-box; }
        button { background-color: #003366; color: white; border: none; font-weight: bold; cursor: pointer; transition: background-color 0.3s ease; }
        button:hover { background-color: #001f4d; }
        .message { text-align: center; font-weight: bold; padding: 10px; border-radius: 6px; margin: 20px auto; width: 90%; max-width: 800px; }
        .message.success { background-color: #28a745; color: white; }
        .message.error { background-color: #dc3545; color: white; }
        .back-btn { display: inline-block; padding: 12px 24px; background: blue; color: white; text-decoration: none; font-weight: bold; border-radius: 6px; transition: background 0.3s ease, transform 0.2s ease; box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4); border: 1px solid rgba(255, 255, 255, 0.3); }
        .back-btn:hover { background: blue; transform: translateY(-2px); box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7); }
        @media (max-width: 768px) {
            .container { padding: 20px 15px; }
            .container h2 { font-size: 1.5rem; }
            input, button { font-size: 0.95rem; padding: 10px; }
            nav img { width: 100px; height: 100px; }
            .nav-links { width: 160px; }
            .message { font-size: 1rem; }
        }

        
    </style>
</head>
<body>
<section class="header">  
    <nav>
        <img src="img/logoo.png" alt="Logo" class="logo">
        <div class="nav-links" id="navLinks">
            <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i>
            <ul>
                <li><a href="homepage.php">HOME</a></li>
                <li><a href="courses.php">COURSE</a></li>
                <li><a href="staff.php">STAFF</a></li>
                <li><a href="login.php">LOG IN</a></li>
            </ul>
        </div>
        <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i>
    </nav>

    <?php
    if (isset($_SESSION['message'])) {
        echo $_SESSION['message'];
        unset($_SESSION['message']);
    }
    ?>

    <div class="container">
        <h2>Edit Course</h2>
        <form method="POST" enctype="multipart/form-data" onsubmit="return confirmEdit();">

            <label>Course:
                <select name="code" id="courseCode" required onchange="loadCourseDetails()">
                    <option value="">-- Select Course Code--</option>
                    <?php foreach ($courses as $course): ?>
                        <option value="<?= htmlspecialchars($course['code']) ?>">
                            <?= htmlspecialchars($course['code']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label><br>

            <label>New Name: <textarea name="name" id="courseName" required></textarea></label><br>
            <label>New Image: <input type="file" name="image" id="imageInput"></label><br>

            <label>New Description: <textarea name="description" id="courseDesc" required></textarea></label><br>

            <label>Type:
                <select name="type" id="courseType" required>
                    <option value="">-- Select Type --</option>
                    <?php foreach ($types as $type): ?>
                        <option value="<?= htmlspecialchars($type['type']) ?>">
                            <?= htmlspecialchars($type['type']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label><br>

            <label>Credits: <input name="credits" id="courseCredits" type="text" required></label><br>
            <button name="edit">Edit Course</button><br><br>
        </form>

        <div style="display: flex; justify-content:center">
            <a href="course_dashboard.php" class="back-btn">Back</a>
        </div>
    </div>
</section>

<script>
function openMenu() {
    document.getElementById("navLinks").style.right = "0";
}
function closeMenu() {
    document.getElementById("navLinks").style.right = "-200px";
}
</script>
<script>
//  Fetch course details to prefill
function loadCourseDetails() {
    const code = document.getElementById('courseCode').value;
    if (!code) return;

    fetch('get_course_details.php?code=' + encodeURIComponent(code))
        .then(response => response.json())
        .then(data => {
            if (data) {
                document.getElementById('courseName').value = data.name;
                document.getElementById('courseDesc').value = data.description;
                document.getElementById('courseType').value = data.type;
                document.getElementById('courseCredits').value = data.credits;
            }
        })
        .catch(err => console.error('Error fetching course details:', err));
}
</script>
<script>
function confirmEdit() {
    return confirm("Are you sure you want to save the updates to this course?");
}
</script>



</body>
</html>
