<?php
include 'db.php';
session_start();

$student = null;
$student_id = $_SESSION['user_id'] ?? null;

$success = '';
$error = '';

// Fetch teachers for dropdown
$teacher_stmt = $pdo->query("SELECT teacher_id, name FROM teacher");
$teachers = $teacher_stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch codes for dropdown
$code_stmt = $pdo->query("SELECT DISTINCT code FROM course WHERE code IS NOT NULL AND code != ''");
$codes = $code_stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $code = $_POST['code'] ?? '';
  $teacher_id = $_POST['teacher_id'] ?? '';

  if (isset($_FILES['assignment']) && $_FILES['assignment']['error'] === 0) {
    $file = $_FILES['assignment'];
    $fileName = basename($file['name']);
    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));  // get file extension

    // Allow only pdf files
    if ($fileExt !== 'pdf') {
        $error = "❌ Only PDF files are allowed!";
    } else {
        $uploadDir = 'uploads/';
        $filePath = $uploadDir . time() . '_' . $fileName;

        if (!is_dir($uploadDir)) {
          mkdir($uploadDir, 0777, true);
        }

        if (move_uploaded_file($file['tmp_name'], $filePath)) {
          $stmt = $pdo->prepare("INSERT INTO submitted_assignments (student_id, file_name, file_path, code, teacher_id, uploaded_at) VALUES (?, ?, ?, ?, ?, NOW())");
          $stmt->execute([$student_id, $fileName, $filePath, $code, $teacher_id]);
          $success = "✅ Assignment uploaded successfully!";
        } else {
          $error = "❌ Failed to move uploaded file.";
        }
    }
  } else {
    $error = "❌ No file uploaded or upload error.";
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Submit Assignment</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Segoe UI', sans-serif;
      background-image: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7)), url("img/build.jpg");
      background-size: cover;
      background-position: center;
      color: #fff;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 30px 20px;
    }
    h2 {
      font-size: 42px;
      margin-bottom: 20px;
      text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.3);
      text-align: center;
    }
    .form-container {
      background: rgba(255, 255, 255, 0.95);
      color: #333;
      padding: 30px 40px;
      border-radius: 20px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
      max-width: 600px;
      width: 100%;
    }
    label {
      display: block;
      margin: 15px 0 5px;
      font-weight: bold;
      color: #540026;
    }
    input[type="file"],
    select {
      width: 100%;
      padding: 10px;
      border-radius: 8px;
      border: 1px solid #ccc;
      margin-bottom: 10px;
    }
    button {
      background-color: #0056b3;
      color: white;
      font-size: 16px;
      padding: 12px 24px;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      font-weight: bold;
      transition: background-color 0.3s ease, transform 0.2s ease;
      width: 100%;
      margin-top: 10px;
    }
    .message {
      margin: 15px 0;
      font-weight: bold;
      text-align: center;
    }
    .success { color: green; }
    .error { color: red; }

    @media (max-width: 768px) {
      h2 { font-size: 28px; }
      .form-container { padding: 20px; }
    }

    .back-btn {
      background: none;
      color: #333;
      border: none;
      font-weight: bold;
      cursor: pointer;
      text-decoration: underline;
      font-size: 14px;
      margin-top: 10px;
      padding: 8px 12px;
      border-radius: 6px;
      transition: background-color 0.3s ease, color 0.3s ease;
    }

    .back-btn:hover {
      background-color: #0056b3;
      color: white;
      text-decoration: none;
    }
  </style>
</head>
<body>

  <h2>Submit Assignment</h2>

  <div class="form-container">
    <?php if ($success): ?>
      <p class="message success"><?= htmlspecialchars($success) ?></p>
    <?php elseif ($error): ?>
      <p class="message error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" id="assignmentForm">
      <label for="assignment">Assignment File (PDF only):</label>
      <input type="file" name="assignment" id="assignment" accept=".pdf" required>

      <label for="code">Select Code:</label>
      <select name="code" id="code" required>
        <option value="">-- Choose Code --</option>
        <?php foreach ($codes as $row): ?>
          <option value="<?= htmlspecialchars($row['code']) ?>"><?= htmlspecialchars($row['code']) ?></option>
        <?php endforeach; ?>
      </select>

      <label for="teacher_id">Select Teacher:</label>
      <select name="teacher_id" id="teacher_id" required>
        <option value="">-- Choose Teacher --</option>
        <?php foreach ($teachers as $teacher): ?>
          <option value="<?= $teacher['teacher_id'] ?>"><?= htmlspecialchars($teacher['name']) ?> (ID: <?= $teacher['teacher_id'] ?>)</option>
        <?php endforeach; ?>
      </select>

      <button type="submit">Upload Assignment</button>
    </form>

    <form action="student_dashboard.php" method="get">
      <button type="submit" class="back-btn">⬅ Back to Student Dashboard</button>
    </form>
  </div>

  <script>
    document.getElementById('assignment').addEventListener('change', function() {
      const allowedExt = ['pdf'];
      const fileName = this.value.toLowerCase();
      const extension = fileName.split('.').pop();

      if (!allowedExt.includes(extension)) {
        alert('Only PDF files are allowed!');
        this.value = ''; // Clear the input
      }
    });
  </script>

</body>
</html>
