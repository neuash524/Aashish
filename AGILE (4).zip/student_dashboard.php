<?php
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
require 'db.php'; 

checkSessionTimeout();

// Allow both admin and student
if (!in_array($_SESSION['user_type'], ['admin', 'student'])) {
    header('Location: unauthorized.php');
    exit();
}

$userName = 'Guest';

if ($_SESSION['user_type'] === 'student') {
    $stmt = $pdo->prepare("SELECT user_name FROM student WHERE student_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        $userName = $user['user_name'];
    }
} elseif ($_SESSION['user_type'] === 'admin') {
    $stmt = $pdo->prepare("SELECT user_name FROM admin WHERE admin_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        $userName = $user['user_name'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Student Dashboard</title>
  <link rel="stylesheet" href="edit_teacher.css">
  <style>
    .header {
      display: flex;
      align-items: center;
      padding: 20px;
      background: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .logo {
      height: 60px;
      width: auto;
      margin-right: 20px;
    }

    .system-title {
      font-size: 20px;
      font-weight: bold;
      color: #4a148c;
    }

    body {
      font-family: 'Inter', sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f9fafb;
      color: #333;
    }

    .dashboard-container {
      padding: 40px 20px;
      max-width: 1200px;
      margin: auto;
      text-align: center;
    }

    .dashboard-container h1 {
      font-size: 32px;
      margin-bottom: 40px;
      color: #333;
    }

    .box-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
      gap: 30px;
    }

    .box {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      background: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
      border: 1px solid rgba(255, 255, 255, 0.3);
      border-radius: 12px;
      padding: 40px;
      box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
      color: white;
      transition: box-shadow 0.3s ease, transform 0.3s ease;
      min-height: 200px;
      font-size: 18px;
    }

    .box:hover {
      box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
      transform: translateY(-5px);
    }

    .box h2 {
      color: white;
      font-size: 26px;
      text-shadow: 0 0 8px rgba(255, 255, 255, 0.7);
    }

    .box p {
      color: white;
      margin-top: 10px;
      font-size: 15px;
      text-shadow: none;
    }

    .box-btn {
      display: inline-block;
      padding: 10px 18px;
      background-color: rgba(255, 255, 255, 0.25);
      color: white;
      text-decoration: none;
      font-weight: bold;
      border-radius: 6px;
      transition: background-color 0.3s ease;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    .box-btn:hover {
      background-color: rgba(255, 255, 255, 0.4);
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }

    .box-link {
      text-decoration: none;
      color: inherit;
      display: block;
    }

    /* Back button styles */
    .back-btn {
      display: inline-block;
      margin-top: 40px;
      padding: 12px 24px;
      background: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
      color: white;
      text-decoration: none;
      font-weight: bold;
      border-radius: 6px;
      transition: background 0.3s ease, transform 0.2s ease;
      box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
      border: 1px solid rgba(255, 255, 255, 0.3);
      cursor: pointer;
    }

    .back-btn:hover {
      background: linear-gradient(rgba(200, 45, 211, 0.9), rgba(68, 175, 109, 0.9));
      transform: translateY(-2px);
    }
  </style>
</head>
<body>

<div class="header">
  <img src="img/logoo.png" alt="School Logo" class="logo">
  <div class="system-title"><strong>Welcome to Greenfield! <?= htmlspecialchars($userName) ?> !!🎓</strong></div>
</div>

<div class="dashboard-container">
  <div class="box-grid">
    <a href="enroll.php" class="box-link">
      <div class="box">
        <h2>Student Enrollment</h2>
        <p>Register for new course</p>
      </div>
    </a>

    <a href="student_view.php" class="box-link">
      <div class="box">
        <h2>View Profile</h2>
        <p>See your personal profile information</p>
      </div>
    </a>

    <a href="edit_student.php" class="box-link">
      <div class="box">
        <h2>Edit Profile</h2>
        <p>Update your profile information</p>
      </div>
    </a>

    <a href="submit_assignment.php" class="box-link">
      <div class="box">
        <h2>Submit Assignment</h2>
        <p>Upload assignment</p>
      </div>
    </a>

    <a href="delete_assignment.php" class="box-link">
      <div class="box">
        <h2>Delete Assignment</h2>
        <p>Remove uploaded assignments</p>
      </div>
    </a>
  </div>

  <!-- Back to Dashboard Button -->
  <a href="all_users.php" class="back-btn">Back</a>
</div>

</body>
</html>
