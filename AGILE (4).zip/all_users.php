<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="userstyle.css"><!-- Link to the user CSS -->
    <title>Document</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
       body {
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9fafb;
            color: #333;
        }

        .dashboard-container {
  padding: 40px 20px;
  max-width: 1200px;
  margin: auto;
  text-align: center;
}

.dashboard-container h1 {
  font-size: 32px;
  margin-bottom: 40px;
  color: #333;
}

.box-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 30px;
}

.box {
  background: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  border-radius: 12px;
  padding: 25px;
  box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
  color: white;
  transition: box-shadow 0.3s ease, transform 0.3s ease;
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.box:hover {
  box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
  transform: translateY(-5px);
}

.box h2 {
  color:rgb(0, 0, 0);
  font-size: 22px;
  margin-bottom: 10px;
}

.box p {
  color:rgb(0, 0, 0);
  font-size: 15px;
  margin-bottom: 20px;
}

.box-btn {
  display: inline-block;
  padding: 10px 18px;
  background-color: rgba(255, 255, 255, 0.25);
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background-color 0.3s ease;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.box-btn:hover {
  background-color: rgba(255, 255, 255, 0.45);
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.logout-footer {
  width: 100%;
  text-align: center;
  padding: 20px 0;
  position: relative;
  bottom: 0;
}

.logout-btn {
  display: inline-block;
  padding: 12px 24px;
  background: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background 0.3s ease, transform 0.2s ease;
  box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.logout-btn:hover {
  background: linear-gradient(rgba(200, 45, 211, 0.9), rgba(68, 175, 109, 0.9));
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
}




</style>
</head>
<body>

<div class="header">
        <img src="img/logoo.png" alt="School Logo" class="logo">
        <div class="system-title"><strong>Welcome to Greenfield!</strong></div>
</div>
<div class="dashboard-container">
  
  <!-- Main Content -->
  <main class="main-content">
    <h1>All Users</h1>
    <div class="box-grid">

    <!--<div class="boxes-container" style="display: flex; gap: 20px; flex-wrap: wrap; justify-content: center;">-->

  <div class="box">
    <div class="icon" style="font-size: 48px; margin-bottom: 10px;">🛠️</div>
    <h2>Admin</h2>
    <p>Manage users, system settings, and oversee platform operations.</p>
    <a href="user_management.php" class="box-btn">Go to Admin</a>
  </div>

  <div class="box">
    <div class="icon" style="font-size: 48px; margin-bottom: 10px;">📚</div>
    <h2>Teacher</h2>
    <p>Access your profile, manage classes, and review student progress.</p>
    <a href="view_teacher_dashboard.php" class="box-btn">Go to Teacher</a>
  </div>

  <div class="box">
    <div class="icon" style="font-size: 48px; margin-bottom: 10px;">🎓</div>
    <h2>Student</h2>
    <p>View your dashboard, track progress, and access course materials.</p>
    <a href="student_dashboard.php" class="box-btn">Go to Student</a>
  </div>
</div>

  <!-- Course Management section BELOW the grid -->
<div class="course-section" style="margin-top: 50px; text-align: center;">
  <h1>Course Management</h1>
  <div style="display: flex; justify-content: center; margin-top: 20px;">
    <div class="box" style="max-width: 300px;">
      <div class="icon" style="font-size: 48px; margin-bottom: 10px;">🗂️</div>
      <h2>Course Management</h2>
      <p>Create, update, and manage courses and related academic content.</p>
      <a href="course_dashboard.php" class="box-btn">Go to Course Management</a>
    </div>
  </div>
</div>


</main>

</div>

<footer class="logout-footer">
  <a href="logout.php" class="logout-btn">Logout</a>
</footer>





<script>
function searchUsers(event) {
    if (event.key === "Enter") {
        const query = document.getElementById("searchInput").value;
        window.location.href = 'search_user.php?query=' + encodeURIComponent(query);
    }
}
</script>

</body>
</html>
