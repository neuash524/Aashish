<?php
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
require 'db.php'; 

checkSessionTimeout();

// Allow both admin and teacher
if (!in_array($_SESSION['user_type'], ['admin', 'teacher'])) {
    header('Location: unauthorized.html');
    exit();
}

$userName = 'Guest';

if ($_SESSION['user_type'] === 'teacher') {
    $stmt = $pdo->prepare("SELECT user_name FROM teacher WHERE teacher_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        $userName = $user['user_name'];
    }
} elseif ($_SESSION['user_type'] === 'admin') {
    $stmt = $pdo->prepare("SELECT user_name FROM admin WHERE admin_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        $userName = $user['user_name'];
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Teacher Dashboard</title>
  <link rel="stylesheet" href="edit_teacher.css">
  <style>

.header {
  display: flex;
  align-items: center;
  padding: 20px;
  background-color:linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.logo {
  height: 60px;
  width: auto;
  margin-right: 20px;
}

.system-title {
  font-size: 20px;
  font-weight: bold;
  color: #4a148c; /* Deep purple */
}


body {
  font-family: 'Inter', sans-serif;
  margin: 0;
  padding: 0;
  background-color: #f9fafb;
  color: #333;
}

.dashboard-container {
  padding: 40px 20px;
  max-width: 1200px;
  margin: auto;
  text-align: center;
}

.dashboard-container h1 {
  font-size: 32px;
  margin-bottom: 40px;
  color: #333;
}

.box-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 30px;
}

.box {
  display: flex;
  flex-direction: column;
  justify-content: center;  /* Vertical centering */
  align-items: center;      /* Horizontal centering */
  text-align: center; 
  background: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  border: 1px solid rgba(255, 255, 255, 0.3);;
  border-radius: 12px;
  padding: 25px;
  color: white; 
  transition: box-shadow 0.3s ease, transform 0.3s ease;
  min-height: 200px;
  padding: 40px;
  font-size: 18px;
}

.box:hover {
  
  transform: translateY(-5px);
}

.box h2 {
  color: white;
  font-size: 26px;
  text-shadow: 0 0 8px rgba(255, 255, 255, 0.7);
}


.box p {
  color: white;
  margin-top: 10px;
  font-size: 15px;
  text-shadow: none; /* Remove glow */
}


.box-btn {
  display: inline-block;
  padding: 10px 18px;
  background-color: rgba(255, 255, 255, 0.25);
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background-color 0.3s ease;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.box-btn:hover {
  background-color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.box-link {
  text-decoration: none;
  color: inherit;
  display: block;
}

.logout-footer {
  width: 100%;
  text-align: center;
  padding: 20px 0;
  position: relative;
  bottom: 0;
}

.logout-btn {
  display: inline-block;
  padding: 12px 24px;
  background: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background 0.3s ease, transform 0.2s ease;
  box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.logout-btn:hover {
  background: linear-gradient(rgba(200, 45, 211, 0.9), rgba(68, 175, 109, 0.9));
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
}

.back-btn {
  display: inline-block;
  padding: 12px 24px;
  background: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background 0.3s ease, transform 0.2s ease;
  box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.3);

}

.back-btn:hover {
  background: linear-gradient(rgba(200, 45, 211, 0.9), rgba(68, 175, 109, 0.9));
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
}

</style>
</head>
<body>

<div class="header">
  <img src="img/logoo.png" alt="School Logo" class="logo">
  <div class="system-title"><strong>Welcome to Greenfield! <?= $userName ?> !!👩‍🏫</strong></div>
</div>

<div class="dashboard-container">
  <div class="box-grid">
  <a href="view_teacher_profile.php" class="box-link">
    <div class="box">
      <h2>View Profile</h2>
      <p>See your personal profile details</p>
    </div>
  </a>

  <a href="edit_teacher.php" class="box-link">
    <div class="box">
      <h2>Edit Profile</h2>
      <p>Update your profile information</p>

    </div>
  </a>

  <a href="delete_teacher.php" class="box-link">
    <div class="box">
      <h2>Delete Profile</h2>
      <p>Remove your profile from the system</p>
    </div>
  </a>

  <a href="view_teacher_classes.php" class="box-link">
    <div class="box">
      <h2>View Assigned Courses</h2>
      <p>Check courses you're responsible for</p>
    </div>
  </a>

  <a href="search_students.php" class="box-link">
    <div class="box">
      <h2>Search Students</h2>
      <p>Find students by name or ID</p>
    </div>
  </a>

</div>



<div class="logout-footer">
  <a href="all_users.php" class="back-btn">Go Back</a>

  <a href="logout.php" class="logout-btn">Logout</a>
</div>
</body>
</html>
