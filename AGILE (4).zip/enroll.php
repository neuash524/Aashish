<?php
$host = 'localhost';
$db = 'student_record_system';
$user = 'root';
$pass = '';

$success_message = '';
$error_message = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch only active course codes
    $code_stmt = $conn->query("SELECT DISTINCT code FROM course WHERE code IS NOT NULL AND code != '' AND is_active = 1");
    $codes = $code_stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $student_id = $_POST['student_id'];
        $code = $_POST['code'];

        // Validate student exists
        $check = $conn->prepare("SELECT * FROM student WHERE student_id = ?");
        $check->execute([$student_id]);

        if ($check->rowCount() > 0) {
            // Validate course is active
            $course_check = $conn->prepare("SELECT * FROM course WHERE code = ? AND is_active = 1");
            $course_check->execute([$code]);

            if ($course_check->rowCount() > 0) {
                // Insert into enroll table
                $stmt = $conn->prepare("INSERT INTO enroll (student_id, code) VALUES (?, ?)");
                if ($stmt->execute([$student_id, $code])) {
                    $success_message = "✅ Enrollment successful!";
                } else {
                    $error_message = "❌ Database error while enrolling.";
                }
            } else {
                $error_message = "❌ Selected course is not active.";
            }
        } else {
            $error_message = "❌ Student ID not found in database.";
        }
    }

} catch (PDOException $e) {
    $error_message = "❌ Connection failed: " . $e->getMessage();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Enroll in Course</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', sans-serif;
      background-image: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7)), url("img/build.jpg");
      background-size: cover;
      background-position: center;
      color: #fff;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 80px 20px;
    }

    .container {
      background: rgba(255, 255, 255, 0.95);
      color: #333;
      padding: 40px 30px;
      border-radius: 16px;
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
      max-width: 500px;
      width: 100%;
      text-align: center;
    }

    h2 {
      font-size: 32px;
      margin-bottom: 25px;
    }

    label {
      display: block;
      margin-bottom: 8px;
      font-weight: bold;
      text-align: left;
    }

    input, select, button {
      width: 100%;
      padding: 12px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 16px;
    }

    button {
      background-color: #0056b3;
      color: white;
      font-weight: bold;
      border: none;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    button:hover {
      background-color: #00408a;
    }

    .message {
      font-weight: bold;
      margin-bottom: 20px;
    }

    .success { color: green; }
    .error { color: red; }

    .back-btn {
      background: none;
      color: #333;
      border: none;
      font-weight: bold;
      cursor: pointer;
      text-decoration: underline;
      font-size: 14px;
      margin-top: 10px;
    }

    .back-btn:hover {
      text-decoration: none;
      background-color: #0056b3;
      color: white;
      border-radius: 6px;
      padding: 6px 12px;
    }

    .header {
      width: 100%;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      position: absolute;
      top: 10px;
      left: 10px;
      z-index: 10;
    }

    .logo {
      height: 60px;
      width: auto;
    }
  </style>
</head>
<body>

<div class="header">
  <img src="img/logoo.png" alt="School Logo" class="logo">
</div>

<div class="container">
  <h2>Enroll in Course</h2>

  <?php if ($success_message): ?>
    <div class="message success"><?= htmlspecialchars($success_message) ?></div>
  <?php endif; ?>

  <?php if ($error_message): ?>
    <div class="message error"><?= htmlspecialchars($error_message) ?></div>
  <?php endif; ?>

  <form method="POST" action="">
    <label for="student_id">Student ID:</label>
    <input type="number" name="student_id" id="student_id" required>

    <label for="code">Select Course Code:</label>
    <select name="code" id="code" required>
      <option value="">-- Choose Course Code --</option>
      <?php foreach ($codes as $row): ?>
        <option value="<?= htmlspecialchars($row['code']) ?>"><?= htmlspecialchars($row['code']) ?></option>
      <?php endforeach; ?>
    </select>

    <button type="submit">Enroll</button>
  </form>

  <form action="student_dashboard.php" method="get">
    <button type="submit" class="back-btn">⬅ Back to Student Dashboard</button>
  </form>
</div>

</body>
</html>
