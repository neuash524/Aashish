<?php 
require 'authentication_middleware.php';
require 'authorization_middleware.php';

allowOnlyUserType('teacher'); // Only teachers can access

require_once 'db.php';
$teacher = null;
$teacher_id = $_SESSION['user_id'] ?? null; // set in authenticate.php

// Only try to fetch teacher data if user is identified
if ($teacher_id) {
$stmt = $pdo->prepare("SELECT * FROM teacher WHERE teacher_id = ?");
$stmt->execute([$teacher_id]);
$teacher = $stmt->fetch();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $qualification = $_POST['qualification'];
    $code = $_POST['code'];
    $photoName = $teacher['photo']; 
    $description = $_POST['description'];


if (!empty($_FILES['photo']['name'])) {
    $targetDir = 'img/';
    $uploadedFile = $_FILES['photo']['name'];
    $tempPath = $_FILES['photo']['tmp_name'];

    $extension = pathinfo($uploadedFile, PATHINFO_EXTENSION);
    $newFileName = 'teacher_' . $teacher_id . '_' . time() . '.' . $extension;
    $destination = $targetDir . $newFileName;

    if (move_uploaded_file($tempPath, $destination)) {
        $photoName = $newFileName;
    }
}

    

    $stmt = $pdo->prepare("UPDATE teacher SET name=?, email=?, qualification=?, code=?, photo=?, description=? WHERE teacher_id=?");
    $stmt->execute([$name, $email, $qualification, $code, $photoName, $description, $teacher_id]);

    $_SESSION['update_success'] = true;
    header("Location: edit_teacher.php");
    exit;
   }
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Edit Teacher</title>
   <link rel="stylesheet" href="edit_teacher.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
   <link rel="icon" href="img/logoo.png" type="image/webp">
   <script src="Navigation.js" defer></script>
</head>
<body>

<!-- Header and Nav -->
<section class="header">
   <nav>
      <img src="img/logoo.png" alt="Logo" class="logo">
      <div class="nav-links" id="navLinks">
         <i class="fas fa-times" onclick="closeMenu()"></i>
         <ul>
            <li><a href="homepage.php">HOME</a></li>
            <li><a href="dashboard.php">COURSE</a></li>
            <li><a href="staff.php">STAFF</a></li>
            <li><a href="login.php">LOG IN</a></li>
         </ul>
      </div>
      <i class="fas fa-bars" onclick="openMenu()"></i>
   </nav>

   <div class="text-box">
      <h1>Edit Your Profile</h1>
   </div>
</section>

<!-- Main Content -->
<section class="mission" style="color: white;">
<?php if ($teacher): ?>
<?php if (!empty($_SESSION['update_success'])): ?>
    <div style="background-color: #d4edda; color: #155724; padding: 1rem; margin-bottom: 1rem; border: 1px solid #c3e6cb; border-radius: 5px; text-align: center;">
        ✅ Profile successfully updated.
    </div>
    <?php unset($_SESSION['update_success']); ?>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data" onsubmit="return confirmUpdate();" style="max-width: 500px; margin: auto; background-color: rgba(0,0,0,0.5); padding: 2rem; border-radius: 10px; color:white;">
    <label>Name:</label><br>
    <input type="text" name="name" value="<?= htmlspecialchars($teacher['name']) ?>" required><br><br>

    <label>Email:</label><br>
    <input type="email" name="email" value="<?= htmlspecialchars($teacher['email']) ?>" required><br><br>

    <label>Qualification:</label><br>
    <input type="text" name="qualification" value="<?= htmlspecialchars($teacher['qualification']) ?>"><br><br>

    <label>Upload Photo:</label><br>
    <input type="file" name="photo" accept="img/*"><br><br>

    <label>Description:</label><br>
    <textarea name="description" rows="4" style="width: 100%; border-radius: 5px; padding: 10px;"><?= htmlspecialchars($teacher['description'] ?? '') ?></textarea><br><br>

    <label>Subject ID:</label><br>
    <input type="text" list="course-list" name="code" required value="<?= htmlspecialchars($teacher['code']) ?>" style="width: 100%; padding: 10px; border-radius: 5px; border: 1px solid #ccc;">

    <datalist id="course-list">
    <?php
    $courses = $pdo->query("SELECT code FROM course")->fetchAll();
    foreach ($courses as $course) {
        echo "<option value=\"{$course['code']}\"></option>";
    }
    ?>
    </datalist>
<br><br>
    <button class="middle-btn" type="submit">Update</button>
    <a class="back-btn" href="view_teacher_dashboard.php" >← Go Back</a>
</form>
<?php else: ?>
    <p>Something went wrong. Please try again.</p>
<?php endif; ?>
</section>


<!-- JS for Nav -->
 <script>
function openMenu() {
    document.getElementById("navLinks").style.right = "0";
}

function closeMenu() {
    document.getElementById("navLinks").style.right = "-100%";
}

// Confirm before submitting the form
function confirmUpdate() {
    return confirm("Are you sure you want to update your profile details?");
}
</script>


</body>
</html>