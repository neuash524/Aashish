<?php
session_start();
include 'db.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin','Course Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();

$showConfirmation = false;
$material = null;

// Step 1: If user clicked delete, fetch material for confirmation
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("SELECT * FROM course_materials WHERE id = ?");
    $stmt->execute([$id]);
    $material = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($material) {
        $showConfirmation = true;
    } else {
        $_SESSION['message'] = "<p class='message error'>Invalid material ID.</p>";
        header("Location: delete_materials.php");
        exit;
    }
}

// Step 2: If user confirms delete via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    $id = $_POST['material_id'] ?? null;

    $stmt = $pdo->prepare("SELECT file_path FROM course_materials WHERE id = ?");
    $stmt->execute([$id]);
    $file = $stmt->fetchColumn();

    if (!$file) {
        $_SESSION['message'] = "<p class='message error'>Material not found.</p>";
        header("Location: delete_materials.php");
        exit;
    }

    if ($file && file_exists($file)) {
        @unlink($file);
    }

    $stmt = $pdo->prepare("DELETE FROM course_materials WHERE id = ?");
    $stmt->execute([$id]);

    $_SESSION['message'] = "<p class='message success'>Material deleted successfully.</p>";
    header("Location: delete_materials.php");
    exit;
}

$materials = $pdo->query("SELECT * FROM course_materials ORDER BY uploaded_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Materials</title>
    <link rel="stylesheet" href="homepage.css">
    <link href="img/logoo.png" rel="icon" type="image/webp">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="Navigation.js" defer></script>
    <style>
        h2 {
            text-align: center;
            font-size: 2rem;
            margin-bottom: 30px;
        }

        .message {
            text-align: center;
            font-weight: bold;
            padding: 10px;
            border-radius: 6px;
            margin: 20px auto;
            width: 90%;
            max-width: 800px;
        }

        .message.success {
            background-color: #28a745;
            color: white;
        }

        .message.error {
            background-color: #dc3545;
            color: white;
        }

        .back-btn {
            display: inline-block;
            padding: 12px 24px;
            background: blue;
            color: white;
            text-decoration: none;
            font-weight: bold;
            border-radius: 6px;
            transition: background 0.3s ease, transform 0.2s ease;
            box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .back-btn:hover {
            background: darkblue;
            transform: translateY(-2px);
        }

        table {
            width: 80%;
            border-collapse: collapse;
            margin: auto;
            background-color: white;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #003366;
            color: white;
        }

        a.delete {
            background-color: red;
            color: white;
            padding: 10px 20px;
            font-weight: bold;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        a.delete:hover {
            background-color:pink;
        }
a.view{
            background-color: blue;
            color: white;
            padding: 10px 20px;
            font-weight: bold;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        a.view:hover {
            background-color:violet;
        }
        
        .confirmation {
    width: 90%;
    max-width: 600px;
    background-color: rgba(255, 255, 255, 0.95);
    margin: 60px auto;
    padding: 20px 25px;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
    color: #003366;
        }
        .confirmation p{
          color:black;
          font-size:1rem;  
        }

        .materials-details {
            list-style: none;
            padding: 0;
            margin: 20px auto;
            max-width: 600px;
            font-size: 1.1rem;
        }

        .materials-details li {
            margin-bottom: 10px;
        }

        .buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-top: 20px;
        }

        .confirm-btn {
            background-color: red;
            color: white;
            padding: 10px 20px;
            font-weight: bold;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        .confirm-btn:hover{
            background-color: blue;
        }

        .cancel-btn {
            background-color: gray;
            color: white;
            padding: 10px 20px;
            font-weight: bold;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        .cancel-btn:hover{
           background-color: blue;
        }
        


        @media (max-width: 768px) {
            .container {
                padding: 20px 15px;
            }

            .container h2 {
                font-size: 1.5rem;
            }

            .message {
                font-size: 1rem;
            }

            .nav-links {
                width: 160px;
            }
        }
    </style>
</head>
<body>
<section class="header">
    <nav>
        <img src="img/logoo.png" alt="Logo" class="logo">
        <div class="nav-links" id="navLinks">
            <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i>
            <ul>
                <li><a href="homepage.php">HOME</a></li>
                <li><a href="courses.php">COURSE</a></li>
                <li><a href="staff.php">STAFF</a></li>
                <li><a href="login.php">LOG IN</a></li>
            </ul>
        </div>
        <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i>
    </nav>

    <?php
    if (isset($_SESSION['message'])) {
        echo $_SESSION['message'];
        unset($_SESSION['message']);
    }
    ?>

    <?php if ($showConfirmation && $material): ?>
        <div class="confirmation">
            <h2>Confirm Deletion</h2>
            <p>Are you sure you want to delete this material? This action cannot be undone.</p>
            <ul class="materials-details">
                <li><strong>ID:</strong> <?= htmlspecialchars($material['id']) ?></li>
                <li><strong>Teacher ID:</strong> <?= htmlspecialchars($material['teacher_id']) ?></li>
                <li><strong>Course Code:</strong> <?= htmlspecialchars($material['code']) ?></li>
                <li><strong>File Name:</strong> <?= htmlspecialchars($material['file_name']) ?></li>
                <li><strong>Uploaded At:</strong> <?= htmlspecialchars($material['uploaded_at']) ?></li>
            </ul>
            <form method="POST">
                <input type="hidden" name="material_id" value="<?= $material['id'] ?>">
                <div class="buttons">
                    <button type="submit" name="confirm_delete" class="confirm-btn">Yes, Delete</button>
                    <a href="delete_materials.php"><button type="button" class="cancel-btn">Cancel</button></a>
                </div>
            </form>
        </div>
    <?php else: ?>
        <div class="container">
            <h2>Uploaded Materials</h2>
            <table>
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Teacher ID</th>
                    <th>Course Code</th>
                    <th>File Name</th>
                    <th>Uploaded At</th>
                    <th>View</th>
                    <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                <?php if ($materials): ?>
                    <?php foreach ($materials as $material): ?>
                        <tr>
                            <td><?= $material['id'] ?></td>
                            <td><?= htmlspecialchars($material['teacher_id']) ?></td>
                            <td><?= htmlspecialchars($material['code']) ?></td>
                            <td><?= htmlspecialchars($material['file_name']) ?></td>
                            <td><?= $material['uploaded_at'] ?></td>
                            <td><a href="view_materials.php?id=<?= $material['id'] ?>" class= "view">View</a></td>
                            <td><a href="#" class="delete" onclick="confirmInitialDelete(<?= $material['id'] ?>)">Delete</a></td>

                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="7">No materials uploaded yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table><br>
            <div style="display: flex; justify-content:center">
                <a href="course_dashboard.php" class="back-btn">Back</a>
            </div>
        </div>
    <?php endif; ?>
</section>
<script>
function confirmInitialDelete(id) {
    const confirmDelete = confirm("Are you sure you want to delete?");
    if (confirmDelete) {
        window.location.href = "delete_materials.php?delete=" + id;
    } else {
        // Do nothing or stay on current page
    }
}
</script>

<script>
    var navLinks = document.getElementById("navLinks");
    function openMenu() {
        navLinks.style.right = "0";
    }
    function closeMenu() {
        navLinks.style.right = "-200px";
    }
</script>
</body>
</html>
