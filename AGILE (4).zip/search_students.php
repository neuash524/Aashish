<?php
/*require 'authentication_middleware.php';
require 'authorization_middleware.php';
allowOnlyUserType('teacher','admin');*/

require_once 'db.php';

$searchResults = [];
$searchTerm = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $searchTerm = trim($_POST['search']);
    $stmt = $pdo->prepare("SELECT student_id, name, email FROM student WHERE student_id LIKE ? OR name LIKE ?");
    $stmt->execute(["%$searchTerm%", "%$searchTerm%"]);
    $searchResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $title; ?></title> <!-- Display page title -->
  <link rel="stylesheet" href="edit_teacher.css">
  <link href="img/logoo.png" rel="icon" type="image/webp"> <!-- Set favicon for the page -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome icons -->
  <script src="Navigation.js" defer></script> <!-- External JavaScript for navigation -->
  <title>Search Students</title>
  <style>
    .search-container {
  max-width: 700px;
  margin: 40px auto;
  padding: 30px;
  border-radius: 12px;
  background-color: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(8px);
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
  text-align: center;
}

.search-heading {
  font-size: 28px;
  color: #fff;
  margin-bottom: 20px;
}

.search-form input[type="text"] {
  width: 70%;
  padding: 12px;
  border-radius: 6px;
  border: none;
  margin-bottom: 15px;
  font-size: 16px;
}

.search-form input[type="submit"] {
  padding: 12px 20px;
  border: none;
  background-color: #00c6ff;
  color: #fff;
  border-radius: 6px;
  cursor: pointer;
  font-weight: bold;
  transition: background 0.3s;
}

.search-form input[type="submit"]:hover {
  background-color: #0072ff;
}

.search-results {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
  color: #fff;
}

.search-results th,
.search-results td {
  border: 1px solid #ddd;
  padding: 12px;
  background-color: rgba(0, 0, 0, 0.3);
}

.search-results th {
  background-color: rgba(0, 0, 0, 0.6);
}

.no-results {
  color: #f8d7da;
  background: rgba(220, 53, 69, 0.2);
  padding: 10px;
  margin-top: 20px;
  border-radius: 6px;
}

div[style*="suggestionBox"] {
  font-family: inherit;
  background-color: rgba(255, 255, 255, 0.95) !important;
  border-radius: 8px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.2);
}

div[style*="suggestionBox"] div {
  padding: 10px;
  transition: background 0.2s ease;
}

div[style*="suggestionBox"] div:hover {
  background-color: #f0f0f0;
}

</style>

</head>
<body>

 
    <nav>
      <img src="img/logoo.png" alt="Logo" class="logo"> <!-- Display the university logo -->
   
      <div class="nav-links" id="navLinks">
         <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i> <!-- Close menu icon -->
         <ul>
            <li><a href="homepage.php">HOME</a></li> <!-- Home link -->
            <li><a href="dashboard.php">COURSE</a></li> <!-- Contact link -->
            <li><a href="staff.php">STAFF</a></li> <!-- About link -->
            <li><a href="login.php">LOG IN</a></li> <!-- Administrator link -->
         </ul>
      </div>
      <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i> <!-- Open menu icon -->
    </nav>
<div class="searh_container">
  <h2 class="search-heading">Search Students</h2>

  <form class="search-form" method="POST" action="">
    <div style="position: relative; display: inline-block; width: 70%;">
    <input type="text" name="search" placeholder="Enter Student ID or Name" value="<?= htmlspecialchars($searchTerm) ?>" autocomplete="off" required>
</div>
    <input type="submit" value="Search">
  </form>

  <?php if (!empty($searchResults)): ?>
    <table>
      <tr>
        <th>Student ID</th>
        <th>Name</th>
        <th>Email</th>
      </tr>
      <?php foreach ($searchResults as $student): ?>
        <tr>
          <td><?= htmlspecialchars($student['student_id']) ?></td>
          <td><?= htmlspecialchars($student['name']) ?></td>
          <td><?= htmlspecialchars($student['email']) ?></td>
        </tr>
      <?php endforeach; ?>
    </table>
  <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
    <p>No students found for "<strong><?= htmlspecialchars($searchTerm) ?></strong>".</p>
  <?php endif; ?>

<a class="back-btn" href="view_teacher_dashboard.php">← Go Back</a>
  </div>
  <script>
document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.querySelector('input[name="search"]');
  const wrapper = searchInput.parentElement; // the div wrapping input
  const suggestionBox = document.createElement("div");
  suggestionBox.style.position = "absolute";
  suggestionBox.style.top = "100%"; // place right below input
  suggestionBox.style.left = "0";
  suggestionBox.style.right = "0";
  suggestionBox.style.background = "#fff";
  suggestionBox.style.border = "1px solid #ccc";
  suggestionBox.style.maxHeight = "200px";
  suggestionBox.style.overflowY = "auto";
  suggestionBox.style.zIndex = "1000";
  suggestionBox.style.display = "none";
  wrapper.appendChild(suggestionBox);

  searchInput.addEventListener("input", () => {
    const query = searchInput.value.trim();
    if (query.length < 1) {
      suggestionBox.style.display = "none";
      return;
    }

    fetch(`suggest_students.php?term=${encodeURIComponent(query)}`)
      .then(res => res.json())
      .then(data => {
        suggestionBox.innerHTML = '';
        if (data.length > 0) {
          data.forEach(student => {
            const item = document.createElement("div");
            item.textContent = `${student.name} (${student.student_id})`;
            item.style.padding = "10px";
            item.style.cursor = "pointer";
            item.addEventListener("click", () => {
              searchInput.value = student.student_id; // Set to ID for full lookup
              suggestionBox.style.display = "none";
              searchInput.form.submit();
            });
            suggestionBox.appendChild(item);
          });
          suggestionBox.style.display = "block";
        } else {
          suggestionBox.style.display = "none";
        }
      });
  });

  document.addEventListener("click", (e) => {
    if (!wrapper.contains(e.target)) {
      suggestionBox.style.display = "none";
    }
  });
});


</script>

</body>
</html>
