<?php
include 'session.php';
/*include 'db.php';

if (isset($_GET['code'])) {
    $stmt = $pdo->prepare("SELECT name, description, type, credits, image FROM course WHERE code = :code");
    $stmt->execute([':code' => $_GET['code']]);
    echo json_encode($stmt->fetch(PDO::FETCH_ASSOC));
}*/
include 'db.php';
header('Content-Type: application/json');

if (!isset($_GET['code']) || empty(trim($_GET['code']))) {
    echo json_encode(['success' => false, 'message' => 'No course code provided.']);
    exit;
}

$code = $_GET['code'];

$stmt = $pdo->prepare("
    SELECT code, name AS name, description, type, teacher_id, credits
    FROM course
    WHERE code = ?
");
$stmt->execute([$code]);
$course = $stmt->fetch(PDO::FETCH_ASSOC);

if ($course) {
    echo json_encode(array_merge(['success' => true], $course));
} else {
    echo json_encode(['success' => false, 'message' => 'Course not found.']);
}

