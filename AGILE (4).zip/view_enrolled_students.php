<?php
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();
require_once 'db.php';

// Fetch enrolled students with course codes from enroll table
$stmt = $pdo->prepare("
    SELECT 
        e.enroll_id,
        s.student_id,
        s.name AS student_name,
        s.email,
        s.class,
        e.code AS course_code
    FROM enroll e
    JOIN student s ON e.student_id = s.student_id
    ORDER BY s.name ASC
");
$stmt->execute();
$enrollments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Enrolled Students</title>
<style>
   * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Segoe UI', sans-serif;
  background-image: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7)), url("img/build.jpg");
  background-size: cover;
  background-position: center;
  color: #fff;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 80px 20px;
}

h1 {
  text-align: center;
  margin-bottom: 30px;
}

table {
  width: 80%;
  border-collapse: collapse;
  margin: auto;
  background-color: white;
  color: #000;
}

th, td {
  border: 1px solid #ddd;
  padding: 12px;
  text-align: center;
}

th {
  background-color: #276129;
  color: white;
}

tr:nth-child(even) {
  background-color: #f1f1f1;
}

.back-btn {
  display: block;
  max-width: 150px;
  margin: 30px auto 0;
  padding: 10px 15px;
  background-color: #2e7d32;
  color: white;
  text-align: center;
  text-decoration: none;
  font-weight: bold;
  border-radius: 8px;
}

.back-btn:hover {
  background-color: #276129;
}

.header {
  width: 100%;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  position: absolute;
  top: 10px;
  left: 10px;
  z-index: 10;
}

.logo {
  height: 60px;
  width: auto;
}

</style>
</head>
<body>
  <div class="header">
  <img src="img/logoo.png" alt="School Logo" class="logo">
</div>

<h1>Enrolled Students</h1>

<?php if (count($enrollments) === 0): ?>
  <p style="text-align:center;">No students are enrolled in any courses yet.</p>
<?php else: ?>
  <table>
    <thead>
      <tr>
        <th>Enrollment ID</th>
        <th>Student Name</th>
        <th>Email</th>
        <th>Class</th>
        <th>Course Code</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($enrollments as $enrollment): ?>
        <tr>
          <td><?= htmlspecialchars($enrollment['enroll_id']) ?></td>
          <td><?= htmlspecialchars($enrollment['student_name']) ?></td>
          <td><?= htmlspecialchars($enrollment['email']) ?></td>
          <td><?= htmlspecialchars($enrollment['class']) ?></td>
          <td><?= htmlspecialchars($enrollment['course_code']) ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>

<a href="course_dashboard.php" class="back-btn">⬅ Back to Dashboard</a>

</body>
</html>
