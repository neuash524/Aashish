<?php

require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin','Department Admin','Course Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();

?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Course Management</title> <!-- Display page title -->
   <link rel="stylesheet" href="homepage.css"> <!-- Link to the homepage CSS -->
   <link href="img/logoo.png" rel="icon" type="image/webp"> <!-- Set favicon for the page -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome icons -->
   <script src="Navigation.js" defer></script> <!-- External JavaScript for navigation -->
</head>
<style>
.header h1,
.header .support {
  margin: 0;
}

.support p {
  margin: 5px 0;
  font-weight: normal;
}

h1 {
  text-align: center;
  font-size: 2.5rem;
  margin-bottom: 20px;
  color: #4B0082;
}

div{
  color: black;
}


.features {
  max-width: 1000px;
  margin: auto;
  padding: 0;
  background: linear-gradient(
    135deg,
    rgba(200, 45, 211, 0.7),
    rgba(68, 175, 109, 0.7)
  );
  border-radius: 12px;
  padding: 5px 5px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
}


.features h2 {
  margin-bottom: 20px;
  color: white}

.grid {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center; /* optional: center align */
}



.logout-footer {
  width: 100%;
  text-align: center;
  padding: 20px 0;
  position: relative;
  bottom: 0;
}

.logout-btn {
  display: inline-block;
  padding: 12px 24px;
  background: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background 0.3s ease, transform 0.2s ease;
  box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.logout-btn:hover {
  background: linear-gradient(rgba(200, 45, 211, 0.9), rgba(68, 175, 109, 0.9));
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
}

.back-btn {
  display: inline-block;
  padding: 12px 24px;
  background: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background 0.3s ease, transform 0.2s ease;
  box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.3);

}

.back-btn:hover {
  background: linear-gradient(rgba(200, 45, 211, 0.9), rgba(68, 175, 109, 0.9));
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
}

/* Responsive cards */
.card {
  flex: 0 0 300px; /* fixed width for each card */
  max-width: 100%;
  background: linear-gradient(
    135deg,
    rgba(200, 45, 211, 0.7),
    rgba(68, 175, 109, 0.7)
  );
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  transition: 0.2s;
  text-decoration: none;
  color: white; /* Adjust for contrast against gradient */
  box-sizing: border-box;
}


.card:hover {
  transform: translateY(-3px);
  box-shadow: 0 6px 12px rgba(0,0,0,0.2);
}


.card-icon {
  font-size: 30px;
  margin-bottom: 10px;
  color: #ff6600;
}

.card-title {
  font-weight: bold;
  margin-bottom: 5px;
  color: black;
}

/* Tablet view: 2 columns */
@media (max-width: 992px) {
  .card {
    flex: 1 1 calc(50% - 20px);
  }
}

/* Mobile view: 1 column */
@media (max-width: 450px) {
  .card {
    flex: 1 1 100%;
  }

  h1 {
    font-size: 2rem;
  }

  .features {
    padding: 0 10px;
  }

  .card-icon {
    font-size: 26px;
  }
}


</style>
</head>
<body>

   <section class="header">  
   <nav>
      <img src="img/logoo.png" alt="Logo" class="logo"> <!-- Display the university logo -->
       <p style="font-size:3.5rem;"> Department- Arts & Media </p>
      <div class="nav-links" id="navLinks">
         <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i> <!-- Close menu icon -->
         <ul>
            <li><a href="homepage.php">HOME</a></li> <!-- Home link -->
            <li><a href="courses.php">COURSE</a></li> <!-- Contact link -->
            <li><a href="about.php">STAFF</a></li> <!-- About link -->
            <li><a href="login.php">LOG IN</a></li> <!-- Administrator link -->
         </ul>
      </div>
      <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i> <!-- Open menu icon -->
   </nav>
 
  <h1>Course Management System </h1>
  <div class="features">
<h2>Your Features</h2>
<div class="grid">
 
      <a class="card" href="add_course.php">
<div class="card-icon">📅</div>
<div class="card-title">Add Course</div>
<div>Add new course</div>
</a>

       <a class="card" href="delete_course.php">
<div class="card-icon">📅</div>
<div class="card-title">Delete Course</div>
<div>Delete course</div>
</a>

      <a class="card" href="edit_course.php">
<div class="card-icon">📤</div>
<div class="card-title">Edit Course </div>
<div>Keep course up-to-date </div>
</a>

      <a class="card" href="view_course.php">
<div class="card-icon">💬</div>
<div class="card-title">Course List</div>
<div>Get information about course</div>
</a>

      <a class="card" href="search_course.php">
<div class="card-icon">📅</div>
<div class="card-title">Search Course</div>
<div>Search particular course</div>
</a>

      <a class="card" href="filter_course.php">
<div class="card-icon">📅</div>
<div class="card-title">Filter Course</div>
<div>Filter courses based on Type/Availibilty </div>
</a>


      <a class="card" href="add_materials.php">
<div class="card-icon">🎭</div>
<div class="card-title">Add Course Materials</div>
<div>Add course materials </div>
</a>

      <a class="card" href="delete_materials.php">
<div class="card-icon">🎭</div>
<div class="card-title">View/Delete Course Materials</div>
<div>View /delete course materials </div>
</a>


      <a class="card" href="manage_teacher.php">
<div class="card-icon">📊</div>
<div class="card-title">Manage Teacher</div>
<div>Add/Delete teacher to particular course</div>
</a>

     <a class="card" href="status.php">
<div class="card-icon">📅</div>
<div class="card-title">Status</div>
<div>Active/Inactive</div>
</a>


<a class="card" href="approve_courses.php">
<div class="card-icon">✅</div>
<div class="card-title">Approve Course</div>
<div>Approve new course</div>
</a>

<a class="card" href="view_enrolled_students.php">
<div class="card-icon">💬</div>
<div class="card-title">Students</div>
<div>View all enrolled students</div>
</a>

<a class="card" href="view_submitted_assignments.php">
<div class="card-icon">✅</div>
<div class="card-title">Assignments</div>
<div>View all submitted assignments</div>
</a>
</div>


<footer class="logout-footer">
  <a href="all_users.php" class="back-btn">Go Back</a>

  <a href="logout.php" class="logout-btn">Logout</a>
</footer>
</section>

   <!-- JavaScript for toggling the menu visibility -->
   <script>
      var navLinks = document.getElementById("navLinks");
      function openMenu() {
         navLinks.style.right = "0"; // Open the menu by setting the style to right = 0
      }
      function closeMenu() {
         navLinks.style.right = "-200px"; // Close the menu by shifting it off-screen
      }
   </script>

</body>

</html>

  