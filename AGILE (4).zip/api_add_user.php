<?php
// api_add_user.php
header('Content-Type: application/json');

// Setup PDO connection
try {
    $pdo = new PDO('mysql:host=localhost;dbname=student_record_system;charset=utf8mb4', 'root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'DB connection failed: ' . $e->getMessage()]);
    exit;
}

require 'UserManager.php';
require 'functions.php';

try {
    $userManager = new UserManager($pdo);
    $response = $userManager->addUser($_POST, $_FILES);
    echo json_encode($response);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
