<?php
// view_material.php
include 'db.php';



if (!isset($_GET['id'])) {
    echo "No material selected.";
    exit;
}

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM course_materials WHERE id = ?");
$stmt->execute([$id]);
$material = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$material) {
    echo "Material not found.";
    exit;
}

$filepath = htmlspecialchars($material['file_path']);
$filename = htmlspecialchars($material['file_name']);
$ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>View Materials</title> <!-- Display page title -->
   <link rel="stylesheet" href="homepage.css"> <!-- Link to the homepage CSS -->
   <link href="img/logoo.png" rel="icon" type="image/webp"> <!-- Set favicon for the page -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome icons -->
   <script src="Navigation.js" defer></script> <!-- External JavaScript for navigation -->
</head>
    <style>
        body {

            text-align: center;
        }
        .back-btn {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background-color:rgb(29, 147, 210);
            color: white;
            text-decoration: none;
            border-radius: 6px;
            justify-content:left;
        }
        iframe,img, video {
            width: 80%;
            height: 80vh;
            margin: auto;
            
        }

        .download {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background-color: #003366;
            color: white;
            text-decoration: none;
            border-radius: 6px;

            text-align:right;
        }
    </style>
</head>
<body>

<section class="header">  
    <nav>
      <img src="img/logoo.png" alt="Logo" class="logo"> <!-- Display the university logo -->
   
      <div class="nav-links" id="navLinks">
         <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i> <!-- Close menu icon -->
         <ul>
            <li><a href="homepage.php">HOME</a></li> <!-- Home link -->
            <li><a href="courses.php">COURSE</a></li> <!-- Contact link -->
            <li><a href="staff.php">STAFF</a></li> <!-- About link -->
            <li><a href="login.php">LOG IN</a></li> <!-- Administrator link -->
         </ul>
      </div>
      <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i> <!-- Open menu icon -->
    </nav>


    <a class="back-btn" href="delete_materials.php">&larr; Back </a>
    
    <h2><?= $filename ?></h2>

    <?php if (in_array($ext, ['pdf' ])): ?>
        <iframe src="<?= $filepath ?>"></iframe>
       

    <?php elseif (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])): ?>
        <img src="<?= $filepath ?>" alt="<?= $filename ?>">

    <?php elseif (in_array($ext, ['mp4', 'webm'])): ?>
        <video controls>
            <source src="<?= $filepath ?>" type="video/<?= $ext ?>">
            Your browser does not support the video tag.
        </video>

    <?php else: ?>
        <p style="font-size:2rem;">Preview not available for this file type.</p>
    <?php endif; ?>

    <a class="download" href="<?= $filepath ?>" download>⬇ Download File</a>

</section>
<!-- JavaScript for toggling the menu visibility -->
   <script>
      var navLinks = document.getElementById("navLinks");
      function openMenu() {
         navLinks.style.right = "0"; // Open the menu by setting the style to right = 0
      }
      function closeMenu() {
         navLinks.style.right = "-200px"; // Close the menu by shifting it off-screen
      }
   </script>


</body>
</html>
