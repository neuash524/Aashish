<?php
session_start();
require 'db.php'; // Assumes $pdo is defined here
require 'functions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_name = $_POST['user_name'] ?? '';
    $password = $_POST['password'] ?? '';

    if (!$user_name || !$password) {
        die("Username and password are required.");
    }

    // These are your user types (table names)
    $user_types = ['student', 'teacher', 'admin'];

    foreach ($user_types as $user_type) {
    $stmt = $pdo->prepare("SELECT * FROM $user_type WHERE user_name = ?");
    $stmt->execute([$user_name]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        if (password_verify($password, $user['hash_password'])) {
            // Set session variables:
            $_SESSION['user_id'] = $user[$user_type . '_id']; // e.g., admin_id
            $_SESSION['user_name'] = $user['user_name'];
            $_SESSION['user_type'] = $user_type;
            $_SESSION['role'] = $user['role'];
            $_SESSION['last_activity'] = time();

            // OTP setup
            $_SESSION['otp'] = (string) random_int(100000, 999999);
            $_SESSION['otp_expires'] = time() + 300;
            logActivity($pdo, $_SESSION['user_id'], $_SESSION['user_type'], 'Logged in');

            // Optional: update last login for admins
        if ($user_type === 'admin') {
            $update = $pdo->prepare("UPDATE admin SET last_login = NOW() WHERE admin_id = ?");
            $update->execute([$_SESSION['user_id']]);
        }

            header("Location: verify_otp.php");
            exit;
        } else {
            echo "Invalid credentials (wrong password)";
            exit;
        }
    }
}
}
