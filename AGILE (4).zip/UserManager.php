<?php

class UserManager {
    private $pdo;
    private $validRoles = ['admin', 'teacher', 'student'];
    private $allowedRoles = ['admin', 'teacher', 'student'];
    private $allowedStatuses = ['pending', 'approved', 'rejected'];

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function addUser(array $data, array $files = []): array {
        $response = ['success' => false, 'message' => '', 'popup' => null];

        // Extract and validate shared fields
        $name = trim($data['name'] ?? '');
        $email = trim($data['email'] ?? '');
        $role = $data['role'] ?? '';

        /*if (!preg_match("/^[a-zA-Z' -]{2,30}$/", $name)) {
            throw new Exception("Invalid name format.");
        }*/
        $email = filter_var($email, FILTER_VALIDATE_EMAIL);
        if (!$email || !$role || !$name) {
            throw new Exception("Missing required fields.");
        }

        // Check if email exists
        $existing = getExistingUserByEmail($this->pdo, $email);
        if ($existing) {
            $user = $existing['user'];
            $table = $existing['table'];
            $idKey = $table . '_id';
            $userId = $user[$idKey];

            $response['popup'] = [
                'message' => "Email already in use: $email",
                'links' => [
                    'update' => "update_user.php?role=$table&{$idKey}={$userId}",
                    'cancel' => "add_user.php"
                ]
            ];
            return $response;
        }

        // Generate login credentials
        $username = generateUsername($name, $role, $this->pdo);
        $password = generatePassword();
        $hash_password = password_hash($password, PASSWORD_DEFAULT);

        // Role-based inserts
        if ($role === 'admin') {
            $stmt = $this->pdo->prepare("INSERT INTO admin (name, email, contact, role, user_name, hash_password) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $name,
                $email,
                trim($data['admin_contact'] ?? ''),
                trim($data['admin_role'] ?? ''),
                $username,
                $hash_password
            ]);
            logActivity($this->pdo, $this->pdo->lastInsertId(), 'admin', 'Created admin user', "Name: $name");

        } elseif ($role === 'teacher') {
            // Validate
            if (isset($data['qualification']) && !isValidQualification($data['qualification'])) {
                throw new Exception("Invalid qualification.");
            }

            if (isset($data['code']) && !isValidCode($data['code'])) {
                throw new Exception("Invalid code.");
            }

            // Photo handling
            $photo = null;
            if (!empty($files['photo']['tmp_name'])) {
                $photo = $this->handlePhotoUpload($files['photo']);
            }

            $admin_id = $this->getAdminIdByRole('Teacher Admin');

            $stmt = $this->pdo->prepare("INSERT INTO teacher (name, email, qualification, photo, description, user_name, hash_password, admin_id, code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $name,
                $email,
                trim($data['qualification'] ?? ''),
                $photo,
                trim($data['description'] ?? ''),
                $username,
                $hash_password,
                $admin_id,
                trim($data['code'] ?? null)
            ]);
            logActivity($this->pdo, $this->pdo->lastInsertId(), 'teacher', 'Created teacher user', "Name: $name");

        } elseif ($role === 'student') {
            if (isset($data['class']) && !isValidClass($data['class'])) {
                throw new Exception("Invalid class.");
            }

            $admin_id = $this->getAdminIdByRole('Student Admin');
            $stmt = $this->pdo->prepare("INSERT INTO student (name, email, class, is_on_scholarship, user_name, hash_password, admin_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $name,
                $email,
                trim($data['class'] ?? ''),
                isset($data['is_on_scholarship']) ? 1 : 0,
                $username,
                $hash_password,
                $admin_id
            ]);
            logActivity($this->pdo, $this->pdo->lastInsertId(), 'student', 'Created student user', "Name: $name");

        } else {
            throw new Exception("Invalid role.");
        }

        $response['success'] = true;
        $response['message'] = "User added successfully!";
        $response['credentials'] = compact('username', 'password');
        return $response;
    }

    private function getAdminIdByRole(string $role): int {
        $stmt = $this->pdo->prepare("SELECT admin_id FROM admin WHERE role = ? LIMIT 1");
        $stmt->execute([$role]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$admin) throw new Exception("No admin found for role: $role");
        return (int)$admin['admin_id'];
    }

    private function handlePhotoUpload(array $file): ?string {
        $uploadDir = 'uploads/photos/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $safeName = preg_replace('/[^a-zA-Z0-9_\.-]/', '_', $file['name']);
        $target = $uploadDir . time() . '_' . $safeName;

        if (move_uploaded_file($file['tmp_name'], $target)) {
            return $target;
        }
        throw new Exception("Photo upload failed.");
    }


    // Fetch user by role and id
    public function getUserById(string $role, int $id): ?array {
        $table = $this->getTableNameByRole($role);
        if (!$table) return null;

        $idField = $role . '_id';
        $stmt = $this->pdo->prepare("SELECT * FROM $table WHERE $idField = ?");
        $stmt->execute([$id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        return $user ?: null;
    }

    // Update user by role and POST data; returns true on success
    public function updateUser(string $role, array $data): bool {
        // Validate input data before update
        if (!$this->validateUserData($role, $data)) {
            return false; // Or throw exception for validation errors
        }

        switch ($role) {
            case 'admin':
                $stmt = $this->pdo->prepare("UPDATE admin SET name=?, email=?, role=?, contact=?, status=?, user_name=? WHERE admin_id=?");
                $stmt->execute([
                    $data['name'], $data['email'], $data['role'], $data['contact'] ?? null,
                    $data['status'], $data['user_name'], $data['admin_id']
                ]);
                break;

            case 'teacher':
                $stmt = $this->pdo->prepare("UPDATE teacher SET name=?, email=?, qualification=?, photo=?, description=?, code=?, user_name=?, status=?, admin_id=? WHERE teacher_id=?");
                $stmt->execute([
                    $data['name'], $data['email'], $data['qualification'] ?? null,
                    $data['photo'] ?? null, $data['description'] ?? null,
                    $data['code'] ?? null, $data['user_name'], $data['status'],
                    $data['admin_id'], $data['teacher_id']
                ]);
                break;

            case 'student':
                $stmt = $this->pdo->prepare("UPDATE student SET name=?, email=?, class=?, is_on_scholarship=?, user_name=?, status=?, admin_id=? WHERE student_id=?");
                $stmt->execute([
                    $data['name'], $data['email'], $data['class'] ?? null,
                    $data['is_on_scholarship'] ?? null, $data['user_name'], $data['status'],
                    $data['admin_id'], $data['student_id']
                ]);
                break;

            default:
                return false;
        }

        if ($stmt->errorCode() !== '00000') {
    // Error occurred
    error_log("Update error for $role: " . implode(", ", $stmt->errorInfo()));
    return false;
}

// Accept successful execution, even if no rows changed
$this->logActivity($role, $data[$role . '_id'], "Updated $role user", "Name: " . $data['name']);
return true;

    }

    // Validation method calling your external validation functions
    private function validateUserData(string $role, array $data): bool {
        require_once 'functions.php';  // ensure validations loaded

        if (!isValidAlpha($data['name'])) return false;
        if (!isValidUsername($data['user_name'])) return false;
        if (!isValidEmail($data['email'])) return false;
        if (!isValidStatus($data['status'])) return false;
if ($role === 'admin') {



if (isset($data['admin_role']) && !isValidAdminRole($data['admin_role'])) return false;

    if (isset($data['contact']) && !isValidContact($data['contact'])) return false;
}



        if ($role === 'teacher') {
            if (isset($data['qualification']) && !isValidQualification($data['qualification'])) return false;
            if (isset($data['code']) && !empty($data['code']) && !isValidCode($data['code'])) return false;
            if (isset($data['photo']) && !empty($data['photo']) && !isValidPhoto($data['photo'])) return false;
            if (isset($data['description']) && !empty($data['description']) && !isValidDescription($data['description'])) return false;
        }

        if ($role === 'student') {
            if (isset($data['class']) && !isValidClass($data['class'])) return false;
            if (isset($data['is_on_scholarship']) && !isValidBooleanLike($data['is_on_scholarship'])) return false;
        }

        return true;
    }

    // Map role to table name
    private function getTableNameByRole(string $role): ?string {
        $map = [
            'admin' => 'admin',
            'teacher' => 'teacher',
            'student' => 'student'
        ];
        return $map[$role] ?? null;
    }

    // Log activity helper method
    private function logActivity(string $role, int $id, string $action, string $description): void {
        require_once 'functions.php';
        logActivity($this->pdo, $id, $role, $action, $description);
    }

    public function deleteUser($role, $id) {
    $table = '';
    $idField = '';

    switch ($role) {
        case 'admin':
            $table = 'admin';
            $idField = 'admin_id';
            break;
        case 'teacher':
            $table = 'teacher';
            $idField = 'teacher_id';
            break;
        case 'student':
            $table = 'student';
            $idField = 'student_id';
            break;
        default:
            return ['error' => '❌ Invalid role.'];
    }

    // Check if user exists
    $stmt = $this->pdo->prepare("SELECT * FROM $table WHERE $idField = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();

    if (!$user) {
        return ['error' => '❌ User not found or already deleted.'];
    }

    // Foreign key checks (optional, but good UX)
    if ($role === 'admin') {
        $check = $this->pdo->prepare("SELECT COUNT(*) FROM course WHERE admin_id = ?");
        $check->execute([$id]);
        if ($check->fetchColumn() > 0) {
            return ['error' => '❌ Cannot delete admin. There are courses assigned to this admin.'];
        }
    }

    if ($role === 'teacher') {
        $check = $this->pdo->prepare("SELECT COUNT(*) FROM course WHERE teacher_id = ?");
        $check->execute([$id]);
        if ($check->fetchColumn() > 0) {
            return ['error' => '❌ Cannot delete teacher. There are courses assigned to this teacher.'];
        }
    }

    if ($role === 'student') {
        $check = $this->pdo->prepare("SELECT COUNT(*) FROM enroll WHERE student_id = ?");
        $check->execute([$id]);
        if ($check->fetchColumn() > 0) {
            return ['error' => '❌ Cannot delete student. The student is enrolled in courses.'];
        }
    }

    // Now try to delete and catch foreign key exceptions
    try {
        $stmt = $this->pdo->prepare("DELETE FROM $table WHERE $idField = ?");
        $stmt->execute([$id]);

        if ($stmt->rowCount() > 0) {
            logActivity(
                $this->pdo,
                $id,
                $role,
                "Deleted $role",
                "Deleted $role with ID: $id"
            );
            return ['success' => "✅ User deleted successfully."];
        } else {
            return ['error' => "❌ Deletion failed. User may not exist."];
        }
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            // 23000 is the SQLSTATE code for integrity constraint violation
            return ['error' => "❌ Cannot delete $role. There are related records preventing deletion."];
        }
        // Other DB errors
        return ['error' => "❌ Database error: " . $e->getMessage()];
    }
}


public function getUserByRoleAndId($role, $id) {
    switch ($role) {
        case 'admin':
            $table = 'admin';
            $idField = 'admin_id';
            break;
        case 'teacher':
            $table = 'teacher';
            $idField = 'teacher_id';
            break;
        case 'student':
            $table = 'student';
            $idField = 'student_id';
            break;
        default:
            return false;
    }
    $stmt = $this->pdo->prepare("SELECT * FROM $table WHERE $idField = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

// Fetch all admins
    public function getAdmins(): array {
        $stmt = $this->pdo->query("SELECT * FROM admin ORDER BY admin_id ASC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fetch all teachers
    public function getTeachers(): array {
        $stmt = $this->pdo->query("SELECT * FROM teacher ORDER BY teacher_id ASC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fetch all students
    public function getStudents(): array {
        $stmt = $this->pdo->query("SELECT * FROM student ORDER BY student_id ASC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Search users by name or email, optionally filtering by role.
     * @param string $searchTerm Search keyword.
     * @param string $role One of 'admin', 'teacher', 'student', or 'all'.
     * @return array Associative array of results, keys are roles.
     */
    public function searchUsers($searchTerm, $role = 'all') {
    $results = [];
    $searchLike = "%$searchTerm%";

    if ($role === 'admin' || $role === 'all') {
        $stmt = $this->pdo->prepare("SELECT * FROM admin WHERE name LIKE :search1 OR email LIKE :search2");
        $stmt->execute(['search1' => $searchLike, 'search2' => $searchLike]);
        $results['admins'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    if ($role === 'teacher' || $role === 'all') {
        $stmt = $this->pdo->prepare("SELECT * FROM teacher WHERE name LIKE :search1 OR email LIKE :search2");
        $stmt->execute(['search1' => $searchLike, 'search2' => $searchLike]);
        $results['teachers'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    if ($role === 'student' || $role === 'all') {
        $stmt = $this->pdo->prepare("SELECT * FROM student WHERE name LIKE :search1 OR email LIKE :search2");
        $stmt->execute(['search1' => $searchLike, 'search2' => $searchLike]);
        $results['students'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    return $results;
}

public function filterUsers($roleFilter = '', $statusFilter = '') {
    if ($roleFilter !== '' && !in_array($roleFilter, $this->allowedRoles)) {
        throw new InvalidArgumentException("Invalid role selected.");
    }

    if ($statusFilter !== '' && !in_array(strtolower($statusFilter), $this->allowedStatuses)) {
        throw new InvalidArgumentException("Invalid status selected.");
    }

    $results = [];

    if ($roleFilter) {
        if ($statusFilter) {
            $stmt = $this->pdo->prepare("SELECT * FROM $roleFilter WHERE LOWER(status) = :status");
            $stmt->execute([':status' => strtolower($statusFilter)]);
        } else {
            $stmt = $this->pdo->prepare("SELECT * FROM $roleFilter");
            $stmt->execute();
        }
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } elseif ($statusFilter) {
        foreach ($this->allowedRoles as $role) {
            $stmt = $this->pdo->prepare("SELECT * FROM $role WHERE LOWER(status) = :status");
            $stmt->execute([':status' => strtolower($statusFilter)]);
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($data as &$row) {
                $row['role'] = $role;
            }
            $results = array_merge($results, $data);
        }
    }

    return $results;
}


public function logFilterActivity($userId, $userType, $roleFilter, $statusFilter) {
        $filterDetail = "Filtered users";
        if ($roleFilter) $filterDetail .= " by role: $roleFilter";
        if ($statusFilter) {
            $filterDetail .= (strpos($filterDetail, ':') ? ", " : " by ") . "status: $statusFilter";
        }

        logActivity(
            $this->pdo,
            $userId,
            $userType,
            'Filter User',
            $filterDetail
        );
}

// Update user status (approve/reject)
    public function updateUserStatus($id, $role, $action) {
        if (!in_array($role, $this->allowedRoles)) {
            throw new InvalidArgumentException("Invalid role specified.");
        }

        $newStatus = ($action === 'approve') ? 'approved' : (($action === 'reject') ? 'rejected' : null);
        if (!$newStatus) {
            throw new InvalidArgumentException("Invalid action specified.");
        }

        $table = $role;
        $idColumn = $role . '_id';

        $stmt = $this->pdo->prepare("UPDATE $table SET status = :status WHERE $idColumn = :id");
        return $stmt->execute([':status' => $newStatus, ':id' => $id]);
    }

    // Get all pending users from all roles
    public function getPendingUsers() {
        $users = [];

        foreach ($this->allowedRoles as $role) {
            $table = $role;
            $idColumn = $role . '_id';

            $stmt = $this->pdo->prepare("SELECT $idColumn AS id, user_name, :role AS role FROM $table WHERE status = 'pending'");
            $stmt->execute([':role' => $role]);
            $users = array_merge($users, $stmt->fetchAll(PDO::FETCH_ASSOC));
        }

        return $users;
    }
}

