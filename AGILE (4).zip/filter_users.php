<?php
session_start();
require 'db.php';
require 'UserManager.php';
require 'functions.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';

// Middleware
allowOnlyUserType('admin');
allowRole(['Super Admin']);
checkSessionTimeout(); // 15-minute timeout default

// Filters
$roleFilter = $_GET['role'] ?? '';
$statusFilter = $_GET['status'] ?? '';

$allowedRoles = ['admin', 'teacher', 'student'];
$allowedStatuses = ['pending', 'approved', 'rejected'];

try {
    // Validate inputs
    if ($roleFilter && !in_array($roleFilter, $allowedRoles)) {
        throw new InvalidArgumentException("Invalid role selected.");
    }
    if ($statusFilter && !in_array($statusFilter, $allowedStatuses)) {
        throw new InvalidArgumentException("Invalid status selected.");
    }

    $userManager = new UserManager($pdo);
    $users = $userManager->filterUsers($roleFilter, $statusFilter);

    // Log activity
    if (!empty($users) && isset($_SESSION['user_id'], $_SESSION['user_type'])) {
        $userManager->logFilterActivity($_SESSION['user_id'], $_SESSION['user_type'], $roleFilter, $statusFilter);
    }
} catch (InvalidArgumentException $e) {
    die("<p style='color: red;'>" . htmlspecialchars($e->getMessage()) . "</p>");
} catch (PDOException $e) {
    die("Database error: " . htmlspecialchars($e->getMessage()));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="userstyle.css">
  <title>USER MANAGEMENT</title>
</head>
<body>

<div class="header">
    <img src="img/logoo.png" alt="School Logo" class="logo">
    <div class="system-title"><strong>User Management System</strong></div>
</div>

<div class="dashboard-container">
    <div class="hamburger" onclick="toggleSidebar()">☰</div>
    <aside class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="homepage.php">Home</a></li>
            <li><a href="user_management.php">Manage Users</a></li>
            <li><a href="course.php">Courses</a></li>
            <li><a href="about.php">About Us</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <div class="form-box">
            <fieldset>
                <legend><strong>User Records</strong></legend>
                <div class="filter-form">
                    <form method="GET">
                        <label for="role-filter">Filter by Role:</label>
                        <select name="role" id="role-filter">
                            <option value="">Select Role</option>
                            <option value="admin" <?= ($roleFilter === 'admin') ? 'selected' : '' ?>>Admin</option>
                            <option value="teacher" <?= ($roleFilter === 'teacher') ? 'selected' : '' ?>>Teacher</option>
                            <option value="student" <?= ($roleFilter === 'student') ? 'selected' : '' ?>>Student</option>
                        </select>

                        <label for="status-filter" style="margin-left: 20px;">Filter by Status:</label>
                        <select name="status" id="status-filter">
                            <option value="">Select Status</option>
                            <option value="pending" <?= ($statusFilter === 'pending') ? 'selected' : '' ?>>Pending</option>
                            <option value="approved" <?= ($statusFilter === 'approved') ? 'selected' : '' ?>>Approved</option>
                            <option value="rejected" <?= ($statusFilter === 'rejected') ? 'selected' : '' ?>>Rejected</option>
                        </select>

                        <button type="submit" style="margin: 15px auto 0; padding: 8px 12px; background-color: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold;">
                            Filter
                        </button>
                    </form>
                </div>
            </fieldset>
        </div>

        <?php
    function renderTable($roleFilter, $users) {
        echo "<h3>" . ucfirst($roleFilter) . " Users</h3>";
        echo "<table><tr><th>ID</th><th>Name</th><th>Email</th>";

        if ($roleFilter === 'admin') {
            echo "<th>Contact</th><th>Role</th><th>Username</th><th>Status</th></tr>";
            foreach ($users as $user) {
                echo "<tr>
                        <td>{$user['admin_id']}</td>
                        <td>{$user['name']}</td>
                        <td>{$user['email']}</td>
                        <td>{$user['contact']}</td>
                        <td>{$user['role']}</td>
                        <td>{$user['user_name']}</td>
                        <td>{$user['status']}</td>
                    </tr>";
            }
        } elseif ($roleFilter === 'teacher') {
            echo "<th>Qualification</th><th>Code</th><th>Username</th><th>Status</th></tr>";
            foreach ($users as $user) {
                echo "<tr>
                        <td>{$user['teacher_id']}</td>
                        <td>{$user['name']}</td>
                        <td>{$user['email']}</td>
                        <td>{$user['qualification']}</td>
                        <td>{$user['code']}</td>
                        <td>{$user['user_name']}</td>
                        <td>{$user['status']}</td>
                    </tr>";
            }
        } elseif ($roleFilter === 'student') {
            echo "<th>Class</th><th>Scholarship</th><th>Username</th><th>Status</th></tr>";
            foreach ($users as $user) {
                echo "<tr>
                        <td>{$user['student_id']}</td>
                        <td>{$user['name']}</td>
                        <td>{$user['email']}</td>
                        <td>{$user['class']}</td>
                        <td>{$user['is_on_scholarship']}</td>
                        <td>{$user['user_name']}</td>
                        <td>{$user['status']}</td>
                    </tr>";
            }
        }

        echo "</table><br>";
    }

    // When a specific role is selected
if ($roleFilter !== '') {
    if (empty($users)) {
        echo "<p>No users found for role: " . htmlspecialchars($roleFilter) . ".</p>";
    } else {
        renderTable($roleFilter, $users);
    }
} elseif ($statusFilter !== '') {
    $grouped = [
        'admin' => [],
        'teacher' => [],
        'student' => []
    ];

    foreach ($users as $user) {
        $grouped[$user['role']][] = $user;
    }

    // Check if all grouped lists are empty
    if (empty($grouped['admin']) && empty($grouped['teacher']) && empty($grouped['student'])) {
        echo "<p>No users found with status: " . htmlspecialchars($statusFilter) . ".</p>";
    } else {
        foreach ($grouped as $r => $list) {
            if (!empty($list)) {
                renderTable($r, $list);
            }
        }
    }
} else {
    echo "<p>Please select a role or status to filter users.</p>";
}

    ?>
        <br><br>
        <a href="user_management.php"><button>Go Back</button></a>
    </main>
</div>

<script>
window.addEventListener('DOMContentLoaded', function () {
    const navEntry = performance.getEntriesByType("navigation")[0];
    if (navEntry && navEntry.type === "reload") {
        window.location.href = window.location.pathname;
    }
});
</script>

</body>
</html>
