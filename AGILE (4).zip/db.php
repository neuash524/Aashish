<?php
/*
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'student_record_system';


$mysqli = new mysqli("localhost", "root", "", "student_record_system");

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}*/



// Basic database connection using PDO

$host = 'localhost';
$db   = 'student_record_system'; // replace with your actual database name
$user = 'root';            // default for XAMPP
$pass = '';                // default for XAMPP is empty string
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // throws exceptions on errors
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // fetches rows as assoc arrays
    PDO::ATTR_EMULATE_PREPARES   => false,                  // use native prepares
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options); // correct argument order
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}


?>




