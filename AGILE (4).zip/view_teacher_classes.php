<?php
require 'authentication_middleware.php';
require 'authorization_middleware.php';

allowOnlyUserType('teacher'); // Only teachers can access

require_once 'db.php';

$teacher = null;
$teacher_id = $_SESSION['user_id'] ?? null;

$courses = [];

if ($teacher_id) {
    $stmt = $pdo->prepare("SELECT code, name, description, type FROM course WHERE teacher_id = ?");
    $stmt->execute([$teacher_id]);
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="edit_teacher.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
   <link rel="icon" href="img/logoo.png" type="image/webp">
   <script src="Navigation.js" defer></script>

<style>
/* Table Section for Course Display */
.course-table {
    margin: 0 auto;
    border-collapse: collapse;
    width: 80%;
    background-color: #fff;
}

.course-table th, .course-table td {
    padding: 14px 18px;
    border: 1px solid #ccc;
    color: #000;
    text-align: center;
    background-color: #ffffff; 
}

.course-table th {
    background-color: #2980b9;
    color: white;
}

.course-table tr:nth-child(even) td {
    background-color: #f0f0f0; 
}


.course-table tr:hover {
    background-color: #f1f1f1;
}


.action-buttons {
    display: flex;
    gap: 10px;
    justify-content: center;
      flex-wrap: wrap;
      margin-top: 10px;
}

.action-buttons a button {
      background-color: #2980b9;
      color: white;
      border: none;
      padding: 8px 12px;
      border-radius: 4px;
      cursor: pointer;
      transition: background-color 0.3s ease;
}

.action-buttons a button:hover {
    background-color: #3498db;
}

.page-title {
    text-align: center;
    margin-top: 40px;
    color: white;
    font-size: 32px;
}
</style>
</head>
<body>
  <nav>
  <img src="img/logoo.png" alt="Logo" class="logo">
  <div class="nav-links" id="navLinks">
    <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i>
    <ul>
      <li><a href="homepage.php">HOME</a></li>
      <li><a href="teacher_profile.php">COURSE</a></li>
      <li><a href="staff.php">STAFF</a></li>
      <li><a href="login.php">LOG IN</a></li>
    </ul>
  </div>
  <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i>
</nav>
  <h2 class="page-title">My Assigned Courses</h2>
<main>
  <?php if (!empty($courses)): ?>
    <table class="course-table">
      <tr>
        <th>Code</th>
        <th>Course Name</th>
        <th>Description</th>
        <th>Type</th>
      </tr>
      <?php foreach ($courses as $course): ?>
        <tr>
          <td><?= htmlspecialchars($course['code']) ?></td>
          <td><?= htmlspecialchars($course['name']) ?></td>
          <td><?= htmlspecialchars($course['description']) ?></td>
          <td><?= htmlspecialchars($course['type']) ?></td>

          <td>
            <div class="action-buttons">
              <a href="view_course_materials.php?course_code=<?= urlencode($course['code']) ?>">
                <button>View Material</button>
              </a>
              <a href="upload_assignment.php?course_code=<?= urlencode($course['code']) ?>">
                <button>Upload Assignment</button>
              </a>
              <a href="view_assignment.php?course_code=<?= urlencode($course['code']) ?>">
                <button>View Assignments</button>
              </a>
            </div>
          </td>

        </tr>
      <?php endforeach; ?>
    </table>
  <?php else: ?>
    <p>No courses assigned yet.</p>
  <?php endif; ?>

  <a class="back-btn"href="view_teacher_dashboard.php">← Back to My Profile</a>
</main>

<script>
  var navLinks = document.getElementById("navLinks");
  function openMenu() {
    navLinks.style.right = "0";
  }
  function closeMenu() {
    navLinks.style.right = "-200px";
  }
</script>
</body>
</html>
