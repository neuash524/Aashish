<?php
date_default_timezone_set('UTC');
require_once 'functions.php';
try {
    $pdo = new PDO('mysql:host=localhost;dbname=student_record_system;charset=utf8', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$base_url = "http://localhost/AGILE/"; // Change if your base URL is different

function log_result($id, $op, $status, $message) {
    $log = "$id | $op | $status | $message | " . date("Y-m-d H:i:s") . "\n";
    file_put_contents("user_manager_test_log.txt", $log, FILE_APPEND);
    echo $log;
}

function fetch_url($url) {
    $context = stream_context_create([
        'http' => [
            'timeout' => 5,
        ],
    ]);
    return @file_get_contents($url, false, $context);
}

function send_post($url, $data) {
    $opts = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ]
    ];
    $ctx = stream_context_create($opts);
    return file_get_contents($url, false, $ctx);
}

/*// 🔹 1. Add Admin User
function test_add_admin() {
    global $base_url;
    $data = [
        'name' => 'Simran Khadka',
        'email' => 'simran.khadka@example.com',
        'role' => 'admin',
        'admin_contact' => '12312312',
        'admin_role' => 'Super Admin'
    ];
    $res = send_post($base_url . "api_add_user.php", $data);
    $response = json_decode($res, true);

    if (!empty($response['success']) && $response['success'] === true) {
        log_result('TC001', 'Add Admin User', 'PASS', 'User added: ' . $data['email']);
    } else {
        log_result('TC001', 'Add Admin User', 'FAIL', $res);
    }
}

// 🔹 2. Add Teacher User
function test_add_teacher() {
    global $base_url;
    $data = [
        'name' => 'Boby Deol',
        'email' => 'boby.deol@example.com',
        'role' => 'teacher',
        'qualification' => 'MSc Computer Science',
        'code' => 'TCH127',
        'description' => 'Senior math teacher'
    ];
    $res = send_post($base_url . "api_add_user.php", $data);
    $response = json_decode($res, true);

    if (!empty($response['success']) && $response['success'] === true) {
        log_result('TC002', 'Add Teacher User', 'PASS', 'User added: ' . $data['email']);
    } else {
        log_result('TC002', 'Add Teacher User', 'FAIL', $res);
    }
}

// 🔹 3. Add Student User
function test_add_student() {
    global $base_url;
    $data = [
        'name' => 'Charlies Angel',
        'email' => 'charlies.angel@example.com',
        'role' => 'student',
        'class' => 10,
        'is_on_scholarship' => 1
    ];
    $res = send_post($base_url . "api_add_user.php", $data);
    $response = json_decode($res, true);

    if (!empty($response['success']) && $response['success'] === true) {
        log_result('TC003', 'Add Student User', 'PASS', 'User added: ' . $data['email']);
    } else {
        log_result('TC003', 'Add Student User', 'FAIL', $res);
    }
}

// Run all tests
test_add_admin();
test_add_teacher();
test_add_student();*/



function test_update_users() {
    global $base_url;

    $tests = [
        [
            'id' => 'TU001',
            'desc' => 'Update admin user valid',
            'data' => [
                'role' => 'admin',
                'admin_id' => 1363,
                'name' => 'Simi Arora',
                'email' => 'simiiaroraaa@example.com',
                'admin_role' => 'super admin',
                'contact' => '12345678',
                'status' => 'rejected',
                'user_name' => 'simmii1234'
            ],
            'expect_success' => true
        ],
      /* [
            'id' => 'TU002',
            'desc' => 'Update teacher user valid',
            'data' => [
                'role' => 'teacher',
                'teacher_id' => 1021,
                'name' => 'Sherriff Updated',
                'email' => 'sherriffupdated@example.com',
                'qualification' => 'PhD',
                'photo' => '',
                'description' => 'Updated description',
                'code' => 'TCH67',
                'user_name' => 'teacheruser21',
                'status' => 'pending',
                'admin_id' => 1116
            ],
            'expect_success' => true
        ],
        [
            'id' => 'TU003',
            'desc' => 'Update student user valid',
            'data' => [
                'role' => 'student',
                'student_id' => 40135,
                'name' => 'Jack Roger',
                'email' => 'jackrogupdated@example.com',
                'class' => 9,
                'is_on_scholarship' => 0,
                'user_name' => 'studentuser16',
                'status' => 'approved',
                'admin_id' => 1117
            ],
            'expect_success' => true
        ],
        /*[
            'id' => 'TU004',
            'desc' => 'Update invalid role',
            'data' => [
                'role' => 'invalidrole',
                'id' => 1,
                'name' => 'Invalid Role',
                'email' => 'invalid@example.com',
                'user_name' => 'invaliduser',
                'status' => 'pending'
            ],
            'expect_success' => false
        ],*/
    ];

    $url = $base_url . "api_update_user.php";

    foreach ($tests as $test) {
        $response = send_post($url, $test['data']);

        if ($response === false) {
            log_result($test['id'], $test['desc'], 'FAIL', 'No response or HTTP error');
            continue;
        }

        $data = json_decode($response, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            log_result($test['id'], $test['desc'], 'FAIL', 'Invalid JSON response');
            continue;
        }

        if (isset($data['success']) && $data['success'] === $test['expect_success']) {
            log_result($test['id'], $test['desc'], 'PASS', $data['message'] ?? 'Success status as expected');
        } else {
            log_result($test['id'], $test['desc'], 'FAIL', 'Unexpected success status or message: ' . json_encode($data));
        }
    }
}

// Run tests
test_update_users();


/*// 🔹 Delete Admin
function test_delete_admin_user() {
    global $base_url;
    $data = [
        'role' => 'admin',
        'id' => 1361,
    ];
    $res = send_post($base_url."api_delete_user.php", $data);
    
    // Debugging: output the full response
    echo "Response for Delete Admin: $res\n";
    
    $status = strpos($res, '"success":true') !== false ? 'PASS' : 'FAIL';
    log_result('TU010', 'Delete Admin', $status, $res);
}


// 🔹 Delete Student
function test_delete_student_user() {
    global $base_url;
    $data = [
        'role' => 'student',
        'id' => 40133,  // replace with a valid student_id for testing
    ];
    $res = send_post($base_url."api_delete_user.php", $data);
    $status = strpos($res, '"success":true') !== false ? 'PASS' : 'FAIL';
    log_result('TU011', 'Delete Student', $status, $res);
}

// 🔹 Delete Teacher
function test_delete_teacher_user() {
    global $base_url;
    $data = [
        'role' => 'teacher',
        'id' => 1020,  // replace with a valid teacher_id for testing
    ];
    $res = send_post($base_url."api_delete_user.php", $data);
    $status = strpos($res, '"success":true') !== false ? 'PASS' : 'FAIL';
    log_result('TU012', 'Delete Teacher', $status, $res);
}

// Run all tests
test_delete_admin_user();
test_delete_student_user();
test_delete_teacher_user();





// Test List Admins
function test_list_admins() {
    global $base_url;
    $res = file_get_contents($base_url . "api_view_users.php?role=admin");
    $status = strpos($res, '"success":true') !== false ? 'PASS' : 'FAIL';
    log_result('TU013', 'List Admins', $status, $res);
}

// Test List Teachers
function test_list_teachers() {
    global $base_url;
    $res = file_get_contents($base_url . "api_view_users.php?role=teacher");
    $status = strpos($res, '"success":true') !== false ? 'PASS' : 'FAIL';
    log_result('TU014', 'List Teachers', $status, $res);
}

// Test List Students
function test_list_students() {
    global $base_url;
    $res = file_get_contents($base_url . "api_view_users.php?role=student");
    $status = strpos($res, '"success":true') !== false ? 'PASS' : 'FAIL';
    log_result('TU015', 'List Students', $status, $res);
}

// Run all tests
test_list_admins();
test_list_teachers();
test_list_students();




// Test search users for different roles
function test_search_users() {
    global $base_url;

    $tests = [
        ['id' => 'TU016', 'role' => 'all', 'desc' => 'Search Users All Roles'],
        ['id' => 'TU017', 'role' => 'admin', 'desc' => 'Search Admin Users'],
        ['id' => 'TU018', 'role' => 'student', 'desc' => 'Search Student Users'],
        ['id' => 'TU019', 'role' => 'teacher', 'desc' => 'Search Teacher Users'],
    ];

    $query = 'Seemran';

    foreach ($tests as $test) {
        $url = $base_url . "api_search_user.php?q=" . urlencode($query) . "&role=" . $test['role'];
        $response = fetch_url($url);

        if ($response === false) {
            log_result($test['id'], $test['desc'], 'FAIL', 'No response or 404 error');
            continue;
        }

        $json = json_decode($response, true);

        if ($json && isset($json['success']) && $json['success'] === true) {
            log_result($test['id'], $test['desc'], 'PASS', $response);
        } else {
            log_result($test['id'], $test['desc'], 'FAIL', $response);
        }
    }
}

// Run the tests
test_search_users();



function test_filter_users() {
    global $base_url;

    $tests = [
        ['role' => '', 'status' => '', 'id' => 'TF001', 'desc' => 'Filter no criteria'],
        ['role' => 'admin', 'status' => '', 'id' => 'TF002', 'desc' => 'Filter role admin'],
        ['role' => '', 'status' => 'approved', 'id' => 'TF003', 'desc' => 'Filter status approved'],
        ['role' => 'teacher', 'status' => 'pending', 'id' => 'TF004', 'desc' => 'Filter role teacher, status pending'],
        ['role' => 'student', 'status' => 'rejected', 'id' => 'TF005', 'desc' => 'Filter role student, status rejected'],
        ['role' => 'invalidrole', 'status' => '', 'id' => 'TF006', 'desc' => 'Filter invalid role'],  // Should handle invalid gracefully
        ['role' => '', 'status' => 'invalidstatus', 'id' => 'TF007', 'desc' => 'Filter invalid status'],  // Should handle invalid gracefully
    ];

    foreach ($tests as $test) {
        $url = $base_url . "api_filter_users.php?";
        $params = [];
        if ($test['role'] !== '') $params['role'] = urlencode($test['role']);
        if ($test['status'] !== '') $params['status'] = urlencode($test['status']);

        if (!empty($params)) {
            $url .= http_build_query($params);
        }

        $response = fetch_url($url);

        if ($response === false) {
            log_result($test['id'], $test['desc'], 'FAIL', 'No response or HTTP error');
            continue;
        }

        $data = json_decode($response, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            log_result($test['id'], $test['desc'], 'FAIL', 'Invalid JSON response');
            continue;
        }

        // Basic validation: Check if response is array and not empty (or empty but valid)
        if (is_array($data)) {
            log_result($test['id'], $test['desc'], 'PASS', 'Valid response received');
        } else {
            log_result($test['id'], $test['desc'], 'FAIL', 'Response not array');
        }
    }
}

// Run tests
test_filter_users();


function test_verify_users() {
    global $base_url;

    $tests = [
        ['id' => 1, 'role' => 'admin', 'action' => 'approve', 'testId' => 'TV001', 'desc' => 'Approve admin user'],
        ['id' => 2, 'role' => 'teacher', 'action' => 'reject', 'testId' => 'TV002', 'desc' => 'Reject teacher user'],
        ['id' => 3, 'role' => 'student', 'action' => 'approve', 'testId' => 'TV003', 'desc' => 'Approve student user'],
        ['id' => 9999, 'role' => 'teacher', 'action' => 'approve', 'testId' => 'TV005', 'desc' => 'Non-existing user'],
    ];

    foreach ($tests as $test) {
        $url = $base_url . "api_verify_user.php";
        $postData = [
            'id' => $test['id'],
            'role' => $test['role'],
            'action' => $test['action'],
        ];

        $response = send_post($url, $postData);

        if ($response === false) {
            log_result($test['testId'], $test['desc'], 'FAIL', 'No response or HTTP error');
            continue;
        }

        $data = json_decode($response, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            log_result($test['testId'], $test['desc'], 'FAIL', 'Invalid JSON response');
            continue;
        }

        if (isset($data['success']) && $data['success'] === true) {
            log_result($test['testId'], $test['desc'], 'PASS', $data['message'] ?? 'Success');
        } else {
            log_result($test['testId'], $test['desc'], 'FAIL', $data['message'] ?? 'Failed to update');
        }
    }
}

// Run the verify user tests
test_verify_users();

function test_login_api() {
    global $base_url;

    $tests = [
        [
            'id' => 'LG001',
            'desc' => 'Valid admin login',
            'data' => ['user_name' => 'skhadka_admin', 'password' => 'TJ9ALH6u'],
            'expect_success' => true
        ],
        [
            'id' => 'LG002',
            'desc' => 'Invalid password',
            'data' => ['user_name' => 'studentuser3', 'password' => 'wrongpassword'],
            'expect_success' => false
        ],
        [
            'id' => 'LG003',
            'desc' => 'Non-existent user',
            'data' => ['user_name' => 'notexist', 'password' => 'anything'],
            'expect_success' => false
        ],
        [
            'id' => 'LG004',
            'desc' => 'Missing password',
            'data' => ['user_name' => 'studentuser3'],
            'expect_success' => false
        ],
    ];

    $url = $base_url . 'api_login.php';

    foreach ($tests as $test) {
        $response = send_post($url, $test['data']);
        if ($response === false) {
            log_result($test['id'], $test['desc'], 'FAIL', 'No response or HTTP error');
            continue;
        }
        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            log_result($test['id'], $test['desc'], 'FAIL', 'Invalid JSON response');
            continue;
        }
        if (isset($data['success']) && $data['success'] === $test['expect_success']) {
            log_result($test['id'], $test['desc'], 'PASS', $data['message']);
        } else {
            log_result($test['id'], $test['desc'], 'FAIL', 'Unexpected success status or message: ' . json_encode($data));
        }
    }
}

test_login_api();*/
?>





