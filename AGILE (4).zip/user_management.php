<?php
/*include 'auth_middleware.php';

if ($_SESSION['role'] !== 'admin') {
    header('Location: login.php?error=Admins only');
    exit;
}*/
//echo "<pre>Session role: " . ($_SESSION['role'] ?? 'NOT SET') . "</pre>";


require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();

?>
<h1>Welcome to User Management, <?= htmlspecialchars($_SESSION['user_name']) ?>!</h1>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="userstyle.css"><!-- Link to the user CSS -->
    <title>User Management Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9fafb;
            color: #333;
        }

        .dashboard-container {
  padding: 40px 20px;
  max-width: 1200px;
  margin: auto;
  text-align: center;
}

.dashboard-container h1 {
  font-size: 32px;
  margin-bottom: 40px;
  color: #333;
}

.box-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 30px;
}

.box {
  background: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  border-radius: 12px;
  padding: 25px;
  box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
  color: white;
  transition: box-shadow 0.3s ease, transform 0.3s ease;
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.box:hover {
  box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
  transform: translateY(-5px);
}

.box h2 {
  color:rgb(0, 0, 0);
  font-size: 22px;
  margin-bottom: 10px;
}

.box p {
  color:rgb(0, 0, 0);
  font-size: 15px;
  margin-bottom: 20px;
}

.box-btn {
  display: inline-block;
  padding: 10px 18px;
  background-color: rgba(255, 255, 255, 0.25);
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background-color 0.3s ease;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.box-btn:hover {
  background-color: rgba(255, 255, 255, 0.45);
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.logout-footer {
  width: 100%;
  text-align: center;
  padding: 20px 0;
  position: relative;
  bottom: 0;
}

.logout-btn {
  display: inline-block;
  padding: 12px 24px;
  background: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background 0.3s ease, transform 0.2s ease;
  box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.logout-btn:hover {
  background: linear-gradient(rgba(200, 45, 211, 0.9), rgba(68, 175, 109, 0.9));
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
}

.back-btn {
  display: inline-block;
  padding: 12px 24px;
  background: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background 0.3s ease, transform 0.2s ease;
  box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.3);

}

.back-btn:hover {
  background: linear-gradient(rgba(200, 45, 211, 0.9), rgba(68, 175, 109, 0.9));
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
}




    </style>
</head>
<body>

<div class="header">
        <img src="img/logoo.png" alt="School Logo" class="logo">
        <div class="system-title"><strong>User Management System</strong></div>
</div>
<div class="dashboard-container">
  
  <!-- Main Content -->
  <main class="main-content">
    <h1>Welcome to the User Management Dashboard 📂</h1>
    <div class="box-grid">

    <div class="box">
      <div class="icon">➕</div>
      <h2>Add User</h2>
      <p>Create a new Admin, Teacher, or Student.</p>
      <a href="add_user.php" class="box-btn">Go to Add User</a>
    </div>

    <div class="box">
      <div class="icon">✏️</div>
      <h2>Update User</h2>
      <p>Edit existing user information by role and ID.</p>
      <a href="view_users.php" class="box-btn">Go to Update User</a>
    </div>

    <div class="box">
      <div class="icon">🗑️</div>
      <h2>Delete User</h2>
      <p>Remove a user account from the system.</p>
      <a href="delete_user.php" class="box-btn">Go to Delete User</a>
    </div>

    <div class="box">
      <div class="icon">🔍</div>
      <h2>Search User</h2>
      <p>Look up users by name, role, or other criteria.</p>
      <a href="search_user.php" class="box-btn">Go to Search User</a>
    </div>

    <div class="box">
      <div class="icon">📋</div>
      <h2>View Users</h2>
      <p>Display a list of all users by category.</p>
      <a href="view_users.php" class="box-btn">Go to View Users</a>
    </div>

    <div class="box">
      <div class="icon">🔽</div>
      <h2>Filter Users</h2>
      <p>Filter users based on role or attributes.</p>
      <a href="filter_users.php" class="box-btn">Go to Filter Users</a>
    </div>

    <div class="box">
  <div class="icon">✅</div>
  <h2>Verify Users</h2>
  <p>Approve or reject newly registered users.</p>
  <a href="verify_users.php" class="box-btn">Go to Verify Users</a>
  </div>

  <div class="box">
      <div class="icon">📋</div>
      <h2>View Students</h2>
      <p>Display a list of students.</p>
      <a href="view_students.php" class="box-btn">Go to View Students</a>
  </div>
 
  <div class="box">
      <div class="icon">📋</div>
      <h2>View Teachers</h2>
      <p>Display a list of teachers.</p>
      <a href="view_all_teachers.php" class="box-btn">Go to View Teachers</a>
    </div>

</div>
  </main>
</div>

<footer class="logout-footer">
  <a href="all_users.php" class="back-btn">Go Back</a>

  <a href="logout.php" class="logout-btn">Logout</a>
</footer>


<script>
function searchUsers(event) {
    if (event.key === "Enter") {
        const query = document.getElementById("searchInput").value;
        window.location.href = 'search_user.php?query=' + encodeURIComponent(query);
    }
}
</script>

</body>
</html>