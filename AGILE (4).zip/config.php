<?php
// config.php

// Database configuration
define('DB_HOST', 'localhost'); // Your database server (usually localhost)
define('DB_NAME', 'student_record_system'); // Your database name
define('DB_USER', 'root'); // Your database username
define('DB_PASS', ''); // Your database password

try {
    // Create a new PDO instance
    $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit; // Stop execution if the connection fails
}
?>