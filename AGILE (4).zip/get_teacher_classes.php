<?php
include 'db.php';
session_start();

$teacher_id = $_SESSION['user_id'] ?? $_SESSION['teacher_id'] ?? null;

if (!$teacher_id) {
    echo json_encode([]);
    exit;
}

$sql = "SELECT c.name AS class_name, s.schedule_time, COUNT(e.student_id) AS student_count
        FROM course c
        LEFT JOIN schedule s ON c.code = s.course_code
        LEFT JOIN enroll e ON c.code = e.code
        WHERE c.teacher_id = ?
        GROUP BY c.code, s.schedule_time";

$stmt = $pdo->prepare($sql);
$stmt->execute([$teacher_id]);
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($classes);

?>
