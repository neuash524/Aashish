<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require 'authentication_middleware.php';
require 'authorization_middleware.php';

allowOnlyUserType('teacher'); // Only teachers can access

require_once 'db.php';

$teacher = null;
$teacher_id = $_SESSION['user_id'] ?? null;

// Fetch courses
$stmt = $pdo->prepare("SELECT code, name FROM course WHERE teacher_id = ?");
$stmt->execute([$teacher_id]);
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['uploads'])) {
    $code = $_POST['code'] ?? null;
    $title = $_POST['title'] ?? null;
    $file = $_FILES['uploads'];
    $upload_dir = "uploads/";
    $filename = basename($file["name"]);
    $file_path = $upload_dir . time() . "_" . $filename;

    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    if ($file['error'] === 0) {
        if (move_uploaded_file($file["tmp_name"], $file_path)) {
            $stmt = $pdo->prepare("INSERT INTO assignments (teacher_id, code, title, file_name, file_path, uploaded_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$teacher_id, $code, $title, $filename, $file_path]);

            $msg = "✅ Assignment uploaded successfully.";
        } else {
            $msg = "❌ Failed to move uploaded file.";
        }
    } else {
        $msg = "❌ Upload error code: " . $file['error'];
    }
}


?>

<!DOCTYPE html>
<html>
    <html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="edit_teacher.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
   <link rel="icon" href="img/logoo.png" type="image/webp">
   <script src="Navigation.js" defer></script>
   <title>Upload Assignment</title>
<style>

.upload-container {
    text-align: center;
    max-width: 600px;
    width:90%;
}

.upload-heading {
    margin-bottom: 20px;
    font-size: 32px;
}

.assignment-form {
    background-color: rgba(255, 255, 255, 0.1);
    padding: 30px 40px;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
    width: 100%;
    max-width: 500px;
    backdrop-filter: blur(10px);
    margin-top: 20px;
}

.assignment-form label {
    display: block;
    margin-top: 15px;
    font-weight: bold;
    color: #e0e0e0;
}

.assignment-form input[type="text"],
.assignment-form select,
.assignment-form input[type="file"] {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: none;
    border-radius: 6px;
    background-color: rgba(255, 255, 255, 0.9);
    color: #333;
}

.assignment-form input[type="submit"] {
    background-color: #00c6ff;
    color: white;
    border: none;
    padding: 12px 20px;
    border-radius: 6px;
    margin-top: 20px;
    cursor: pointer;
    width: 100%;
    font-weight: bold;
    transition: background-color 0.3s ease;
}

.assignment-form input[type="submit"]:hover {
    background-color: #0072ff;
}

p.upload-msg {
    color: lime;
    font-weight: bold;
    margin-top: 10px;
}
</style>

</head>
<body>
    <nav>
  <img src="img/logoo.png" alt="Logo" class="logo">
  <div class="nav-links" id="navLinks">
    <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i>
    <ul>
      <li><a href="homepage.php">HOME</a></li>
      <li><a href="dashboard.php">COURSE</a></li>
      <li><a href="staff.php">STAFF</a></li>
      <li><a href="login.php">LOG IN</a></li>
    </ul>
  </div>
  <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i>
</nav>
<div class="main-content">
    <div class="upload-container">
    <h2 class="upload-heading">Upload Assignment</h2>

    <?php if (!empty($msg)) echo "<p class='upload-msg'>$msg</p>"; ?>

    <form class="assignment-form"method="POST" enctype="multipart/form-data">
        <label>Course:</label>
        <select name="code" required>
            <?php foreach ($courses as $course): ?>
                <option value="<?= $course['code'] ?>"><?= htmlspecialchars($course['name']) ?></option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Assignment Title:</label>
        <input type="text" name="title" required><br><br>

        <label>Select File:</label>
        <input type="file" name="uploads" accept=".pdf,.doc,.docx" required><br><br>

        <input type="submit" value="Upload Assignment">

        <p><a class="back-btn"href="view_teacher_classes.php">← Back to My Courses</a></p>
    </form>
    <div>
</div>

    <script>
  var navLinks = document.getElementById("navLinks");
  function openMenu() {
    navLinks.style.right = "0";
  }
  function closeMenu() {
    navLinks.style.right = "-200px";
  }
</script>
    
</body>
</html>
