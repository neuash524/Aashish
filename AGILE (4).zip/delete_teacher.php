<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'db.php';

allowOnlyUserType('teacher');

// Handle deletion if it's a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    $teacher_id = $_SESSION['user_id'] ?? null;

    if (!$teacher_id) {
        echo json_encode(["deleted" => false, "error" => "User not logged in."]);
        exit;
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM teacher WHERE teacher_id = ?");
        $stmt->execute([$teacher_id]);

        if ($stmt->rowCount() > 0) {
            session_destroy();
            echo json_encode(["deleted" => true]);
        } else {
            echo json_encode(["deleted" => false, "error" => "Teacher not found or already deleted."]);
        }
    } catch (Exception $e) {
        echo json_encode(["deleted" => false, "error" => "Server error: " . $e->getMessage()]);
    }

    exit; // Prevent rendering HTML after JSON response
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete My Account | Greenfield School</title>
    <link rel="stylesheet" href="edit_teacher.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
<section class="header">
    <nav>
        <img src="img/logoo.png" alt="Logo" class="logo">
        <div class="nav-links" id="navLinks">
            <i class="fas fa-times" onclick="closeMenu()"></i>
            <ul>
                <li><a href="homepage.php">HOME</a></li>
                <li><a href="dashboard.php">COURSE</a></li>
                <li><a href="staff.php">STAFF</a></li>
                <li><a href="logout.php">LOG OUT</a></li>
            </ul>
        </div>
        <i class="fas fa-bars" onclick="openMenu()"></i>
    </nav>

    <div class="delete-section">
        <h1>Delete Your Account</h1>
        <p>This action will permanently remove your teacher profile. Proceed only if you're sure.</p>

        <button class="delete-btn" onclick="confirmDelete()">Delete My Account</button>
        <br><br>
        <a class="back-btn" href="view_teacher_dashboard.php">← Go Back</a>
    </div>
</section>

<script>
    function openMenu() {
        document.getElementById("navLinks").style.right = "0";
    }

    function closeMenu() {
        document.getElementById("navLinks").style.right = "-100%";
    }

    function confirmDelete() {
        if (confirm("Are you sure you want to delete your account? This action cannot be undone.")) {
            fetch(window.location.href, {
                method: 'POST'
            })
            .then(res => res.json())
            .then(data => {
                if (data.deleted) {
                    alert("Your account has been deleted.");
                    window.location.href = "login.php";
                } else {
                    alert("Error: " + data.error);
                }
            })
            .catch(error => {
                console.error(error);
                alert("An error occurred. Please try again.");
            });
        }
    }
</script>
</body>
</html>
