<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
     <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(rgba(135, 83, 177, 0.7), rgba(94, 187, 234, 0.7)), url('img/back_school.webp') no-repeat center center/cover;
      background-attachment: fixed;
      color: #f4f4f4;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    /* Header styles */
    .header {
      width: 100%;
      padding: 1rem 2rem;
      background-color: rgba(135, 83, 177, 0); /* transparent background to let image show */
    }

    nav{
    display: flex;
    padding:0rem;
    justify-content: space-between;
    align-items: center;

}
nav img{
    width:150px;
    height: 150px;
}
.nav-links{
    flex: 1;
    text-align: right;
    
}

.nav-links ul li{
    list-style: none;
    display: inline-block;
    padding: 8px 12px;
    position:relative;
}
.nav-links ul li a{
    color: #f3f3f3;
    text-decoration: none;
    font-size: 23px;
}

.nav-links ul li::after{
    content:'';
    width: 0%;
    height: 2px;
    background:#540026;
    display: block;
    margin: auto;
    transition: 0.5s;
}
.nav-links ul li:hover:after{
    width: 100%;
}
nav .fas {
  display: none; /* Hide toggle buttons on larger screens */
}

    .login-container {
      background: white;
      padding: 2rem;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
      width: 300px;
       margin: 60px auto;
      color: #000;
      
    }

    .login-container h2 {
      text-align: center;
      margin-bottom: 1.5rem;
      color: #1e293b;
    }

    .login-container input[type="text"],
    .login-container input[type="password"] {
      width: 100%;
      padding: 10px;
      margin: 0.5rem 0;
      border: 1px solid #cbd5e1;
      border-radius: 5px;
    }

    .login-container button {
      width: 100%;
      padding: 10px;
      background: #391e89;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      margin-top: 1rem;
    }

    .login-container button:hover {
      background: #2f1669;
    }

    .forgot-password {
      text-align: right;
      margin-top: 0.5rem;
    }

    .forgot-password a {
      color: #391e89;
      text-decoration: none;
      font-size: 0.9rem;
    }

    .forgot-password a:hover {
      text-decoration: underline;
    }
    @media(max-width: 768px){
    .text-box h1{
        font-size:30px;
     }
     .nav-links ul li{
        display:block;
     }
     .nav-links {
        position: absolute;
        background: rgba(195, 255, 177, 0.7);
        height: 100vh;
        width: 200px;
        top:0;
        right:-200px;
        text-align: left;
        z-index: 2;
        transition: 1s;

     }
    
     nav .fas{
        display: block;
        color:#fff;
        margin:10px;
        font-size:22px;
        cursor:pointer;

     }
     .nav-links ul{
        padding:30px;
     }
 }
  </style>
</head>
<body>
    <!-- Header with navigation -->
    <secion class="header">
<nav>
  <img src="img/logoo.png" alt="Logo" class="logo">
  <div class="nav-links" id="navLinks">
    <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i>
    <!-- Close menu icon -->
    <ul>
      <li><a href="homepage.php">HOME</a></li>
      <li><a href="course.php">COURSE</a></li>
      <li><a href="staff.php">STAFF</a></li>
      <li><a href="login.php">LOG IN</a></li>
    </ul>
  </div>
  <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i>
</nav>

<!-- Login Form -->
<div class =  "login-container">
<h2>Login</h2>
    <?php if (isset($_GET['error'])): ?>
        <p style="color:red"><?= htmlspecialchars($_GET['error']) ?></p>
    <?php endif; ?>
    <form method="post" action="authenticate1.php">
        <label>Username:</label>
        <input type="text" name="user_name" required><br><br>
        <label>Password:</label>
        <input type="password" name="password" required><br><br>
        <button type="submit">Login</button>
    </form>
    </div>



<script>
  var navLinks = document.getElementById("navLinks");
  function openMenu() {
    navLinks.style.right = "0";
  }
  function closeMenu() {
    navLinks.style.right = "-200px";
  }
</script>

</body>
</html>


