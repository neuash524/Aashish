<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require 'db.php'; // assumes db.php sets up $pdo with a PDO connection

$course = null;

if (isset($_GET['code'])) {
    $code = $_GET['code'];

    $stmt = $pdo->prepare("SELECT * FROM course WHERE code = ?");
    $stmt->execute([$code]);
    $course = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title> Course Details</title> <!-- Display page title -->
   <link rel="stylesheet" href="homepage.css"> <!-- Link to the homepage CSS -->
   <link href="img/logoo.png" rel="icon" type="image/webp"> <!-- Set favicon for the page -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome icons -->
   <script src="Navigation.js" defer></script> <!-- External JavaScript for navigation -->
</head>
    <style>
        body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f0f2f5;
    margin: 0;
    padding: 0;
    background-image: linear-gradient(rgba(200, 45, 211, 0.7),rgba(68, 175, 109, 0.7) ), url("img/build.jpg"); 
    background-position:center;
    background-size: cover;
    position: relative;
}


.navbar {
    background-color: #001f3f;
    color: white;
    padding: 1rem 2rem;
    font-size: 1.5rem;
    font-weight: bold;
    text-align: center;
}

.container {
    max-width: 90%;
    margin: 40px auto;
    background-color: white;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
}

h2 {
    color: #003366;
    font-size: 1.75rem;
    margin-bottom: 20px;
    text-align: center;
}

.detail {
    margin: 10px 0;
    font-size: 1rem;
}

.detail strong {
    display: inline-block;
    min-width: 120px;
    color: #333;
}

.back-btn {
  display: inline-block;
  padding: 12px 24px;
  background: blue;
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background 0.3s ease, transform 0.2s ease;
  box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.back-btn:hover {
  background: blue;
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
}


.course-card img,
.detail img {
    border-radius: 12px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    max-width: 100%;
    height: auto;
}

/* Responsive styles */
@media (min-width: 768px) {
    .container {
        max-width: 700px;
        padding: 30px;
    }

    .detail {
        font-size: 1.1rem;
    }

    h2 {
        font-size: 2rem;
    }
}

    </style>
</head>
<body>

<div class="navbar">
    Course Details
</div>

<div class="container">
    <?php if ($course): ?>
        <h2><?= htmlspecialchars($course['name']) ?></h2>

        <div class="detail">
            <?php if (!empty($course['image']) && file_exists($course['image'])): ?>
                <img src="<?= htmlspecialchars($course['image']) ?>" alt="Course Image" style="width:300px; height:auto; border-radius:12px; margin:auto;">
            <?php endif; ?>
        </div>

        <div class="detail"><strong>Code:</strong> <?= htmlspecialchars($course['code']) ?></div>
        <div class="detail"><strong>Description:</strong> <?= htmlspecialchars($course['description']) ?></div>
        <div class="detail"><strong>Type:</strong> <?= htmlspecialchars($course['type']) ?></div>
        <div class="detail"><strong>Credits:</strong> <?= htmlspecialchars($course['credits']) ?></div>
        <div class="detail"><strong>Admin ID:</strong> <?= htmlspecialchars($course['admin_id']) ?></div>
        <div class="detail"><strong>Teacher ID:</strong> <?= htmlspecialchars($course['teacher_id']) ?></div>
        <div class="detail"><strong>Active:</strong> <?= $course['is_active'] ? 'Yes' : 'No' ?></div>

        <a href="view_course.php" class="back-btn">← Back</a>
    <?php else: ?>
        <h1>Course not found.</h1>
    <?php endif; ?>
</div>
</section>

<!-- JavaScript for toggling the menu visibility -->
   <script>
      var navLinks = document.getElementById("navLinks");
      function openMenu() {
         navLinks.style.right = "0"; // Open the menu by setting the style to right = 0
      }
      function closeMenu() {
         navLinks.style.right = "-200px"; // Close the menu by shifting it off-screen
      }
   </script>
   

</body>
</html>
