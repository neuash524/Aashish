<?php

use PHPUnit\Framework\TestCase;

require_once 'UserManager.php';  // adjust path if needed

class UserManagerTest extends TestCase
{
    private $pdo;
    private $userManager;

    protected function setUp(): void
    {
        // Set up a PDO connection to the test database
        $dsn = 'mysql:host=localhost;dbname=test_db;charset=utf8mb4';  // adjust as needed
        $username = 'root'; // change to your DB username
        $password = '';     // change to your DB password

        $this->pdo = new PDO($dsn, $username, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);

        $this->userManager = new UserManager($this->pdo);

        // Clear the tables before each test
        $this->pdo->exec("DELETE FROM admin");
        $this->pdo->exec("DELETE FROM teacher");
        $this->pdo->exec("DELETE FROM student");
    }

    public function testAddAdminUser()
    {
        $data = [
            'name' => 'Admin User',
            'email' => 'admin@example.com',
            'role' => 'admin',
            'admin_contact' => '1234567890',
            'admin_role' => 'Super Admin',
        ];

        $response = $this->userManager->addUser($data);
        $this->assertTrue($response['success']);
        $this->assertEquals("User added successfully!", $response['message']);
        $this->assertArrayHasKey('credentials', $response);
        $this->assertArrayHasKey('username', $response['credentials']);
        $this->assertArrayHasKey('password', $response['credentials']);
    }

    public function testAddTeacherUser()
    {
        // Ensure there is a 'Teacher Admin' to get admin_id reference
        $this->pdo->exec("INSERT INTO admin (name, email, contact, role, user_name, hash_password) VALUES ('Teacher Admin', 'teacheradmin@example.com', '', 'Teacher Admin', 'teacheradmin', 'passwordhash')");

        $data = [
            'name' => 'Teacher User',
            'email' => 'teacher@example.com',
            'role' => 'teacher',
            'qualification' => 'Masters',
            'description' => 'Math Teacher',
            'code' => 'T123',
        ];

        // No photo file in this test
        $response = $this->userManager->addUser($data);
        $this->assertTrue($response['success']);
        $this->assertEquals("User added successfully!", $response['message']);
    }

    public function testAddStudentUser()
    {
        // Ensure there is a 'Student Admin' to get admin_id reference
        $this->pdo->exec("INSERT INTO admin (name, email, contact, role, user_name, hash_password) VALUES ('Student Admin', 'studentadmin@example.com', '', 'Student Admin', 'studentadmin', 'passwordhash')");

        $data = [
            'name' => 'Student User',
            'email' => 'student@example.com',
            'role' => 'student',
            'class' => '10th Grade',
            'is_on_scholarship' => true,
        ];

        $response = $this->userManager->addUser($data);
        $this->assertTrue($response['success']);
        $this->assertEquals("User added successfully!", $response['message']);
    }

    public function testGetUserById()
    {
        // Add an admin user directly to DB
        $this->pdo->exec("INSERT INTO admin (name, email, contact, role, user_name, hash_password, status) VALUES ('Admin User', 'admin@example.com', '1234567890', 'Super Admin', 'adminuser', 'passwordhash', 'approved')");
        $user = $this->userManager->getUserById('admin', 1);
        $this->assertNotNull($user);
        $this->assertEquals('Admin User', $user['name']);
    }

    public function testUpdateUserStatus()
    {
        // Insert admin user
        $this->pdo->exec("INSERT INTO admin (name, email, contact, role, user_name, hash_password, status) VALUES ('Admin User', 'admin@example.com', '1234567890', 'Super Admin', 'adminuser', 'passwordhash', 'pending')");

        $result = $this->userManager->updateUserStatus(1, 'admin', 'approve');
        $this->assertTrue($result);

        $user = $this->userManager->getUserById('admin', 1);
        $this->assertEquals('approved', $user['status']);
    }

    public function testDeleteUser()
    {
        // Insert admin user
        $this->pdo->exec("INSERT INTO admin (name, email, contact, role, user_name, hash_password, status) VALUES ('Admin User', 'admin@example.com', '1234567890', 'Super Admin', 'adminuser', 'passwordhash', 'pending')");

        $response = $this->userManager->deleteUser('admin', 1);
        $this->assertArrayHasKey('success', $response);
        $this->assertStringContainsString('User deleted successfully', $response['success']);

        $user = $this->userManager->getUserById('admin', 1);
        $this->assertNull($user);
    }

    public function testSearchUsers()
    {
        // Insert test users
        $this->pdo->exec("INSERT INTO admin (name, email, contact, role, user_name, hash_password, status) VALUES ('Admin User', 'admin@example.com', '', 'Super Admin', 'adminuser', 'passwordhash', 'approved')");
        $this->pdo->exec("INSERT INTO teacher (name, email, qualification, photo, description, user_name, hash_password, admin_id, code, status) VALUES ('Teacher User', 'teacher@example.com', 'Masters', NULL, NULL, 'teacheruser', 'passwordhash', 1, 'T123', 'approved')");
        $this->pdo->exec("INSERT INTO student (name, email, class, is_on_scholarship, user_name, hash_password, admin_id, status) VALUES ('Student User', 'student@example.com', '10th Grade', 1, 'studentuser', 'passwordhash', 1, 'approved')");

        $results = $this->userManager->searchUsers('User', 'all');
        $this->assertArrayHasKey('admins', $results);
        $this->assertArrayHasKey('teachers', $results);
        $this->assertArrayHasKey('students', $results);

        $this->assertCount(1, $results['admins']);
        $this->assertCount(1, $results['teachers']);
        $this->assertCount(1, $results['students']);
    }

    protected function tearDown(): void
    {
        $this->pdo = null;
    }
}

?>

