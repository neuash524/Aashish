<?php
include 'session.php';
include 'db.php'; 

/*require 'authentication_middleware.php';
allowOnlyUserType('admin');
allowOnlyRole(['Course Admin']);**/
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin','Department Admin', 'Course Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();

// Fetch all courses
$coursesStmt = $pdo->query("SELECT code, name FROM course ORDER BY code");
$courses = $coursesStmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = $_POST['code'] ?? '';

    if ($code) {
        // Fetch current status of the course
        $stmt = $pdo->prepare("SELECT is_active FROM course WHERE code = :code");
        $stmt->execute([':code' => $code]);
        $course = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$course) {
            $_SESSION['message'] = "<p style='color:red;font-size:2rem'> Invalid course selected.</p>";
            header("Location: status.php");
            exit();
        }

        if (isset($_POST['activate'])) {
            if ($course['is_active']) {
                $_SESSION['message'] = "<p style='color:orange;font-size:2rem'> Course is already active.</p>";
            } else {
                try {
                    $updateStmt = $pdo->prepare("UPDATE course SET is_active = 1 WHERE code = :code");
                    $updateStmt->execute([':code' => $code]);
                    $_SESSION['message'] = "<p style='color:white;font-size:2rem'> Course activated successfully.</p>";
                } catch (PDOException $e) {
                    $_SESSION['message'] = "<p style='color:red;font-size:2rem'> Error activating course: " . $e->getMessage() . "</p>";
                }
            }
        } elseif (isset($_POST['deactivate'])) {
            if (!$course['is_active']) {
                $_SESSION['message'] = "<p style='color:orange;font-size:2rem'>Course is already inactive.</p>";
            } else {
                try {
                    $updateStmt = $pdo->prepare("UPDATE course SET is_active = 0 WHERE code = :code");
                    $updateStmt->execute([':code' => $code]);
                    $_SESSION['message'] = "<p style='color:orange;font-size:2rem'> Course deactivated successfully.</p>";
                } catch (PDOException $e) {
                    $_SESSION['message'] = "<p style='color:red;font-size:2rem'> Error deactivating course: " . $e->getMessage() . "</p>";
                }
            }
        }
    } else {
        $_SESSION['message'] = "<p style='color:orange;font-size:2rem'> Please select a course.</p>";
    }

    header("Location: status.php");
    exit();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Course status</title> <!-- Display page title -->
   <link rel="stylesheet" href="homepage.css"> <!-- Link to the homepage CSS -->
   <link href="img/logoo.png" rel="icon" type="image/webp"> <!-- Set favicon for the page -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome icons -->
   <script src="Navigation.js" defer></script> <!-- External JavaScript for navigation -->
</head>
<style>
.container {
    max-width: 600px;
    width: 90%;
    margin: 60px auto;
    background-color: rgba(255, 255, 255, 0.95);
    padding: 30px 25px;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    color: #003366;
}

.container h2 {
    text-align: center;
    font-size: 2rem;
    margin-bottom: 20px;
}

form {
    display: flex;
    flex-direction: column;
    gap: 20px;
    margin-bottom: 15px;
    font-weight: bold;
    color: #003366;
}


input, select,
button {
    padding: 12px;
    font-size: 1rem;
    border-radius: 6px;
    border: 1px solid #ccc;
    width: 100%;
    box-sizing: border-box;
}

button {
    background-color: #003366;
    color: white;
    border: none;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #001f4d;
}

.deactivate-btn {
    background-color: #dc3545;
    color: white;
}

.deactivate-btn:hover {
    background-color: #b52a3a;
}

/* Flash message styling */
.message {
    text-align: center;
    font-weight: bold;
    padding: 10px;
    border-radius: 6px;
    margin: 20px auto;
    width: 90%;
    max-width: 800px;
}

.message.success {
    background-color: #28a745;
    color: white;
}

.message.error {
    background-color: #dc3545;
    color: white;
}


.back-btn {
  display: inline-block;
  padding: 12px 24px;
  background: blue;
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background 0.3s ease, transform 0.2s ease;
  box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.back-btn:hover {
  background: blue;
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
}


/* Mobile Responsiveness */
@media (max-width: 768px) {
    .container {
        padding: 20px 15px;
    }

    .container h2 {
        font-size: 1.5rem;
    }

    input,
    button {
        font-size: 0.95rem;
        padding: 10px;
    }

    nav img {
        width: 100px;
        height: 100px;
    }

    .nav-links {
        width: 160px;
    }

    .message {
        font-size: 1rem;
    }
}

</style>
</head>
<body>
<section class="header">  
    <nav>
      <img src="img/logoo.png" alt="Logo" class="logo"> <!-- Display the university logo -->
   
      <div class="nav-links" id="navLinks">
         <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i> <!-- Close menu icon -->
         <ul>
            <li><a href="homepage.php">HOME</a></li> <!-- Home link -->
            <li><a href="courses.php">COURSE</a></li> <!-- Contact link -->
            <li><a href="staff.php">STAFF</a></li> <!-- About link -->
            <li><a href="login.php">LOG IN</a></li> <!-- Administrator link -->
         </ul>
      </div>
      <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i> <!-- Open menu icon -->
    </nav>
 <!-- Display Flash Messages -->
 <?php

if (isset($_SESSION['message'])) {
    echo $_SESSION['message'];
    unset($_SESSION['message']);
}
?>
 <div class =  "container">

<h2>Update Course Status</h2><br>
  <form method="POST">
        <input type="hidden" name="action" value="status">
        
        <label>Course:</label>
        <select name="code" required>
            <option value="">-- Select Course --</option>
            <?php foreach ($courses as $course): ?>
                <option value="<?= htmlspecialchars($course['code']) ?>">
                    <?= htmlspecialchars($course['code'] . ' - ' . $course['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    <button type="submit" name="activate" onclick="return checkCourseSelectedAndConfirm('activate')">Activate</button>
    <button  typr="submit"class="deactivate-btn" name="deactivate" onclick="return checkCourseSelectedAndConfirm('deactivate')">Deactivate</button>
</form>



<div style="display: flex; justify-content:center">
        <a href="course_dashboard.php" class="back-btn"> Back</a>
    </div>
   </div> 
</section>

<!-- JavaScript for toggling the menu visibility -->
   <script>
      var navLinks = document.getElementById("navLinks");
      function openMenu() {
         navLinks.style.right = "0"; // Open the menu by setting the style to right = 0
      }
      function closeMenu() {
         navLinks.style.right = "-200px"; // Close the menu by shifting it off-screen
      }
   </script>
   <script>
function checkCourseSelectedAndConfirm(action) {
    const select = document.querySelector('select[name="code"]');
    if (!select.value) {
        alert('Please select a course first.');
        return false;
    }
    let message = '';
    if (action === 'activate') {
        message = 'Are you sure you want to activate this course?';
    } else if (action === 'deactivate') {
        message = 'Are you sure you want to deactivate this course?';
    }
    return confirm(message);
}
</script>

   
   

</body>
</html>
