<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin','Department Admin','Course Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();

// Connect to the database using PDO
try {
    $pdo = new PDO("mysql:host=localhost;dbname=student_record_system", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}   
    $courses = $pdo->query("SELECT * FROM course")->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course List</title> <!-- Display page title -->
    <link rel="stylesheet" href="homepage.css"> <!-- Link to the homepage CSS -->
    <link href="img/logoo.png" rel="icon" type="image/webp"> <!-- Set favicon for the page -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome icons -->
    <script src="Navigation.js" defer></script> <!-- External JavaScript for navigation -->
</head>
<style>
/* Base styles for all screen sizes */
body {
    font-family: 'Segoe UI', sans-serif;
    background-color: #f4f4f9;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

h1{
    text-align: center;
    font-size: 2.5rem;
    margin-bottom: 20px;
     color: rgb(147, 212, 157);
}


/* Grid for course cards */
.course-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(260px, 260px));
    gap: 20px;
    padding: 0 10px;
    margin: 0 auto;
    max-width: 1200px;
    justify-content: center;
}

/* Individual course card */
.course-card {
    background-color: #ffffff;
    border-radius: 12px;
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
    padding: 25px;
    text-align: center;
    transition: transform 0.2s, box-shadow 0.2s;
}

.course-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
}

.course-card a {
    text-decoration: none;
    color: #003366;
    font-size: 1.2rem;
    font-weight: bold;
    display: block;
    word-wrap: break-word;
}

.course-card a:hover {
    color: #0055cc;
}

/* Responsive layout for extra flexibility */
.grid-container {
    display: grid;
    grid-template-columns: 1fr;
    gap: 20px;
    padding: 10px;
}

.back-btn {
    display: inline-block;
    margin: 10px 0;
    padding: 10px 20px;
    text-align:center;
    color:white;
    background: #007bff; 
    text-decoration: none;
    border-radius: 5px;
    width:150px;
}

.back-btn:hover {
    text-decoration: underline;
}

/* Medium screens: 2 columns */
@media (min-width: 600px) {
    .grid-container {
        grid-template-columns: repeat(2, 1fr);
    }

    form {
            justify-content: center;
}
    }


/* Large screens: 3 columns */
@media (min-width: 900px) {
    .grid-container {
        grid-template-columns: repeat(3, 1fr);
    }
}

/* Mobile tweaks */
@media (max-width: 480px) {
    h1, h2 {
        font-size: 1.8rem;
    }

    form {
        flex-direction: column;
        align-items: stretch;
        text-align: center;
    }

}
   
</style>

</head>

<body>

<section class="header">  
    <nav>
      <img src="img/logoo.png" alt="Logo" class="logo"> <!-- Display the university logo -->

  <div class="nav-links" id="navLinks">
     <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i> <!-- Close menu icon -->
     <ul>
        <li><a href="homepage.php">HOME</a></li> <!-- Home link -->
        <li><a href="courses.php">COURSE</a></li> <!-- Contact link -->
        <li><a href="staff.php">STAFF</a></li> <!-- About link -->
        <li><a href="login.php">LOG IN</a></li> <!-- Administrator link -->
     </ul>
  </div>
  <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i> <!-- Open menu icon -->
</nav>
<h1>Available Courses</h1><br>

<div class="course-grid">
    <?php if (!empty($courses)): ?>
        <?php foreach ($courses as $row): ?>
            <div class="course-card">
                <?php if (!empty($row['image']) && file_exists($row['image'])): ?>
                    <img src="<?= htmlspecialchars($row['image']) ?>" alt="Course Image"
                         style="width:100%; height:150px; object-fit:cover; border-radius:8px; margin-bottom:10px;">
                <?php endif; ?>

                <a href="course_details1.php?code=<?= urlencode($row['code']) ?>">
                    <?= htmlspecialchars($row['code']) ?> - <?= htmlspecialchars($row['name']) ?>
                </a>
                <div>Type: <?= htmlspecialchars($row['type']) ?></div>
                <div>Active: <?= $row['is_active'] ? 'Yes' : 'No' ?></div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="text-align:center;">No courses available.</p>
    <?php endif; ?>
</div>
<div style="display: flex; justify-content:center">
        <a href="course_dashboard.php" class="back-btn"> Back</a>
    </div>
            </section>

<script>
    var navLinks = document.getElementById("navLinks");
    function openMenu() {
        navLinks.style.right = "0"; // Open the menu by setting the style to right = 0
    }
    function closeMenu() {
        navLinks.style.right = "-200px"; // Close the menu by shifting it off-screen
    }
</script>

</section>
</body>
</html>

