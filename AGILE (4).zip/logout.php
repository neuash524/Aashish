<?php
session_start();
require 'db.php';              // Make sure $pdo is available
require 'functions.php';      // Include logActivity definition

// Log the logout BEFORE destroying the session
if (isset($_SESSION['user_id'], $_SESSION['user_type'])) {
    logActivity($pdo, $_SESSION['user_id'], $_SESSION['user_type'], 'Logged out');
}

session_destroy();
header('Location: login.php');
exit;
?>
