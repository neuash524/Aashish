<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>About Us - Greenfield School</title>
  <link rel="stylesheet" href="homepage.css">
  <link href="img/logoo.png" rel="icon" type="image/webp"> <!-- Set favicon for the page -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome icons -->
   <script src="Navigation.js" defer></script> <!-- External JavaScript for navigation -->
  
  <style>
    
 .welcome {
  padding: 2rem;
  text-align: center;
   font-size: 1.5em;
 }

 .welcome p{
    font-size: 0.75em;
 }

 .welcome-text h2 {
    font-size: 2.5em;
  margin-bottom: 1rem;
  color:rgb(154, 212, 157);
 }

 .department-info {
  padding: 3rem 2rem;
  text-align: center;
  color: #fff;
 }

 .department-info h2 {
  font-size: 3.5rem;
  margin-bottom: 1.5rem;
 color:rgb(154, 212, 157);
 }

 .department-details  {
  width: 900px;
  height: auto;
  object-fit: cover;
  margin: 0 auto;
  text-align: left;
  font-size: 1.5rem;
  background-color: rgba(224, 193, 160, 0.9);
  padding: 1.5rem;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
 }
 .department-details p {
  font-size: 1.2rem ;
  font-family: 'Segoe UI', sans-serif;
 }
 .gallery {
  padding: 1rem 0; /* reduced vertical padding */
  background-color: rgba(224, 193, 160, 0.9);
  text-align: center;
  max-width: 900px; /* optional: limits width */
  margin: auto;     /* centers the section */
 }


 .gallery h2 {
  margin-bottom: 1rem;
  color: #2e7d32;
 }

 .gallery-images {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 1rem;
 }

 .gallery-images img {
  width: 250px;
  height: 180px;
  object-fit: cover;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.15);
  }
 .gallery img {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  border-radius: 10px;
 }

 .gallery img:hover {
  transform: scale(1.05);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
 }

 .school-image {
  display: flex;
  flex-direction: column;
  align-items: center; /* centers the content horizontally */
  padding: 2rem;
  width: 100%;
 }

 .school-image h2 {
  margin-bottom: 1rem;
  color: #2e7d32;
  text-align: center;
 }

 .school-image img {
  width: 90%;
  max-width: 800px;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.1);
   margin: 0 auto; /* ensures centering as fallback */
 }
 @media (max-width: 768px) {
  .welcome-text h2 {
    font-size: 1.8em; /* or smaller if needed */
  }

  .welcome p {
    font-size: 0.9em;
    padding: 0 1rem;
  }
  .department-info h2 {
    font-size: 2rem; /* Decrease heading size */
  }

  .department-details {
    font-size: 1rem; /* Decrease paragraph text size */
    padding: 1rem;
    width: 90%; /* Make it responsive */
  }

  .department-details p {
    font-size: 1rem; /* Ensure paragraph font scales too */
  }
 }


    </style>
</head>
<body>


<section class="header">  
   <nav>
      <img src="img/logoo.png" alt="Logo" class="logo"> <!-- Display the university logo -->
   
      <div class="nav-links" id="navLinks">
         <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i> <!-- Close menu icon -->
         <ul>
            <li><a href="homepage.php">HOME</a></li> <!-- Home link -->
            <li><a href="course.php">COURSE</a></li> <!-- Contact link -->
            <li><a href="staff.php">STAFF</a></li> <!-- About link -->
            <li><a href="login.php">LOG IN</a></li> <!-- Administrator link -->
         </ul>
      </div>
      <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i> <!-- Open menu icon -->
   </nav>
   


  <!-- Welcome Section -->
  <section class="welcome">
    <div class="welcome-text">
      <h2>Welcome to Greenfield School</h2>
      <p>
        At Greenfield School, we believe in nurturing minds and building futures. We provide a vibrant academic environment where students are encouraged to explore, innovate, and grow. Our holistic approach combines strong academics with character development, ensuring that each child not only excels intellectually but also grows into a responsible and compassionate individual. With dedicated educators, modern facilities, and a focus on both personal and academic success, Greenfield School prepares students to thrive in a dynamic and ever-changing world.
      </p>
    </div>
  </section>

   <!-- School Image Section -->
  <section class="school-image">
    <h2>Our School</h2>
    <img src="img/build.jpg" alt="School Building">
  </section>

  <!-- Department Info Section -->
<section class="department-info">
  <h2>Department</h2>
  <div class="department-details">
    <p> Arts and Media</p>
    <p>The Arts and Media Department focuses on creative expression, visual storytelling, and media literacy. It offers a diverse range of courses designed to nurture artistic talent and communication skills.</p>
    <p><strong>Courses Offered:</strong> Visual Arts, Film Studies, Media Production, Photography, Graphic Design, Creative Writing, Performing Arts</p>
  </div>
</section>


    
  <!-- Student Life Gallery -->
    <section class="gallery">
    <h2>Student Life at Greenfield</h2>
    <div class="gallery-images">
      <img src="img/student1.jpg" alt="Student 1">
      <img src="img/student2.jpg" alt="Student 2">
      <img src="img/student3.jpg" alt="Student 3">
    </div>
  </section>

 


  <!-- Footer section with contact information -->
  <footer>
      <section class="about-contact">
         <h2>Contact Us</h2>
         <div class="contact-container">
            <div class="contact-details">
               <p>📍 Sankt Petri Passage 10, 1165 København, Denmark</p> <!-- Address -->
               <p>📧 Email: contact@greenfieldschool.com</p> <!-- Email -->
               <p>📞 Phone: +45 123 5678</p> <!-- Phone number -->
            </div>
         </div>
      </section>
   </footer>
      

   <!-- JavaScript for toggling the menu visibility -->
   <script>
      var navLinks = document.getElementById("navLinks");
      function openMenu() {
         navLinks.style.right = "0"; // Open the menu by setting the style to right = 0
      }
      function closeMenu() {
         navLinks.style.right = "-200px"; // Close the menu by shifting it off-screen
      }
   </script>

</body>
</html>