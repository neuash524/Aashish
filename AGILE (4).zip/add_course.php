<?php
include 'session.php';
include 'db.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin','Department Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();



// Fetch all unique course types
$typeStmt = $pdo->query("SELECT DISTINCT type FROM course ORDER BY type");
$types = $typeStmt->fetchAll(PDO::FETCH_ASSOC);

if (isset($_POST['add_course'])) {
    try {
        // Check if course code already exists
        $check = $pdo->prepare("SELECT 1 FROM course WHERE code = :code");
        $check->execute([':code' => $_POST['code']]);

        if ($check->fetch()) {
            $_SESSION['message'] = "<p style='color:red;font-size:2rem'>Course code already exists.</p>";
        } else {
            // Fetch a Course Admin's ID from admin table
            $adminStmt = $pdo->prepare("SELECT admin_id FROM admin WHERE role = 'Course Admin' LIMIT 1");
            $adminStmt->execute();
            $admin = $adminStmt->fetch(PDO::FETCH_ASSOC);
            logActivity($pdo, $_SESSION['user_id'], 'admin', 'Created course', "Course Name: $name, Code: $code");


            if (!$admin) {
                $_SESSION['message'] = "<p style='color:red;font-size:2rem'>No Course Admin found in admin table.</p>";
            } else {
                $adminId = $admin['admin_id'];

                // Handle file upload
                $targetDir = "img/";
                $fileName = basename($_FILES["image"]["name"]);
                $targetFilePath = $targetDir . $fileName;
                $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

                // Validate file type
                $validTypes = ['jpg', 'jpeg', 'png', 'webp'];
                if (in_array($fileType, $validTypes)) {
                    if (!is_dir($targetDir)) {
                        mkdir($targetDir, 0755, true);
                    }

                    if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
                        // Insert course into database
                        $stmt = $pdo->prepare("
                            INSERT INTO course 
                            (code, name, description, type, credits, is_active, image, admin_id) 
                            VALUES 
                            (:code, :name, :description, :type, :credits, 1, :image, :admin_id)
                        ");
                        $stmt->execute([
                            ':code' => $_POST['code'],
                            ':name' => $_POST['name'],
                            ':description' => $_POST['description'],
                            ':type' => $_POST['type'],
                            ':credits' => $_POST['credits'],
                            ':image' => $targetFilePath,
                            ':admin_id' => $adminId
                        ]);
                        $_SESSION['message'] = "<p style='color:white;font-size:2rem;'>Course added successfully.</p>";
                    }
                } else {
                    $_SESSION['message'] = "<p style='color:red;font-size:2rem;'>Invalid image format.</p>";
                }
            }
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = "<p style='color:red;'>Error: " . $e->getMessage() . "</p>";
    }

    header("Location: add_course.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Add Course</title> <!-- Display page title -->
   <link rel="stylesheet" href="homepage.css"> <!-- Link to the homepage CSS -->
   <link href="img/logoo.png" rel="icon" type="image/webp"> <!-- Set favicon for the page -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome icons -->
   <script src="Navigation.js" defer></script> <!-- External JavaScript for navigation -->
</head>
    <style>
 /* Add Course Form Container */
 .container {
    max-width: 500px; 
    width: 90%;
    margin: 30px auto;
    background-color: rgba(255, 255, 255, 0.95);
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 6px 10px rgba(0, 0, 0, 0.1);
    color: #003366;
 
 }

.container h2 {
    text-align: center;
    font-size: 2rem;
    margin-bottom: 20px;
}

form label {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-bottom: 15px;
    font-weight: bold;
    color: #003366;
}


input, select, button {
    padding: 12px;
    font-size: 1rem;
    border-radius: 6px;
    border: 1px solid #ccc;
    width: 100%;
    box-sizing: border-box;
}

button {
    background-color: #003366;
    color: white;
    border: none;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #001f4d;
}

.footer {
  width: 100%;
  text-align: center;
  padding: 0;
  position: relative;
  bottom: 0;
}
.back-btn {
  display: inline-block;
  padding: 12px 24px;
  background: blue;
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background 0.3s ease, transform 0.2s ease;
  box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.back-btn:hover {
  background: blue;
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
}

/* Mobile Responsiveness */
@media (max-width: 768px) {
    .container {
        padding: 20px 15px;
    }

    .container h2 {
        font-size: 1.5rem;
    }

    input,
    button {
        font-size: 0.95rem;
        padding: 10px;
    }

    nav img {
        width: 100px;
        height: 100px;
    }

    .nav-links {
        width: 160px;
    }

    .message {
        font-size: 1rem;
    }
}


</style>
</head>
<body>

<section class="header">  
    <nav>
      <img src="img/logoo.png" alt="Logo" class="logo"> <!-- Display the university logo -->
   
      <div class="nav-links" id="navLinks">
         <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i> <!-- Close menu icon -->
         <ul>
            <li><a href="homepage.php">HOME</a></li> <!-- Home link -->
            <li><a href="courses.php">COURSE</a></li> <!-- Contact link -->
            <li><a href="staff.php">STAFF</a></li> <!-- About link -->
            <li><a href="login.php">LOG IN</a></li> <!-- Administrator link -->
         </ul>
      </div>
      <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i> <!-- Open menu icon -->
    </nav>

<?php

if (isset($_SESSION['message'])) {
    echo $_SESSION['message'];
    unset($_SESSION['message']);
}
?>
 <div class =  "container">

<h2>Add New Course</h2>

<form method="POST" enctype="multipart/form-data">
    <label> Course Code: <input name="code" required></label><br>
    <label> Course Name: <textarea name="name" required></textarea></label><br>
    <label>Image: <input type="file" name="image" required></label><br>
    <label>Description:<textarea name="description"required></textarea></label><br>
       
<label>Type:</label>
<select name="type" required>
    <option value="">-- Select Type --</option>
    <?php foreach ($types as $type): ?>
        <option value="<?= htmlspecialchars($type['type']) ?>">
            <?= htmlspecialchars($type['type']) ?>
        </option>
    <?php endforeach; ?>
</select><br>

    <label>Credits: <input name="credits" type="text" required></label><br>

    <button name="add_course">Add Course</button><br>
</form>

<footer class="footer">
  <a href="course_dashboard.php" class="back-btn"> Back</a>
</footer>
</section>

<!-- JavaScript for toggling the menu visibility -->
   <script>
      var navLinks = document.getElementById("navLinks");
      function openMenu() {
         navLinks.style.right = "0"; // Open the menu by setting the style to right = 0
      }
      function closeMenu() {
         navLinks.style.right = "-200px"; // Close the menu by shifting it off-screen
      }
   </script>


</body>
</html>
