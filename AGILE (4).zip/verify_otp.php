<?php
session_start();

// Redirect to login if no user session or OTP not set
if (empty($_SESSION['user_id']) || empty($_SESSION['otp'])) {
    header('Location: login.php?error=Please login first.');
    exit;
}

// Check if OTP expired
if (time() > ($_SESSION['otp_expires'] ?? 0)) {
    // Clear OTP data and user session for security
    unset($_SESSION['otp'], $_SESSION['otp_expires'], $_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['user_type'], $_SESSION['role'], $_SESSION['last_activity']);
    session_destroy();
    header('Location: login.php?error=OTP expired, please login again.');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $enteredOtp = trim($_POST['otp'] ?? '');

    if ($enteredOtp === $_SESSION['otp']) {
        // OTP is correct

        // Mark OTP verified
        $_SESSION['otp_verified'] = true;

        // Remove OTP info for security
        unset($_SESSION['otp'], $_SESSION['otp_expires']);

        // Regenerate session ID to prevent fixation
        session_regenerate_id(true);

        // Redirect to the dashboard or main page
        header('Location: all_users.php');
        exit;
    } else {
        $error = "Invalid OTP. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>OTP Verification</title>
</head>
<body>
    <h2>OTP Verification</h2>
    <?php if ($error) echo "<p style='color:red;'>$error</p>"; ?>
    <p><strong>Your OTP (for simulation): <?php echo htmlspecialchars($_SESSION['otp']); ?></strong></p>
    <form method="post" action="">
        <label for="otp">Enter OTP:</label>
        <input type="text" name="otp" id="otp" required maxlength="6" pattern="\d{6}" autofocus />
        <button type="submit">Verify</button>
    </form>
</body>
</html>
