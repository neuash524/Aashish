<?php
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'db.php';

$user_id = $_SESSION['user_id'] ?? null;
$user_type = $_SESSION['user_type'] ?? null;

if (!$user_id || !$user_type) {
    header("Location: login.php");
    exit;
}

$students = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $user_type === 'admin' && isset($_POST['delete_student_id'])) {
    $delete_id = $_POST['delete_student_id'];
    $stmt = $pdo->prepare("DELETE FROM student WHERE student_id = ?");
    $stmt->execute([$delete_id]);
}

if ($user_type === 'student') {
    allowOnlyUserType('student');
    $stmt = $pdo->prepare("SELECT student_id, name, email, class, admin_id, is_on_scholarship FROM student WHERE student_id = ?");
    $stmt->execute([$user_id]);
    $students[] = $stmt->fetch(PDO::FETCH_ASSOC);
} elseif ($user_type === 'admin') {
    allowOnlyUserType('admin');
    $stmt = $pdo->prepare("SELECT student_id, name, email, class, admin_id, is_on_scholarship FROM student");
    $stmt->execute();
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= $user_type === 'admin' ? 'All Students' : 'Student Profile' ?></title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-image: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7)), url("img/build.jpg");
      background-size: cover;
      min-height: 100vh;
      margin: 0;
      padding: 0;
    }

    h2 {
      text-align: center;
      font-size: 36px;
      margin: 90px 0 30px;
      color: #fff;
    }

    .student-list {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 20px;
      padding: 0 20px;
    }

    .profile {
      background: white;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
      position: relative;
    }

    .profile p {
      margin: 8px 0;
      font-size: 16px;
    }

    .profile strong {
      color: #555;
    }

    .profile span {
      color: #007B55;
      font-weight: bold;
    }

   
    .button-wrapper {
  display: flex;
  justify-content: flex-end;
  margin-top: 16px;
}

.delete-btn {
  background-color: #c62828;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  cursor: pointer;
  font-weight: bold;
}

    .delete-btn:hover {
      background-color: #b71c1c;
    }

    .back-btn {
      display: block;
      width: fit-content;
      margin: 40px auto;
      background-color: #333;
      color: white;
      padding: 12px 20px;
      text-decoration: none;
      border-radius: 8px;
      font-weight: bold;
    }

    .back-btn:hover {
      background-color: #000;
    }

    .header {
      width: 100%;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      position: absolute;
      top: 10px;
      left: 10px;
      z-index: 10;
    }

    .logo {
      height: 60px;
      width: auto;
    }

    #confirmModal {
      display: none;
      position: fixed;
      top: 0; left: 0;
      width: 100%; height: 100%;
      background-color: rgba(0,0,0,0.6);
      justify-content: center;
      align-items: center;
      z-index: 1000;
    }

    .modal-content {
      background: white;
      padding: 30px 20px;
      border-radius: 10px;
      text-align: center;
      max-width: 400px;
      width: 90%;
    }

    .modal-content button {
      padding: 10px 16px;
      border: none;
      border-radius: 5px;
      margin: 10px;
      font-weight: bold;
      cursor: pointer;
    }

    .modal-content .confirm {
      background-color: #d32f2f;
      color: white;
    }

    .modal-content .cancel {
      background-color: #999;
      color: white;
    }
  </style>
</head>
<body>
  <div class="header">
    <img src="img/logoo.png" alt="School Logo" class="logo">
  </div>

  <h2><?= $user_type === 'admin' ? 'All Registered Students' : 'Welcome, ' . htmlspecialchars($students[0]['name']) ?></h2>

  <div class="student-list">
    <?php foreach ($students as $student): ?>
      <div class="profile">
        <p><strong>ID:</strong> <span><?= htmlspecialchars($student['student_id']) ?></span></p>
        <p><strong>Name:</strong> <span><?= htmlspecialchars($student['name']) ?></span></p>
        <p><strong>Email:</strong> <span><?= htmlspecialchars($student['email']) ?></span></p>
        <p><strong>Scholarship:</strong> <span><?= $student['is_on_scholarship'] ? 'Yes' : 'No' ?></span></p>
        <p><strong>Class:</strong> <span><?= htmlspecialchars($student['class']) ?></span></p>
        <p><strong>Admin ID:</strong> <span><?= htmlspecialchars($student['admin_id']) ?></span></p>

        <?php if ($user_type === 'admin'): ?>
          <div class="button-wrapper">
  <form method="POST" class="delete-form">
    <input type="hidden" name="delete_student_id" value="<?= htmlspecialchars($student['student_id']) ?>">
    <button type="button" class="delete-btn" onclick="confirmDelete(this)">Delete</button>
  </form>
</div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>

  <a href="student_dashboard.php" class="back-btn">⬅ Back to Student Dashboard</a>

  <!-- Modal -->
  <div id="confirmModal">
    <div class="modal-content">
      <p>Are you sure you want to delete this student?</p>
      <button class="confirm" onclick="submitDelete()">Yes, Delete</button>
      <button class="cancel" onclick="closeModal()">Cancel</button>
    </div>
  </div>

  <script>
    let activeForm = null;

    function confirmDelete(button) {
      activeForm = button.closest('form');
      document.getElementById('confirmModal').style.display = 'flex';
    }

    function closeModal() {
      document.getElementById('confirmModal').style.display = 'none';
      activeForm = null;
    }

    function submitDelete() {
      if (activeForm) activeForm.submit();
    }
  </script>
</body>
</html>
