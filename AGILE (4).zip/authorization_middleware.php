<?php
// authorization_middleware.php
/*session_start();//

/**
 * Allow access only if the user's role is in the allowed list.
 *
 * @param array $allowedRoles Array of allowed role names (e.g., ['Course Admin', 'Coordinator'])
 */
function allowRole(array $allowedRoles) {
    if (!isset($_SESSION['role'])) {
        header("Location: login.php?error=Please login first");
        exit;
    }

    $userRole = trim(strtolower($_SESSION['role']));
    $allowedRolesNormalized = array_map(fn($r) => trim(strtolower($r)), $allowedRoles);

    if (!in_array($userRole, $allowedRolesNormalized)) {
        echo "<h2 style='color:red'>Access Denied: This page is only accessible to specific roles.</h2>";
        exit;
    }
}
?>