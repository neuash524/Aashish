<?php
// api_list_users.php
header('Content-Type: application/json');

try {
    $pdo = new PDO('mysql:host=localhost;dbname=student_record_system;charset=utf8mb4', 'root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'DB connection failed: ' . $e->getMessage()]);
    exit;
}

require 'UserManager.php';

try {
    $userManager = new UserManager($pdo);
    $role = $_GET['role'] ?? '';

    if (!in_array($role, ['admin', 'teacher', 'student'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid or missing role parameter']);
        exit;
    }

    switch ($role) {
        case 'admin':
            $users = $userManager->getAdmins();
            break;
        case 'teacher':
            $users = $userManager->getTeachers();
            break;
        case 'student':
            $users = $userManager->getStudents();
            break;
    }

    echo json_encode(['success' => true, 'data' => $users]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>