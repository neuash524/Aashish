<?php
// sanitize_input_middleware.php

function sanitizeArray(array &$inputArray) {
    foreach ($inputArray as $key => $value) {
        if (is_array($value)) {
            sanitizeArray($value);
        } else {
            $inputArray[$key] = htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
        }
    }
}

// Sanitize global inputs
sanitizeArray($_GET);
sanitizeArray($_POST);
//sanitizeArray($_REQUEST);
?>