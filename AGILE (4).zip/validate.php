<?php
session_start();
include 'sanitize_input_middleware.php'; // optional, sanitize inputs

// Get OTP entered by user
$enteredOtp = $_POST['otp'] ?? '';

// Get OTP and expiration from session
$expectedOtp = $_SESSION['otp'] ?? null;
$expiresAt = $_SESSION['otp_expires'] ?? 0;

// Check if OTP is expired
if (!$expectedOtp || time() > $expiresAt) {
    session_destroy();
    die("OTP expired or invalid session. Please login again.");
}

// Validate OTP
if ($enteredOtp === $expectedOtp) {
    // OTP valid — set final session variables
    $_SESSION['user_id'] = $_SESSION['temp_user']['id'];
    $_SESSION['user_name'] = $_SESSION['temp_user']['name'];
    $_SESSION['user_type'] = $_SESSION['temp_user']['type'];
    $_SESSION['role'] = $_SESSION['temp_user']['role'];
    $_SESSION['last_activity'] = time();

    // Clear temp and OTP data
    unset($_SESSION['otp'], $_SESSION['otp_expires'], $_SESSION['temp_user']);

    // Redirect to dashboard or protected page
    header('Location: all_users.php');
    exit;
} else {
    // OTP invalid
    echo "Invalid OTP entered. <a href='login.php'>Try again</a>";
}

/*session_start();

if (empty($_SESSION['user_id']) || empty($_SESSION['otp_verified'])) {
    header('Location: login.php?error=Please login and verify OTP first.');
    exit;
}*/
