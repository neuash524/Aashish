<?php
// session_timeout_middleware.php

function checkSessionTimeout(int $timeoutDuration = 900, string $redirectUrl = 'login.php') {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (isset($_SESSION['last_activity'])) {
        $inactive = time() - $_SESSION['last_activity'];

        if ($inactive > $timeoutDuration) {
            session_unset();
            session_destroy();

            // Redirect with optional message
            $errorMsg = urlencode("Session expired. Please login again.");
            header("Location: {$redirectUrl}?error={$errorMsg}");
            exit();
        }
    }

    // Update last activity timestamp
    $_SESSION['last_activity'] = time();
}
?>