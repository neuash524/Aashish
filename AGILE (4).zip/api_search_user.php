<?php
header('Content-Type: application/json');
require_once 'UserManager.php'; // Adjust the path as needed

try {
    $pdo = new PDO('mysql:host=localhost;dbname=student_record_system;charset=utf8', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}
$userManager = new UserManager($pdo);

// Get query parameters q and role
$q = $_GET['q'] ?? '';
$role = $_GET['role'] ?? 'all';

// Validate input
if (empty($q)) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing search query parameter "q".'
    ]);
    exit;
}

// Validate role
$validRoles = ['admin', 'teacher', 'student', 'all'];
if (!in_array($role, $validRoles)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid role parameter.'
    ]);
    exit;
}

try {
    $results = $userManager->searchUsers($q, $role);

    echo json_encode([
        'success' => true,
        'data' => $results
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

?>