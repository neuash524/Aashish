<?php
session_start();
require 'db.php';
require 'functions.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();


$searchTerm = '';  // Prevents undefined variable warning
$role = 'all';
$results = [];

require_once 'UserManager.php';

$userManager = new UserManager($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' || isset($_GET['search'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $searchTerm = trim($_POST['search'] ?? '');
        $role = $_POST['role'] ?? 'all';
    } else {
        $searchTerm = trim($_GET['search'] ?? '');
        $role = $_GET['role'] ?? 'all';
    }

    try {
        $results = $userManager->searchUsers($searchTerm, $role);
    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
    }

    // ✅ Now $searchTerm is always defined before this point
    if (isset($_SESSION['user_id'], $_SESSION['user_type'])) {
        $logDetails = "Searched users with keyword: " . htmlspecialchars($searchTerm);
        if ($role !== 'all') {
            $logDetails .= " in role: $role";
        }
        logActivity(
            $pdo,
            $_SESSION['user_id'],
            $_SESSION['user_type'],
            'Search User',
            $logDetails
        );
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="userstyle.css">
  <title>USER MANAGEMENT</title>
</head>
<body>

<div class="header">
    <img src="img/logoo.png" alt="School Logo" class="logo">
    <div class="system-title"><strong>User Management System</strong></div>
</div>

<div class="dashboard-container">
    <div class="hamburger" onclick="toggleSidebar()">☰</div>
    <aside class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="homepage.php">Home</a></li>
            <li><a href="user_management.php">Manage Users</a></li>
            <li><a href="course.php">Courses</a></li>
            <li><a href="about.php">About Us</a></li>
        </ul>      
    </aside>

    <main class="main-content">
        <div class="form-box">
            <legend><strong>Search Users</strong></legend>
            <form method="post" action="">
                <input type="text" name="search" placeholder="Enter name or email" required value="<?= htmlspecialchars($searchTerm) ?>">
                
                <!-- Optional: Role selector -->
                <select name="role">
                    <option value="all" <?= $role === 'all' ? 'selected' : '' ?>>All Roles</option>
                    <option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>Admin</option>
                    <option value="teacher" <?= $role === 'teacher' ? 'selected' : '' ?>>Teacher</option>
                    <option value="student" <?= $role === 'student' ? 'selected' : '' ?>>Student</option>
                </select>
                
                <button type="submit">Search</button>
                <input type="hidden" name="search_submitted" value="1">
            </form>

            <?php if (!empty($searchTerm)): ?>
                <h3>Search Results for '<?= htmlspecialchars($searchTerm) ?>'</h3>

                <!-- Admin Results -->
                <?php if (!empty($results['admins'])): ?>
                    <h4>Admin Users</h4>
                    <table border="1" cellpadding="6">
                        <tr>
                            <th>ID</th><th>Name</th><th>Email</th><th>Contact</th><th>Role</th><th>Username</th>
                        </tr>
                        <?php foreach ($results['admins'] as $admin): ?>
                            <tr>
                                <td><?= htmlspecialchars($admin['admin_id']) ?></td>
                                <td><?= htmlspecialchars($admin['name']) ?></td>
                                <td><?= htmlspecialchars($admin['email']) ?></td>
                                <td><?= htmlspecialchars($admin['contact']) ?></td>
                                <td><?= htmlspecialchars($admin['role']) ?></td>
                                <td><?= htmlspecialchars($admin['user_name']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                <?php endif; ?>

                <!-- Teacher Results -->
                <?php if (!empty($results['teachers'])): ?>
                    <h4>Teacher Users</h4>
                    <table border="1" cellpadding="6">
                        <tr>
                            <th>ID</th><th>Name</th><th>Email</th><th>Qualification</th><th>Code</th><th>Username</th><th>Admin ID</th>
                        </tr>
                        <?php foreach ($results['teachers'] as $teacher): ?>
                            <tr>
                                <td><?= htmlspecialchars($teacher['teacher_id']) ?></td>
                                <td><?= htmlspecialchars($teacher['name']) ?></td>
                                <td><?= htmlspecialchars($teacher['email']) ?></td>
                                <td><?= htmlspecialchars($teacher['qualification']) ?></td>
                                <td><?= htmlspecialchars($teacher['code']) ?></td>
                                <td><?= htmlspecialchars($teacher['user_name']) ?></td>
                                <td><?= htmlspecialchars($teacher['admin_id']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                <?php endif; ?>

                <!-- Student Results -->
                <?php if (!empty($results['students'])): ?>
                    <h4>Student Users</h4>
                    <table border="1" cellpadding="6">
                        <tr>
                            <th>ID</th><th>Name</th><th>Email</th><th>Age</th><th>Gender</th><th>Contact</th><th>Class</th><th>Scholarship</th><th>Username</th><th>Admin ID</th>
                        </tr>
                        <?php foreach ($results['students'] as $student): ?>
                            <tr>
                                <td><?= htmlspecialchars($student['student_id']) ?></td>
                                <td><?= htmlspecialchars($student['name']) ?></td>
                                <td><?= htmlspecialchars($student['email']) ?></td>
                                <td><?= htmlspecialchars($student['age']) ?></td>
                                <td><?= htmlspecialchars($student['gender']) ?></td>
                                <td><?= htmlspecialchars($student['contact']) ?></td>
                                <td><?= htmlspecialchars($student['class']) ?></td>
                                <td><?= $student['is_on_scholarship'] ? "Yes" : "No" ?></td>
                                <td><?= htmlspecialchars($student['user_name']) ?></td>
                                <td><?= htmlspecialchars($student['admin_id']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                <?php endif; ?>

                <?php if (
                    empty($results['admins']) &&
                    empty($results['teachers']) &&
                    empty($results['students'])
                ): ?>
                    <p>No users found for '<?= htmlspecialchars($searchTerm) ?>'.</p>
                <?php endif; ?>
            <?php endif; ?>

            <br>
            <a href="user_management.php"><button>Go Back</button></a>
        </div>
    </main>
</div>

<script>
  if (performance.navigation.type === 1) {
    // Page was reloaded - clear form
    document.querySelector('form').reset();
  }
</script>

</body>
</html>
