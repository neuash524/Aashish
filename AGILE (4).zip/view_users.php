<?php
session_start();
require 'db.php';
require 'UserManager.php';
require 'functions.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();

$userManager = new UserManager($pdo);

try {
    $admins = $userManager->getAdmins();
    $teachers = $userManager->getTeachers();
    $students = $userManager->getStudents();
} catch (PDOException $e) {
    die("Database error: " . htmlspecialchars($e->getMessage()));
}
//  Log view activity
if (isset($_SESSION['user_id'], $_SESSION['user_type'])) {
    logActivity(
        $pdo,
        $_SESSION['user_id'],
        $_SESSION['user_type'],
        'View Users',
        'Viewed all users (admins, teachers, students)'
    );
}
?>

<!-- User List Tables -->
 <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="userstyle.css"> <!-- Link to the user CSS -->
  <title>USER MANAGEMENT</title>
  <style>
    /* Table base styling */
.table-wrapper {
  max-width: 1100px; /* wider than before */
  margin: 20px auto;
  overflow-x: auto;  /* keep horizontal scroll only if really needed */
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  background: white;
  border: 1px solid #ddd;
}

table {
  width: 100%;
  border-collapse: collapse;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  font-size: 14px;
  color: #333;
  background: linear-gradient(135deg, rgba(68, 175, 109, 0.2), rgba(200, 45, 211, 0.2));
}



thead tr {
  background: linear-gradient(135deg, rgba(68, 175, 109, 0.2), rgba(200, 45, 211, 0.2));
  font-weight: 600;
  text-transform: uppercase;
}

th, td {
  padding: 8px 12px;
  text-align: left;
  border-bottom: 1px solid #eee;
  vertical-align: middle;
  white-space: nowrap;
}

tbody tr:nth-child(even) {
  background-color: #f9f9f9;
}

tbody tr:hover {
  background-color: rgba(68, 175, 109, 0.1);
}

th:nth-child(1), td:nth-child(1) {
  width: 50px;
}

th:nth-child(4), td:nth-child(4),
th:nth-child(5), td:nth-child(5),
th:nth-child(7), td:nth-child(7),
th:nth-child(10), td:nth-child(10) {
  width: 70px;
}

td {
  max-width: 180px;
  overflow: hidden;
  text-overflow: ellipsis;
}

button {
  background-color: #44af6d;
  border: none;
  color: white;
  padding: 5px 10px;
  margin: 2px 0;
  border-radius: 4px;
  cursor: pointer;
  font-size: 13px;
  transition: background-color 0.3s ease;
}

button:hover {
  background-color: #c82dd3;
}


</style>
</head>
<body>

<div class="header">
        <img src="img/logoo.png" alt="School Logo" class="logo">
        <div class="system-title"><strong>User Management System</strong></div>
</div>

<div class="dashboard-container">
   <!-- Hamburger icon -->
    <div class="hamburger" onclick="toggleSidebar()">☰</div>
    <aside class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="homepage.php">Home</a></li>
            <li><a href="user_management.php">Manage Users</a></li>
            <li><a href="course.php">Courses</a></li>
            <li><a href="about.php">About Us</a></li>
        </ul>      
    </aside>

    <main class="main-content">

    <legend><strong>EXISTING USERS</strong></legend>

    <!-- Admin Table -->
    <h2>Admin Users</h2>
    <div class="table-wrapper">
    <table>
      <tr>
        <th>ID</th><th>Name</th><th>Email</th><th>Contact</th><th>Role</th><th>Username</th><th>Last Login</th><th>Status</th><th>Actions</th>
      </tr>
      <?php if (!empty($admins)): ?>
        <?php foreach ($admins as $admin): ?>
          <tr>
            <td><?= htmlspecialchars($admin['admin_id']) ?></td>
            <td><?= htmlspecialchars($admin['name']) ?></td>
            <td><?= htmlspecialchars($admin['email']) ?></td>
            <td><?= htmlspecialchars($admin['contact']) ?></td>
            <td><?= htmlspecialchars($admin['role']) ?></td>
            <td><?= htmlspecialchars($admin['user_name']) ?></td>
            <td><?= htmlspecialchars($admin['last_login']) ?></td>
            <td><?= htmlspecialchars($admin['status']) ?></td>
            <td>
             <a href="update_user.php?role=admin&admin_id=<?= $admin['admin_id'] ?>">
               <button>Update</button>
             </a>
             <a href="delete_user.php?role=admin&admin_id=<?= $admin['admin_id'] ?>" onclick="return confirm('Are you sure you want to delete this admin?')">
                <button>Delete</button>
             </a>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php else: ?>
        <tr><td colspan="9">No admins found.</td></tr>
      <?php endif; ?>
    </table>
      </div>

    <!-- Teacher Table -->
    <h2>Teacher Users</h2>
    <div class="table-wrapper">
    <table>
      <tr>
        <th>ID</th><th>Name</th><th>Email</th><th>Qualification</th><th>Username</th><th>Code</th><th>Admin ID</th><th>Status</th><th>Actions</th>
      </tr>
      <?php foreach ($teachers as $teacher): ?>
        <tr>
          <td><?= htmlspecialchars($teacher['teacher_id']) ?></td>
          <td><?= htmlspecialchars($teacher['name']) ?></td>
          <td><?= htmlspecialchars($teacher['email']) ?></td>
          <td><?= htmlspecialchars($teacher['qualification']) ?></td>
          <td><?= htmlspecialchars($teacher['user_name']) ?></td>
          <td><?= htmlspecialchars($teacher['code']) ?></td>
          <td><?= htmlspecialchars($teacher['admin_id']) ?></td>
          <td><?= htmlspecialchars($teacher['status']) ?></td>
          <td>
             <a href="update_user.php?role=teacher&teacher_id=<?= $teacher['teacher_id'] ?>">
             <button>Update</button>
             </a>
             <a href="delete_user.php?role=teacher&teacher_id=<?= $teacher['teacher_id'] ?>" onclick="return confirm('Are you sure you want to delete this teacher?')">
             <button>Delete</button>
             </a>
            </td>

        </tr>
      <?php endforeach; ?>
    </table>
      </div>

    <!-- Student Table -->
    <h2>Student Users</h2>
    <div class="table-wrapper">
    <table>
      <tr>
        <th>ID</th><th>Name</th><th>Email</th><th>Class</th><th>Scholarship</th><th>Username</th><th>Admin ID</th><th>Status</th><th>Actions</th>
      </tr>
      <?php foreach ($students as $student): ?>
        <tr>
          <td><?= htmlspecialchars($student['student_id']) ?></td>
          <td><?= htmlspecialchars($student['name']) ?></td>
          <td><?= htmlspecialchars($student['email']) ?></td>
          <td><?= htmlspecialchars($student['class']) ?></td>
          <td><?= $student['is_on_scholarship'] ? "Yes" : "No" ?></td>
          <td><?= htmlspecialchars($student['user_name']) ?></td>
          <td><?= htmlspecialchars($student['admin_id']) ?></td>
          <td><?= htmlspecialchars($student['status']) ?></td>
          <td>
  <a href="update_user.php?role=student&student_id=<?= $student['student_id'] ?>">
    <button>Update</button>
  </a>
  <a href="delete_user.php?role=student&student_id=<?= $student['student_id'] ?>" onclick="return confirm('Are you sure you want to delete this student?')">
    <button>Delete</button>
  </a>
</td>

        </tr>
      <?php endforeach; ?>
    </table>
    </div>
</div><br><br>
<a href="user_management.php"><button>Go Back</button></a>
</div>
</body>
</html>