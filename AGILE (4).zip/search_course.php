<?php
include 'session.php';
include 'db.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin','Department Admin','Course Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();

$courses = [];

// Handle search query
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['search'])) {
    $search = trim($_GET['search']);

    if ($search !== '') {
        $query = "SELECT * FROM course WHERE LOWER(code) = LOWER(:search_code) OR LOWER(name) = LOWER(:search_name)";
        $stmt = $pdo->prepare($query);
        $stmt->bindValue(':search_code', $search);
        $stmt->bindValue(':search_name', $search);
        $stmt->execute();
        $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (count($courses) === 0) {
            $_SESSION['message'] = " No courses found with given data.";
        } else {
            $_SESSION['courses'] = $courses;
        }
    } 

    // Redirect to prevent resubmission and reset form input
    header("Location: search_course.php");
    exit();
}

// Load session data after redirect
if (isset($_SESSION['courses'])) {
    $courses = $_SESSION['courses'];
    unset($_SESSION['courses']);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Search Course</title> <!-- Display page title -->
   <link rel="stylesheet" href="homepage.css"> <!-- Link to the homepage CSS -->
   <link href="img/logoo.png" rel="icon" type="image/webp"> <!-- Set favicon for the page -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome icons -->
   <script src="Navigation.js" defer></script> 
</head>
    <style>

        body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f0f2f5;
    margin: 0;
    padding: 0;
    background-image: linear-gradient(rgba(200, 45, 211, 0.7),rgba(68, 175, 109, 0.7) ), url("img/build.jpg"); 
    background-position:center;
    background-size: cover;
    position: relative;
}

        .search-form {
            text-align: center;
            margin-top: 30px;
            font-size: 2rem;
        }
        .search-form input[type="text"] {
            padding: 10px;
            font-size: 1rem;
            width: 300px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .search-form button {
            padding: 10px 20px;
            font-size: 1rem;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            margin-left: 10px;
            cursor: pointer;
        }
        .message {
            color: white;
            /*text-align: center;*/
            margin-top: 15px;
            font-size: 3rem;
        }

    .container {
    padding: 20px; /* Adds inner spacing */
    background-color: #ffffff; /* Optional: for clarity */
    border-radius: 12px;       /* Optional: for smooth corners */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1); /* Optional: for subtle shadow */
    max-width: 800px;          /* Optional: limits width for better readability */
    margin: 20px auto;         /* Center the container */

}
h2 {
    color: #003366;
    font-size: 1.75rem;
    margin-bottom: 20px;
    text-align: center;
}

.detail {
    margin: 10px 0;
    font-size: 1rem;
    padding:5px;
}

.detail strong {
    display: inline-block;
    min-width: 50px;
    color: #333;
}
.detail img {
    border-radius: 12px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    max-width: 100%;
    height: auto;
}
.back-btn {
  display: inline-block;
  padding: 12px 24px;
  background: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background 0.3s ease, transform 0.2s ease;
  box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.back-btn:hover {
  background: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
}
/* Responsive styles */
@media (min-width: 768px) {
    .container {
        max-width: 700px;
        
    }

    .detail {
        font-size: 1.1rem;
    }

    h2 {
        font-size: 2rem;
    }
}


    </style>
</head>
<body>
   <section class="header">  
    <nav>
      <img src="img/logoo.png" alt="Logo" class="logo"> <!-- Display the university logo -->
   
      <div class="nav-links" id="navLinks">
         <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i> <!-- Close menu icon -->
         <ul>
            <li><a href="homepage.php">HOME</a></li> <!-- Home link -->
            <li><a href="courses.php">COURSE</a></li> <!-- Contact link -->
            <li><a href="staff.php">STAFF</a></li> <!-- About link -->
            <li><a href="login.php">LOG IN</a></li> <!-- Administrator link -->
         </ul>
      </div>
      <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i> <!-- Open menu icon -->
    </nav>

<h1 style="text-align:center;">Search Courses</h1>

<?php if (isset($_SESSION['message'])): ?>
    <div class="message"><?= $_SESSION['message'] ?></div>
    <?php unset($_SESSION['message']); ?>
<?php endif; ?>


    <form method="GET" class="search-form">
        <div class="form-row">
        <input type="text" name="search" placeholder="Enter course name or code" value="" required>
        <button type="submit">Search</button>
    </form>
</div><br><br>


<?php if (!empty($courses)): ?>
   <div class="container">
        <?php foreach ($courses as $course): ?>
            <h2><?= htmlspecialchars($course['name']) ?></h2>
            
             <div class="detail">
            <?php if (!empty($course['image']) && file_exists($course['image'])): ?>
                <img src="<?= htmlspecialchars($course['image']) ?>" alt="Course Image" style="width:300px; height:auto; border-radius:12px; margin:auto;">
            <?php endif; ?>
        </div>

        <div class="detail"><strong>Code:</strong> <?= htmlspecialchars($course['code']) ?></div>
        <div class="detail"><strong>Description:</strong> <?= htmlspecialchars($course['description']) ?></div>
        <div class="detail"><strong>Type:</strong> <?= htmlspecialchars($course['type']) ?></div>
        <div class="detail"><strong>Credits:</strong> <?= htmlspecialchars($course['credits']) ?></div>
        <div class="detail"><strong>Admin ID:</strong> <?= htmlspecialchars($course['admin_id']) ?></div>
        <div class="detail"><strong>Teacher ID:</strong> <?= htmlspecialchars($course['teacher_id']) ?></div>
        <div class="detail"><strong>Active:</strong> <?= $course['is_active'] ? 'Yes' : 'No' ?></div>

        <?php endforeach; ?>
    </div>
<?php endif; ?>
<div style="display: flex; justify-content:center">
        <a href="course_dashboard.php" class="back-btn"> Back</a>
    </div>
        </section>

        
   <!-- JavaScript for toggling the menu visibility -->
   <script>
      var navLinks = document.getElementById("navLinks");
      function openMenu() {
         navLinks.style.right = "0"; // Open the menu by setting the style to right = 0
      }
      function closeMenu() {
         navLinks.style.right = "-200px"; // Close the menu by shifting it off-screen
      }
   </script>

</body>
</html>
