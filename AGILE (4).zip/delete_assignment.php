<?php
require 'authentication_middleware.php';
require 'authorization_middleware.php';

allowOnlyUserType('student'); // Only student can access

require_once 'db.php';

$student = null;
$student_id = $_SESSION['user_id'] ?? null;
// ✅ Initialize status message variables
$success = '';
$error = '';


// Generate CSRF token if not set
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Handle delete request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'], $_POST['csrf_token'])) {
    if (hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $delete_id = intval($_POST['delete_id']);

        // Fetch file path for the assignment to delete the file
        $stmt = $pdo->prepare("SELECT file_path FROM submitted_assignments WHERE id = ? AND student_id = ?");
        $stmt->execute([$delete_id, $student_id]);
        $assignment = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($assignment) {
            // Delete file from server
            if (file_exists($assignment['file_path'])) {
                unlink($assignment['file_path']);
            }

            // Delete record from DB
            $del_stmt = $pdo->prepare("DELETE FROM submitted_assignments WHERE id = ? AND student_id = ?");
            $del_stmt->execute([$delete_id, $student_id]);

            $success = "✅ Assignment deleted successfully!";
        } else {
            $error = "❌ Assignment not found or permission denied.";
        }
    } else {
        $error = "❌ Invalid CSRF token.";
    }
}

// Fetch assignments for this student to show a list with delete options
$stmt = $pdo->prepare("SELECT id, file_name, uploaded_at FROM submitted_assignments WHERE student_id = ? ORDER BY uploaded_at DESC");
$stmt->execute([$student_id]);
$assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Delete Assignments</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-image: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7)), url("img/build.jpg");
            background-color: #f4f4f4;
            padding: 40px;
            color: #333;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .message {
            text-align: center;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .success { color: green; }
        .error { color: red; }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 6px;
            overflow: hidden;
        }
        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #007BFF;
            color: white;
        }
        .delete-btn {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 8px 14px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .delete-btn:hover {
            background-color: #b02a37;
        }
        .back-btn {
            background: none;
            color: #333;
            border: none;
            font-weight: bold;
            cursor: pointer;
            text-decoration: underline;
            font-size: 14px;
            margin-top: 10px;
        }

        .back-btn:hover {
            text-decoration: none;
            background-color: #0056b3;
            color: white;
            border-radius: 6px;
            padding: 6px 12px;
        }

        .back-btn-container {
            text-align: center;
            margin-top: 20px;
        }
        .header {
      width: 100%;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      position: absolute;
      top: 10px;
      left: 10px;
      z-index: 10;
    }

    .logo {
      height: 60px;
      width: auto;
    }
    </style>
</head>
<body>
     <div class="header">
  <img src="img/logoo.png" alt="School Logo" class="logo">
</div>


<h1>Delete Your Assignments</h1>

<?php if ($success): ?>
    <p class="message success"><?= htmlspecialchars($success) ?></p>
<?php elseif ($error): ?>
    <p class="message error"><?= htmlspecialchars($error) ?></p>
<?php endif; ?>

<?php if (count($assignments) > 0): ?>
    <table>
        <thead>
            <tr>
                <th>File Name</th>
                <th>Uploaded At</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($assignments as $assignment): ?>
                <tr>
                    <td><?= htmlspecialchars($assignment['file_name']) ?></td>
                    <td><?= htmlspecialchars(date('Y-m-d H:i', strtotime($assignment['uploaded_at']))) ?></td>
                    <td>
                        <form method="post" onsubmit="return confirm('Are you sure you want to delete this assignment?');">
                            <input type="hidden" name="delete_id" value="<?= $assignment['id'] ?>">
                            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                            <button type="submit" class="delete-btn">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p style="text-align:center;">You have no submitted assignments to delete.</p>
<?php endif; ?>
<form action="student_dashboard.php" method="get" class="back-btn-container">
    <button type="submit" class="back-btn">⬅ Back to Student Dashboard</button>
</form>

</body>
</html>