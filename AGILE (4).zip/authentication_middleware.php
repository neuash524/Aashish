<?php
// authentication_middleware.php
//session_start();

/*function allowOnly(array $allowedRoles) {
    if (!isset($_SESSION['role'])) {
        header("Location: login.php?error=You must log in first");
        exit;
    }

    if (!in_array($_SESSION['role'], $allowedRoles)) {
        echo "<h2 style='color:red'>Access Denied: You are not authorized to view this page.</h2>";
        exit;
    }
}*/
//
//session_start();
/*
function allowOnlyUserType($requiredType) {
    if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== $requiredType) {
        echo "<h2 style='color:red'>Access Denied: Invalid user type.</h2>";
        exit;
    }
}

*/
//changes  i make from this
// auth_middleware.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Enforces that the user is logged in as a specific user type (e.g., 'admin', 'teacher', 'student').
 */
function allowOnlyUserType(string $requiredType) {
    if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== $requiredType) {
        echo "<h2 style='color:red'>Access Denied: Only $requiredType users can access this page.</h2>";
        exit;
    }
}

/**
 * Enforces that the logged-in user has one of the allowed roles (e.g., 'Course Admin', 'Department Admin').
 */
function allowOnlyRole(array $allowedRoles) {
    if (!isset($_SESSION['role'])) {
        header("Location: login.php?error=You must log in first");
        exit;
    }

    $userRole = strtolower(trim($_SESSION['role']));
    $normalizedRoles = array_map(fn($r) => strtolower(trim($r)), $allowedRoles);

    if (!in_array($userRole, $normalizedRoles)) {
        echo "<h2 style='color:red'>Access Denied: You are not authorized to view this page.</h2>";
        exit;
    }
}
?>
