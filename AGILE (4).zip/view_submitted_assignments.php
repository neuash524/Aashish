<?php
require 'authentication_middleware.php';
require 'authorization_middleware.php';

allowOnlyUserType('admin');

require_once 'db.php';

// Handle delete request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    $stmt = $pdo->prepare("DELETE FROM submitted_assignments WHERE id = ?");
    $stmt->execute([$delete_id]);
    header("Location: view_submittedassignments.php"); // refresh page
    exit;
}

// Fetch assignments with student details
$stmt = $pdo->prepare("
    SELECT 
        sa.id, 
        sa.file_name, 
        sa.file_path, 
        sa.code, 
        sa.uploaded_at,
        s.name AS student_name, 
        s.class AS student_class, 
        s.email AS student_email
    FROM submitted_assignments sa
    LEFT JOIN student s ON sa.student_id = s.student_id
    ORDER BY sa.uploaded_at DESC
");
$stmt->execute();
$assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>View Submitted Assignments</title>
  <style>
    body {
  background-image: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7)), url("img/build.jpg");
  background-size: cover;
  background-position: center;
  color: #000;
}

        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 1000px;
        }
    h2 {
      text-align: center;
      margin-bottom: 30px;
    }

    table {
  width: 100%;
  border-collapse: collapse;
  background: rgba(255, 255, 255, 0.85); /* softer white */
  box-shadow: 0 0 10px rgba(0,0,0,0.05);
}
    th, td {
      padding: 12px 15px;
      border: 1px solid #ddd;
      text-align: left;
    }

    th {
      background-color: #276129;
      color: white;
    }

    tr:nth-child(even) {
      background: #f1f1f1;
    }

    a.download-btn {
      color: #007BFF;
      text-decoration: none;
      font-weight: bold;
    }

    a.download-btn:hover {
      text-decoration: underline;
    }

    form.delete-form {
      margin: 0;
    }

    button.delete-btn {
      background-color: #dc3545;
      color: white;
      border: none;
      padding: 6px 12px;
      border-radius: 4px;
      cursor: pointer;
    }

    button.delete-btn:hover {
      background-color: #b02a37;
    }
    .back-btn {
  display: inline-block;
  margin: 30px auto 0;
  background-color: #276129;
  color: white;
  padding: 12px 20px;
  text-decoration: none;
  border-radius: 8px;
  font-weight: bold;
}
.back-btn:hover {
  background-color: #276129;
}
.header {
      width: 100%;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      position: absolute;
      top: 10px;
      left: 10px;
      z-index: 10;
    }

    .logo {
      height: 60px;
      width: auto;
    }
  </style>
  <script>
    function confirmDelete() {
      return confirm('Are you sure you want to delete this assignment?');
    }
  </script>
</head>
<body>
  <div class="header">
  <img src="img/logoo.png" alt="School Logo" class="logo">
</div>

<h2>Submitted Assignments</h2>

<?php if (count($assignments) === 0): ?>
    <p>No assignments submitted yet.</p>
<?php else: ?>
    <table>
        <thead>
            <tr>
                <th>Student Name</th>
                <th>Email</th>
                <th>Class</th>
                <th>File Name</th>
                <th>Code</th>
                <th>Uploaded At</th>
                <th>Download</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($assignments as $assignment): ?>
                <tr>
                    <td><?= htmlspecialchars($assignment['student_name'] ?? 'Unknown') ?></td>
                    <td><?= htmlspecialchars($assignment['student_email'] ?? 'Unknown') ?></td>
                    <td><?= htmlspecialchars($assignment['student_class'] ?? 'Unknown') ?></td>
                    <td><?= htmlspecialchars($assignment['file_name']) ?></td>
                    <td><?= htmlspecialchars($assignment['code']) ?></td>
                    <td><?= htmlspecialchars($assignment['uploaded_at']) ?></td>
                    <td>
                        <a class="download-btn" href="<?= htmlspecialchars($assignment['file_path']) ?>" download>Download</a>
                    </td>
                    <td>
                        <form method="POST" class="delete-form" onsubmit="return confirmDelete();">
                            <input type="hidden" name="delete_id" value="<?= $assignment['id'] ?>">
                            <button type="submit" class="delete-btn">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

</body>
<div style="text-align: center;">
  <a href="course_dashboard.php" class="back-btn">⬅ Back to Dashboard</a>
</div>
</html>
