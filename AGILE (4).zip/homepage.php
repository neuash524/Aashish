<?php
// Start the session to access session variables
session_start();

// Define a variable for the page title
$title = "Greenfield School";

// Check if the user is logged in by verifying the session variable 'user_id'
$loggedIn = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title><?php echo $title; ?></title> <!-- Display page title -->
   <link rel="stylesheet" href="homepage.css"> <!-- Link to the homepage CSS -->
   <link href="img/logoo.png" rel="icon" type="image/webp"> <!-- Set favicon for the page -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome icons -->
  <!-- <script src="Navigation.js" defer></script>  External JavaScript for navigation -->
</head>

<body>
   <section class="header">  
    <nav>
      <img src="img/logoo.png" alt="Logo" class="logo"> <!-- Display the university logo -->
   
      <div class="nav-links" id="navLinks">
         <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i> <!-- Close menu icon -->
         <ul>
            <li><a href="homepage.php">HOME</a></li> <!-- Home link -->
            <li><a href="course.php">COURSE</a></li> <!-- Contact link -->
            <li><a href="staff.php">STAFF</a></li> <!-- About link -->
            <li><a href="login.php">LOG IN</a></li> <!-- Administrator link -->
         </ul>
      </div>
      <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i> <!-- Open menu icon -->
    </nav>
  
    <div class="text-box">
      <h1>GREENFIELD  SCHOOL -   The  way  to  your dream!</h1> <!-- Heading for the page -->
      <p>
      Greenfield High is a leading educational institution offering world-class learning in a supportive and inclusive environment. Our mission is to nurture young minds with values, knowledge, and skills for a successful life.Our cutting-edge facilities and distinguished faculty empower students 
      to achieve their dreams.
      </p>
      <a href="about.php" class="middle-btn" > About us ->> </a> <!-- Button to redirect to available courses -->
    </div>

    </section>

    
    <!-- Footer section with contact information -->
    <footer>
      <section class="about-contact">
         <h2>Contact Us</h2>
         <div class="contact-container">
            <div class="contact-details">
               <p>📍 Sankt Petri Passage 10, 1165 København, Denmark</p> <!-- Address -->
               <p>📧 Email: contact@greenfieldschool.com</p> <!-- Email -->
               <p>📞 Phone: +45 123 5678</p> <!-- Phone number -->
            </div>
         </div>
      </section>



<div id="consent-banner" style="
  position: fixed; bottom: 0; left: 0; right: 0; background: #222; color: #fff;
  padding: 15px; text-align: center; font-family: Arial, sans-serif; z-index: 1000;
  display: none;
  box-shadow: 0 -2px 5px rgba(0,0,0,0.3);
">
  This website uses cookies to improve your experience.
  Please read our
  <a href="/privacy-policy.html" target="_blank" style="color: #4CAF50; text-decoration: underline;">
    Privacy Policy
  </a>.
  <br><br>
  <button id="consent-accept-btn" style="
    padding: 6px 14px; background-color: #4CAF50;
    color: white; border: none; border-radius: 3px; cursor: pointer; font-weight: bold;">
    Accept
  </button>

  <button id="consent-decline-btn" style="
    padding: 6px 14px; background-color: #f44336;
    color: white; border: none; border-radius: 3px; cursor: pointer; font-weight: bold; margin-left: 10px;">
    Decline
  </button>
</div>

   </footer>
      

   <!-- JavaScript for toggling the menu visibility -->
   <script>
  var navLinks = document.getElementById("navLinks");
  
  function openMenu() {
    navLinks.style.right = "0"; // Open the menu by setting right to 0
  }
  
  function closeMenu() {
    navLinks.style.right = "-200px"; // Close the menu by shifting it off-screen
  }

   // Check if user has given consent
  const consentGiven = localStorage.getItem('userConsentGiven') === 'true';

  // Get all links that require consent
  const consentLinks = document.querySelectorAll('.needs-consent');

  if (!consentGiven) {
    // Show consent banner
    document.getElementById('consent-banner').style.display = 'block';

    // Disable each link that requires consent
    consentLinks.forEach(link => {
      link.classList.add('disabled');
      link.addEventListener('click', function (e) {
        e.preventDefault(); // Prevent click
        alert("Please accept cookies to use this feature.");
      });
    });
  }

  // Handle consent acceptance
  document.getElementById('consent-accept-btn').addEventListener('click', function () {
    localStorage.setItem('userConsentGiven', 'true');
    document.getElementById('consent-banner').style.display = 'none';

    // Re-enable links
    consentLinks.forEach(link => {
      link.classList.remove('disabled');
    });
  });

  // Handle decline
document.getElementById('consent-decline-btn').addEventListener('click', function () {
  localStorage.setItem('userConsentGiven', 'false');
  document.getElementById('consent-banner').style.display = 'none';

  // Keep links disabled
  consentLinks.forEach(link => {
    link.classList.add('disabled');
  });

  alert("You must accept cookies to use certain features on this site.");
});
   </script>


</body>
</html>