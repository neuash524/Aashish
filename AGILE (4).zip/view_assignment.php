<?php
require 'authentication_middleware.php';
require 'authorization_middleware.php';

allowOnlyUserType('teacher'); // Only teachers can access

require_once 'db.php';

$teacher = null;
$teacher_id = $_SESSION['user_id'] ?? null;

$stmt = $pdo->prepare("SELECT a.id, a.title, a.file_name, a.file_path, c.name, a.uploaded_at
                       FROM assignments a
                       JOIN course c ON a.code = c.code
                       WHERE a.teacher_id = ?
                       ORDER BY a.uploaded_at DESC");
$stmt->execute([$teacher_id]);
$assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="edit_teacher.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
   <link rel="icon" href="img/logoo.png" type="image/webp">
   <script src="Navigation.js" defer></script>
   <title>Upload Assignment</title>
<head>
    <title>My Assignments</title>
</head>
<body>
    <h2>My Uploaded Assignments</h2>

    <?php if (!empty($assignments)): ?>
        <ul>
        <?php foreach ($assignments as $a): ?>
            <li>
                <strong><?= htmlspecialchars($a['title']) ?></strong> (<?= htmlspecialchars($a['name']) ?>)
                — <a href="<?= $a['file_path'] ?>" target="_blank">Download</a>
                — <small><?= $a['uploaded_at'] ?></small>
                — <a href="delete_assignment.php?id=<?= $a['id'] ?>" onclick="return confirm('Are you sure you want to delete this assignment?')">🗑️ Delete</a>

            </li>
        <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>No assignments uploaded yet.</p>
    <?php endif; ?>

    p><a class="back-btn"href="view_teacher_classes.php">← Back to My Assigned Courses</a></p>

</body>
</html>
