<?php

// ==========================
// 1. General Validation
// ==========================

function validateName($name, $user_role) {
    $name = trim($name);
    if (empty($name)) return "Name is required.";
    if (strlen($name) > 30) return "Name must not exceed 30 characters.";
    if (!preg_match("/^[a-zA-Z' -]+$/", $name)) return "Name must contain only letters, spaces, hyphens, or apostrophes.";
    return null;
}
/*function isValidateName($input){
    return preg_match("/^[a-zA-Z' -]+$/", $input);
}*/
/*function isValidUserRole($input) {
    $valid_roles = ['admin', 'teacher', 'student'];
    return in_array(strtolower($input), $valid_roles);
}*/

function isValidAlpha($input) {
    return preg_match("/^[a-zA-Z' -]+$/", $input);
}


function isValidUsername($input) {
    return preg_match('/^[a-zA-Z0-9_]+$/', $input);
}

function isValidEmail($input) {
    return filter_var($input, FILTER_VALIDATE_EMAIL) !== false;
}

function isValidAdminRole($input) {
    $valid_roles = ['super admin', 'department admin', 'student admin', 'course admin', 'teacher admin'];
    return in_array(strtolower($input), $valid_roles);
}

function isValidStatus($input) {
    $valid_status = ['pending', 'approved', 'rejected'];
    return in_array(strtolower($input), $valid_status);
}

function isValidBooleanLike($input) {
    $valid = ['yes', 'no', '0', '1', 0, 1, true, false];
    return in_array(strtolower((string)$input), $valid, true);
}

// ==========================
// 2. Field-Specific Validation
// ==========================

function isValidContact($input) {
    $input = trim($input);
    if (strlen($input) !== 8) {
        return false; // Must be exactly 8 characters
    }
    return preg_match('/^[0-9+\-\s\(\)]+$/', $input);
}

function isValidQualification($input) {
    return preg_match('/^[a-zA-Z\s,\.]+$/', $input);
}

function isValidClass($input) {
    return preg_match('/^[a-zA-Z0-9]+$/', $input);
}

function isValidCode($input) {
    return preg_match('/^[a-zA-Z0-9]+$/', $input);
}

function isValidPhoto($input) {
    return preg_match('/^[a-zA-Z0-9_\.\-]+$/', $input);
}

function isValidDescription($input) {
    return preg_match('/^[a-zA-Z0-9\s,.\-!?()\'"]*$/', $input);
}

// ==========================
// 3. Account Logic
// ==========================

function generateUsername($fullName, $role, $pdo) {
    $names = explode(' ', strtolower(trim($fullName)));
    $firstInitial = isset($names[0]) ? substr($names[0], 0, 1) : '';
    $lastName = isset($names[count($names) - 1]) ? $names[count($names) - 1] : '';
    $baseUsername = $firstInitial . $lastName . '_' . str_replace(' ', '_', strtolower($role));
    $username = $baseUsername;
    $counter = 1;

    while (usernameExists($username, $pdo)) {
        $username = $baseUsername . $counter;
        $counter++;
    }

    return $username;
}

function usernameExists($username, $pdo) {
    $tables = ['admin', 'teacher', 'student'];
    foreach ($tables as $table) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM $table WHERE user_name = ?");
        $stmt->execute([$username]);
        if ($stmt->fetchColumn() > 0) {
            return true;
        }
    }
    return false;
}

function generatePassword($length = 8) {
    return substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, $length);
}

// ==========================
// 4. Utility
// ==========================

function getExistingUserByEmail($pdo, $email) {
    $tables = ['admin', 'teacher', 'student'];
    foreach ($tables as $table) {
        $stmt = $pdo->prepare("SELECT * FROM $table WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            return ['table' => $table, 'user' => $user];
        }
    }
    return null;
}

function logActivity($pdo, $user_id, $role, $activity, $details = null) {
    $stmt = $pdo->prepare("INSERT INTO activity_log (user_id, role, activity, details) VALUES (?, ?, ?, ?)");
    $stmt->execute([$user_id, $role, $activity, $details]);
}

function getAnyUserIdByRole(PDO $pdo, string $role): ?int {
    $table = '';
    $idField = '';

    switch ($role) {
        case 'admin':
            $table = 'admin';
            $idField = 'admin_id';
            break;
        case 'teacher':
            $table = 'teacher';
            $idField = 'teacher_id';
            break;
        case 'student':
            $table = 'student';
            $idField = 'student_id';
            break;
        default:
            return null;
    }

    $stmt = $pdo->prepare("SELECT $idField FROM $table LIMIT 1");
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ? (int)$row[$idField] : null;
}




