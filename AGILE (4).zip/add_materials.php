<?php
session_start();
include 'db.php';

// ✅ Uncomment if role-based access is active
// require 'authentication_middleware.php';
// allowOnlyUserType('admin');
// allowOnlyRole(['Course Admin']);
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin','Course Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();

$upload_dir = "img/";
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Fetch all courses
$coursesStmt = $pdo->query("SELECT code, name, teacher_id FROM course ORDER BY code");
$courses = $coursesStmt->fetchAll(PDO::FETCH_ASSOC);

// Handle upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['material'])) {
    $id = $_POST['id'];
    $code = $_POST['code'];
    $file = $_FILES['material'];

    // Get teacher_id for the selected course
    $teacher_id_stmt = $pdo->prepare("SELECT teacher_id FROM course WHERE code = ?");
    $teacher_id_stmt->execute([$code]);
    $teacher_id = $teacher_id_stmt->fetchColumn();

    //  Check if course has a teacher assigned
    if (empty($teacher_id)) {
        $_SESSION['message'] = "<p class='message error'>Cannot upload. The selected course has no assigned teacher.</p>";
        header("Location: add_materials.php");
        exit;
    }

    if ($file['error'] === 0) {
        $filename = basename($file["name"]);
        $target_file = $upload_dir . $filename;

        // Check for duplicate ID
        $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM course_materials WHERE id = ?");
        $checkStmt->execute([$id]);
        if ($checkStmt->fetchColumn() > 0) {
            $_SESSION['message'] = "<p class='message error'>Material ID already exists. Please choose a unique ID.</p>";
        } elseif (move_uploaded_file($file["tmp_name"], $target_file)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO course_materials (id, teacher_id, code, file_name, file_path) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$id, $teacher_id, $code, $filename, $target_file]);
                $_SESSION['message'] = "<p class='message success'>File uploaded successfully.</p>";
            } catch (PDOException $e) {
                $_SESSION['message'] = "<p class='message error'>Database error: " . htmlspecialchars($e->getMessage()) . "</p>";
            }
        } else {
            $_SESSION['message'] = "<p class='message error'>Error moving uploaded file.</p>";
        }
    } else {
        $_SESSION['message'] = "<p class='message error'>File upload error: " . $file['error'] . "</p>";
    }

    header("Location: add_materials.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Upload Course Materials</title>
   <link rel="stylesheet" href="homepage.css">
   <link href="img/logoo.png" rel="icon" type="image/webp">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
   <style>
.container {
    width: 90%;
    max-width: 700px;
    background-color: rgba(255, 255, 255, 0.95);
    margin: auto;
    padding: 30px 25px;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
    color: #003366;
}
h2 {
    text-align: center;
    font-size: 2rem;
    margin-bottom: 30px;
}
form {
    display: flex;
    flex-direction: column;
    gap: 15px;
    margin-bottom: 40px;
    font-weight: bold;
}
input, select, button {
    padding: 12px;
    font-size: 1rem;
    border-radius: 6px;
    border: 1px solid #ccc;
    width: 100%;
    box-sizing: border-box;
}
button {
    background-color: #003366;
    color: white;
    border: none;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s ease;
}
button:hover {
    background-color: #001f4d;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 25px;
}
th, td {
    border: 1px solid #ddd;
    padding: 12px;
    text-align: left;
}
th {
    background-color: #003366;
    color: white;
}
a.delete {
    color: red;
    font-weight: bold;
}
.message {
    text-align: center;
    font-weight: bold;
    padding: 10px;
    border-radius: 6px;
    margin: 15px auto;
    width: 90%;
    max-width: 600px;
}
.message.success {
    background-color: #28a745;
    color: white;
}
.message.error {
    background-color: #dc3545;
    color: white;
}
.footer {
  width: 100%;
  text-align: center;
  padding: 0;
  position: relative;
  bottom: 0;
}
.back-btn {
  display: inline-block;
  padding: 12px 24px;
  background: blue;
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background 0.3s ease, transform 0.2s ease;
  box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.back-btn:hover {
  background: blue;
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
}

@media (max-width: 768px) {
    .container {
        padding: 20px 15px;
    }
    .container h2 {
        font-size: 1.5rem;
    }
    input,
    button {
        font-size: 1rem;
        padding: 10px;
    }
    nav img {
        width: 100px;
        height: 100px;
    }
    .nav-links {
        width: 160px;
    }
    .message {
        font-size: 1rem;
    }
}
   </style>
</head>
<body>
<section class="header">  
    <nav>
      <img src="img/logoo.png" alt="Logo" class="logo">
      <div class="nav-links" id="navLinks">
         <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i>
         <ul>
            <li><a href="homepage.php">HOME</a></li>
            <li><a href="courses.php">COURSE</a></li>
            <li><a href="staff.php">STAFF</a></li>
            <li><a href="login.php">LOG IN</a></li>
         </ul>
      </div>
      <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i>
    </nav>

<!-- Display Flash Messages -->
 <?php

if (isset($_SESSION['message'])) {
    echo $_SESSION['message'];
    unset($_SESSION['message']);
}
?>
<div class="container">
    <h2>Upload Course Material</h2>
    <form method="POST" enctype="multipart/form-data">
        <label for="id">Material ID:</label>
         <input type="int" name="id" required>

        <label>Course:</label>
        <select name="code" required>
            <option value="">-- Select Course --</option>
            <?php foreach ($courses as $course): ?>
                <option value="<?= htmlspecialchars($course['code']) ?>">
                    <?= htmlspecialchars($course['code'] . ' - ' . $course['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="material">Select File:</label>
        <input type="file" name="material" accept=".pdf,.doc,.ppt,.pptx,.png,.jpg,.webp,.zip" required>
        <button type="submit">Upload</button>
    </form>
<footer class="footer">
  <a href="course_dashboard.php" class="back-btn"> Back</a>
</footer>
    </section>
<

  <!-- JavaScript for toggling the menu visibility -->
   <script>
      var navLinks = document.getElementById("navLinks");
      function openMenu() {
         navLinks.style.right = "0"; // Open the menu by setting the style to right = 0
      }
      function closeMenu() {
         navLinks.style.right = "-200px"; // Close the menu by shifting it off-screen
      }
   </script>

</body>
</html>
