<?php

session_start();
require 'db.php'; // Your PDO connection
require 'functions.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();
require_once 'UserManager.php';

$userManager = new UserManager($pdo);


$role = $_GET['role'] ?? '';
$id = 0;

if ($role) {
    if ($role === 'admin' && isset($_GET['admin_id'])) {
        $id = (int)$_GET['admin_id'];
    } elseif ($role === 'teacher' && isset($_GET['teacher_id'])) {
        $id = (int)$_GET['teacher_id'];
    } elseif ($role === 'student' && isset($_GET['student_id'])) {
        $id = (int)$_GET['student_id'];
    } elseif (isset($_GET['id'])) {
        // fallback if just 'id' is present
        $id = (int)$_GET['id'];
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'GET' && $role && $id) {
    $user = $userManager->getUserByRoleAndId($role, $id);
    if (!$user || !is_array($user)) {
        $errorMessage = "❌ User not found.";
        $user = false; // <== Add this
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postRole = $_POST['role'] ?? '';
    $postId = isset($_POST['id']) ? (int)$_POST['id'] : 0;

    if (!$postRole || !$postId) {
        $errorMessage = "❌ Error: Missing role or ID for deletion.";
    } else {
        $result = $userManager->deleteUser($postRole, $postId);

        if (isset($result['error'])) {
            $errorMessage = $result['error'];
        } else {
            $successMessage = $result['success'];
            $user = false; // Hide confirmation table
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="userstyle.css"> <!-- Link to the user CSS -->
  <title>USER MANAGEMENT</title>
</head>
<body>

<div class="header">
  <img src="img/logoo.png" alt="School Logo" class="logo">
  <div class="system-title"><strong>User Management System</strong></div>
</div>

<div class="dashboard-container">
  <!-- Hamburger icon -->
  <div class="hamburger" onclick="toggleSidebar()">☰</div>

  <aside class="sidebar">
    <h2>Dashboard</h2>
    <ul>
      <li><a href="homepage.php">Home</a></li>
      <li><a href="user_management.php">Manage Users</a></li>
      <li><a href="course.php">Courses</a></li>
      <li><a href="about.php">About Us</a></li>
    </ul>      
  </aside>

  <main class="main-content">
    <!--Delete User-->
    <div class="form-box">
      <fieldset>
        <legend><strong>Delete User</strong></legend>
        <!-- Manual form to enter role + ID -->
        <form method="GET" action="delete_user.php" style="margin-bottom: 15px;">
          <label for="role">Role:</label>
          <select name="role" id="role" required>
            <option value="">-- Select role --</option>
            <option value="admin" <?= ($role === 'admin') ? 'selected' : '' ?>>Admin</option>
            <option value="teacher" <?= ($role === 'teacher') ? 'selected' : '' ?>>Teacher</option>
            <option value="student" <?= ($role === 'student') ? 'selected' : '' ?>>Student</option>
          </select>

          <label for="id">ID:</label>
          <input type="number" name="id" id="id" value="<?= htmlspecialchars($id ?? '') ?>" required>

          <button type="submit">Find User</button>
        </form>
      </fieldset>
    </div>

    <br><br>
    <a href="user_management.php"><button>Go Back</button></a><br><br>

    <!-- Confirmation block: moved inside main-content, below form -->

    <?php if (is_array($user)): ?>

      <div style="max-width: 600px; font-size: 0.9em; border: 1px solid #ccc; padding: 10px; background: #f8f8f8;">
        <h3 style="margin-top:0;">Confirm Deletion</h3>
        <table border="1" cellpadding="4" cellspacing="0" style="width: 100%; border-collapse: collapse; font-size: 0.9em;">
          <!-- Common info -->
          <tr><td><strong>Username</strong></td><td><?= htmlspecialchars($user['user_name']) ?></td></tr>
          <tr><td><strong>Email</strong></td><td><?= htmlspecialchars($user['email']) ?></td></tr>

          <!-- Role-specific info -->
          <?php if ($role === 'admin'): ?>
            <tr><td><strong>Admin ID</strong></td><td><?= htmlspecialchars($user['admin_id']) ?></td></tr>
            <tr><td><strong>Admin Role</strong></td><td><?= htmlspecialchars($user['role']) ?></td></tr>
            <tr><td><strong>Contact</strong></td><td><?= htmlspecialchars($user['contact']) ?></td></tr>
          <?php elseif ($role === 'teacher'): ?>
            <tr><td><strong>Teacher ID</strong></td><td><?= htmlspecialchars($user['teacher_id']) ?></td></tr>
            <tr><td><strong>Qualification</strong></td><td><?= htmlspecialchars($user['qualification']) ?></td></tr>
            <tr><td><strong>Code</strong></td><td><?= htmlspecialchars($user['code']) ?></td></tr>
          <?php elseif ($role === 'student'): ?>
            <tr><td><strong>Student ID</strong></td><td><?= htmlspecialchars($user['student_id']) ?></td></tr>
            <tr><td><strong>Age</strong></td><td><?= htmlspecialchars($user['age']) ?></td></tr>
            <tr><td><strong>Gender</strong></td><td><?= htmlspecialchars($user['gender']) ?></td></tr>
            <tr><td><strong>Class</strong></td><td><?= htmlspecialchars($user['class']) ?></td></tr>
            <tr><td><strong>Contact</strong></td><td><?= htmlspecialchars($user['contact']) ?></td></tr>
            <tr><td><strong>On Scholarship</strong></td><td><?= htmlspecialchars($user['scholarship']) ?></td></tr>
          <?php endif; ?>
        </table>

        <form method="POST" action="delete_user.php" style="margin-top: 10px;" onsubmit="return confirm('Are you sure you want to delete this user?');">
          <input type="hidden" name="role" value="<?= htmlspecialchars($role) ?>">
          <input type="hidden" name="id" value="<?= htmlspecialchars($id) ?>">
          <button type="submit" style="background-color: #d9534f; color: white; border: none; padding: 6px 12px; cursor: pointer;">Yes, Delete User</button>
          <a href="delete_user.php" style="margin-left: 10px; color: #555; text-decoration: none;">Cancel</a>
        </form>
      </div>
    <?php endif; ?>

     <?php if (!empty($errorMessage)): ?>
        <div style="color: black; font-weight: bold;"><?= htmlspecialchars($errorMessage) ?></div>
    <?php endif; ?>

    <?php if (!empty($successMessage)): ?>
        <div style="color: black; font-weight: bold;"><?= htmlspecialchars($successMessage) ?></div>
    <?php endif; ?>
    

  </main>
</div>




</body>
</html>



