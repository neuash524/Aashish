<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Connect to the database using PDO
try {
    $pdo = new PDO("mysql:host=localhost;dbname=student_record_system", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Initialize variables
$message = '';
$search = $_GET['search'] ?? '';
$type = $_GET['type'] ?? '';
$action = $_GET['action'] ?? '';

// Handle form actions
if ($action === 'search') {
    if (empty($search)) {
        $message = "Please enter code or name to search.";
        $courses = $pdo->query("SELECT * FROM course WHERE is_active = 1")->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $query = "SELECT * FROM course WHERE is_active = 1 AND (code LIKE :search OR name LIKE :search)";
        $stmt = $pdo->prepare($query);
        $stmt->bindValue(':search', '%' . $search . '%');
        $stmt->execute();
        $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} elseif ($action === 'filter') {
    if (empty($search) && empty($type)) {
        $message = "No filter is applied.";
        $courses = $pdo->query("SELECT * FROM course WHERE is_active = 1")->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $query = "SELECT * FROM course WHERE is_active = 1";
        $params = [];

        if (!empty($search)) {
            $query .= " AND (code LIKE :search OR name LIKE :search)";
            $params[':search'] = '%' . $search . '%';
        }

        if (!empty($type)) {
            $query .= " AND type = :type";
            $params[':type'] = $type;
        }

        $stmt = $pdo->prepare($query);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }

        $stmt->execute();
        $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} else {
    // Default: show all active courses
    $courses = $pdo->query("SELECT * FROM course WHERE is_active = 1")->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Courses</title>
    <link rel="stylesheet" href="homepage.css">
    <link href="img/logoo.png" rel="icon" type="image/webp">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="Navigation.js" defer></script>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        h1 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 20px;
            color: rgb(147, 212, 157);
        }
        .search-filter-form {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 10px;
            margin: 1rem;
        }
        .search-filter-form .form-row {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }
        input[type="text"],
        select {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 1rem;
            width: 200px;
        }
        button {
            padding: 10px 16px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .reset-btn {
            background-color: #6c757d;
            color: white;
            padding: 10px 16px;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
        }
        .reset-btn:hover {
            background-color: #5a6268;
        }
        .course-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(260px, 260px));
            gap: 20px;
            padding: 0 10px;
            margin: 0 auto;
            max-width: 1200px;
            justify-content: center;
        }
        .course-card {
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
            padding: 25px;
            text-align: center;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .course-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
        }
        .course-card a {
            text-decoration: none;
            color: #003366;
            font-size: 1.2rem;
            font-weight: bold;
        }
        .course-card a:hover {
            color: #0055cc;
        }
        @media (max-width: 480px) {
            h1 { font-size: 1.8rem; }
            .search-filter-form {
                align-items: center;
                text-align: center;
            }
            input[type="text"], select, button {
                width: 100%;
                margin: 5px 0;
            }
        }
    </style>
</head>

<body>
<section class="header">
    <nav>
        <img src="img/logoo.png" alt="Logo" class="logo">
        <div class="nav-links" id="navLinks">
            <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i>
            <ul>
                <li><a href="homepage.php">HOME</a></li>
                <li><a href="course.php">COURSE</a></li>
                <li><a href="staff.php">STAFF</a></li>
                <li><a href="login.php">LOG IN</a></li>
            </ul>
        </div>
        <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i>
    </nav>

    <h1>Available Courses</h1>

    <?php if (!empty($message)): ?>
        <p style="text-align:center; font-size:1.5rem; color:white;background-color: #f8d7da; padding:10px;width: fit-content;  margin: 10px auto; "><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>

    <form method="GET" class="search-filter-form">
        <div class="form-row">
            <input type="text" name="search" placeholder="Search by code or name" value="<?= htmlspecialchars($search) ?>">
            <button type="submit" name="action" value="search">Search</button>
        </div>

        <div class="form-row">
            <label for="type">Type:</label>
            <select name="type" id="type">
                <option value="">All</option>
                <option value="theoretical" <?= $type === 'theoretical' ? 'selected' : '' ?>>Theoretical</option>
                <option value="practical" <?= $type === 'practical' ? 'selected' : '' ?>>Practical</option>
            </select>
            <button type="submit" name="action" value="filter">Filter</button>
            <button type="button" class="reset-btn" onclick="window.location.href='<?= $_SERVER['PHP_SELF'] ?>'">Reset</button>
        </div>
    </form>

    <div class="course-grid">
        <?php if ($courses && count($courses) > 0): ?>
            <?php foreach ($courses as $row): ?>
                <div class="course-card">
                    <?php if (!empty($row['image']) && file_exists($row['image'])): ?>
                        <img src="<?= htmlspecialchars($row['image']) ?>" alt="Course Image" style="width:100%; height:150px; object-fit:cover; border-radius:8px; margin-bottom:10px;">
                    <?php endif; ?>
                    <a href="course_details.php?code=<?= urlencode($row['code']) ?>">
                        <?= htmlspecialchars($row['code']) ?> - <?= htmlspecialchars($row['name']) ?>
                    </a>
                    <?php if (!empty($search) || !empty($type)): ?>
                        <div>Type: <?= htmlspecialchars($row['type']) ?></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p style="font-size:3rem; color:white;">No courses found.</p>
        <?php endif; ?>
    </div>

    <script>
        function openMenu() {
            document.getElementById("navLinks").style.right = "0";
        }
        function closeMenu() {
            document.getElementById("navLinks").style.right = "-200px";
        }
    </script>
</section>
</body>
</html>
