<?php
// Database connection using PDO
session_start();
require 'db_connection.php'; // Contains $conn = new PDO(...);
include 'config.php'; // Include your config file (if needed)

$host = 'localhost';
$db = 'student_record_system';  // replace this
$user = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch all courses
    $stmt = $pdo->query("SELECT * FROM course");
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>

/* Base styling */
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f0fff4;
    margin: 0;
    padding: 20px;
    color: #333;
}

h1, h2, h3 {
    color: #2f855a;
    margin-bottom: 10px;
}

form {
    background-color: #e6fffa;
    border: 1px solid #81e6d9;
    padding: 15px;
    margin-bottom: 20px;
    border-radius: 10px;
    box-shadow: 0 2px 5px rgba(0, 128, 0, 0.1);
}

input[type="text"], select {
    padding: 8px;
    margin: 5px 0 15px;
    border: 1px solid #c6f6d5;
    border-radius: 5px;
    width: 100%;
    max-width: 300px;
}

button {
    padding: 10px 15px;
    background-color: #38a169;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #2f855a;
}

table {
    width: 100%;
    border-collapse: collapse;
    background-color: #ffffff;
    margin-top: 20px;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0, 128, 0, 0.1);
}

table th, table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #c6f6d5;
}

table th {
    background-color: #9ae6b4;
    color: #22543d;
}

#confirmation {
    background-color: #fefcbf;
    border: 1px solid #ecc94b;
    padding: 10px;
    border-radius: 8px;
    margin-top: 10px;
}

/* Mobile responsiveness */
@media (max-width: 768px) {
    input[type="text"], select {
        width: 100%;
    }

    table, thead, tbody, th, td, tr {
        display: block;
    }

    table tr {
        margin-bottom: 15px;
    }

    table td {
        padding-left: 50%;
        position: relative;
    }

    table td::before {
        position: absolute;
        left: 10px;
        top: 12px;
        white-space: nowrap;
        font-weight: bold;
    }

    table td:nth-child(1)::before { content: "Code"; }
    table td:nth-child(2)::before { content: "Name"; }
    table td:nth-child(3)::before { content: "Description"; }
    table td:nth-child(4)::before { content: "Type"; }
    table td:nth-child(5)::before { content: "Credits"; }
    table td:nth-child(6)::before { content: "Admin ID"; }
    table td:nth-child(7)::before { content: "Teacher ID"; }
    table td:nth-child(8)::before { content: "Active"; }
    table td:nth-child(9)::before { content: "Status"; }
}
</style>
</head>
<body>
    <h1>Course Management</h1>

    <!-- Add Course Form -->
    <h2>Add Course</h2>
    <form action="process_course.php" method="POST">
      <input type="text" name="name" placeholder="Course Name" required>
      <input type="text" name="course_code" placeholder="Course Code" required>
      <select name="type" required>
         <option value="">Select Type</option>
         <option value="practical">Practical</option>
         <option value="theoretical">Theoretical</option>
        </select>
        <button type="submit">Add Course</button>
    </form>

    <!-- Update Course Form -->
    <h2>Update Course</h2>
    <form action="process_course.php" method="POST">
        <input type="hidden" name="id" id="update-id">
        <input type="text" name="name" id="update-name" placeholder="Course Name" required>
        <input type="text" name="course_code" placeholder="Course Code" required>
        <select name="type" id="update-type" required>
            <option value="">Select Type</option>
            <option value="practical">Practical</option>
            <option value="theoretical">Theoretical</option>
        </select>
        <button type="submit">Update Course</button>
    </form>

    <!-- Delete Course Form -->
    <h1>Delete Course</h1>
     <form id="deleteForm" action="process_course.php" method="POST">
        <input type="text" name="course_identifier" id="course-identifier" placeholder="Course Name or Course Code" required>
        <button type="submit">Delete Course</button>
    </form>

    <div id="confirmation" style="display: none;">
      <p>Are you sure you want to delete the course <strong id="confirmName"></strong>?</p>
      <button onclick="confirmDelete()">Yes, Delete Course</button>
      <button onclick="cancelDelete()">Cancel</button>
    </div>

    <script>
       const form = document.getElementById("deleteForm");
       const confirmationBox = document.getElementById("confirmation");
       const confirmName = document.getElementById("confirmName");

      // Intercept the form submit
      form.addEventListener("submit", function(event) {
        event.preventDefault(); // Stop immediate submission
        const courseIdentifier = document.getElementById("course-identifier").value; // Get the course name or code
        confirmName.textContent = courseIdentifier || "[unknown]";
        confirmationBox.style.display = "block"; // Show confirmation box
      });

       function confirmDelete() {
         form.submit(); // Submit the form for real
        }

       function cancelDelete() {
          confirmationBox.style.display = "none"; // Hide confirmation box
        }
    </script>

    <!--Listing all courses-->

     
    <h1>Existing Courses</h1>
    <table border="1">
        <tr>
            <th>Code</th><th>Name</th><th>Description</th><th>Type</th><th>Credits</th>
            <th>Admin ID</th><th>Teacher ID</th><th>Active</th><th>Status</th>
        </tr>
        <?php foreach ($courses as $row): ?>
        <tr>
            <td><?= htmlspecialchars($row['code']) ?></td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= htmlspecialchars($row['description']) ?></td>
            <td><?= htmlspecialchars($row['type']) ?></td>
            <td><?= $row['credits'] ?></td>
            <td><?= $row['admin_id'] ?></td>
            <td><?= $row['teacher_id'] ?></td>
            <td><?= $row['is_active'] ? "Yes" : "No" ?></td>
            <td><?= ucfirst($row['status']) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <!-- Filter Course -->
<h1>Filter Courses</h1>
<form action="process_course.php" method="POST">
    <label>Type:</label>
    <select name="type">
        <option value="">Select Type</option>
        <option value="Practical">Practical</option>
        <option value="Theoretical">Theoretical</option>
    </select>

    <label>Active:</label>
    <select name="status">
        <option value="">Select Status</option>
        <option value="Yes">Yes</option>
        <option value="No">No</option>
    </select>

    <input type="hidden" name="action" value="filter">
    <button type="submit">Filter</button>
</form>

    <!-- Search Course -->
<h1>Search Course</h1>
<form action="process_course.php" method="POST">
    <input type="hidden" name="action" value="search"> <!-- Hidden field to specify search action -->
    <input type="text" name="search" placeholder="Enter course name" required>
    <button type="submit">Search</button>
</form>

<!-- Display Search Results -->
 <?php $results = $_SESSION['search_results'] ?? null;
       unset($_SESSION['search_results']); // Optional: clear after use 
    ?>

    <?php if (isset($results)): ?>
    <h3>Search Results:</h3>
    <?php if (count($results) > 0): ?>
        <ul>
            <?php foreach ($results as $course): ?>
                <li>
                    <strong><?= htmlspecialchars($course['name']) ?></strong> 
                    (<?= htmlspecialchars($course['code']) ?>) - 
                    <?= htmlspecialchars($course['type']) ?> - 
                    <?= htmlspecialchars($course['status'] ?? 'N/A') ?>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>No courses found.</p>
    <?php endif; ?>
<?php endif; ?>



    <script>
        function editCourse(id, name, type) {
            document.getElementById('update-id').value = id;
            document.getElementById('update-name').value = name;
            document.getElementById('update-type').value = type;
        }

        function confirmDelete() {
            return confirm("Are you sure you want to delete this course?");
        }
    </script>

</body>
</html>
