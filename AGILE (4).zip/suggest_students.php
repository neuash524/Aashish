<?php
require 'authentication_middleware.php';
require 'authorization_middleware.php';
allowOnlyUserType('teacher');

require_once 'db.php';

$term = $_GET['term'] ?? '';

if (strlen($term) >= 1) {
    $stmt = $pdo->prepare("SELECT student_id, name FROM student WHERE name LIKE ? OR student_id LIKE ? LIMIT 10");
    $stmt->execute(["%$term%", "%$term%"]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

echo json_encode([]);
?>
