<?php
require 'db.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();

$user_id = $_SESSION['user_id'];

// Handle delete request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_student_id'])) {
    $delete_id = $_POST['delete_student_id'];

    // Delete related enrollments first due to foreign key constraint
    $stmt = $pdo->prepare("DELETE FROM enroll WHERE student_id = ?");
    $stmt->execute([$delete_id]);

    // Now delete student
    $stmt = $pdo->prepare("DELETE FROM student WHERE student_id = ?");
    $stmt->execute([$delete_id]);

    // Redirect to avoid form resubmission and show success message
    header("Location: view_studentprofile.php?deleted=1");
    exit;
}

// Fetch all students
$stmt = $pdo->prepare("SELECT student_id, name, email, class, admin_id, is_on_scholarship FROM student");
$stmt->execute();
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>All Students</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', sans-serif;
      background-image: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7)), url("img/build.jpg");
      background-size: cover;
      background-position: center;
      color: #fff;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 80px 70px;
    }

    .header {
      background: #fff;
      padding: 1rem;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .logo {
      height: 60px;
    }

    h2 {
      text-align: center;
      margin-top: 20px;
      color: white;
      font-size: 2rem;
    }

    .success-message {
      text-align: center;
      color: lightgreen;
      margin: 10px 0;
      font-weight: bold;
    }

    .student-list {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 2rem;
      padding: 2rem;
      max-width: 1200px;
      margin: auto;
    }

    .profile {
      background-color: #fff;
      border-radius: 16px;
      padding: 1.5rem;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      color: #444;
    }

    .profile p {
      margin: 0.5rem 0;
      font-size: 1rem;
    }

    .profile span {
      font-weight: 600;
      color: #008060;
    }

    .button-wrapper {
      margin-top: 1rem;
    }

    .delete-btn {
      background-color: #c62828;
      color: white;
      padding: 0.5rem 1rem;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-size: 0.9rem;
    }

    .delete-btn:hover {
      background-color: #b71c1c;
    }

    .back-btn {
      display: inline-block;
      margin: 2rem auto;
      text-align: center;
      display: block;
      color: white;
      text-decoration: none;
      font-weight: bold;
      font-size: 1.1rem;
    }

    #confirmModal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background-color: rgba(0,0,0,0.5);
      justify-content: center;
      align-items: center;
      z-index: 1000;
    }

    .modal-content {
      background-color: #fff;
      padding: 2rem;
      border-radius: 12px;
      text-align: center;
    }

    .modal-content button {
      margin: 0.5rem;
      padding: 0.5rem 1rem;
      font-size: 1rem;
      border: none;
      border-radius: 6px;
      cursor: pointer;
    }

    .confirm {
      background-color: #c62828;
      color: white;
    }

    .cancel {
      background-color: #ccc;
      color: black;
    }
  </style>
</head>
<body>
  <div class="header">
    <img src="img/logoo.png" alt="School Logo" class="logo">
  </div>

  <h2>All Registered Students</h2>

  <?php if (isset($_GET['deleted'])): ?>
    <div class="success-message">Student successfully deleted!</div>
  <?php endif; ?>

  <div class="student-list">
    <?php foreach ($students as $student): ?>
      <div class="profile">
        <p><strong>ID:</strong> <span><?= htmlspecialchars($student['student_id']) ?></span></p>
        <p><strong>Name:</strong> <span><?= htmlspecialchars($student['name']) ?></span></p>
        <p><strong>Email:</strong> <span><?= htmlspecialchars($student['email']) ?></span></p>
        <p><strong>Scholarship:</strong> <span><?= $student['is_on_scholarship'] ? 'Yes' : 'No' ?></span></p>
        <p><strong>Class:</strong> <span><?= htmlspecialchars($student['class']) ?></span></p>
        <p><strong>Admin ID:</strong> <span><?= htmlspecialchars($student['admin_id']) ?></span></p>

        <div class="button-wrapper">
          <form method="POST" class="delete-form">
            <input type="hidden" name="delete_student_id" value="<?= htmlspecialchars($student['student_id']) ?>">
            <button type="button" class="delete-btn" onclick="confirmDelete(this)">Delete</button>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <a href="user_management.php" class="back-btn">⬅ Back to Dashboard</a>

  <!-- Modal -->
  <div id="confirmModal">
    <div class="modal-content">
      <p>Are you sure you want to delete this student?</p>
      <button class="confirm" onclick="submitDelete()">Yes, Delete</button>
      <button class="cancel" onclick="closeModal()">Cancel</button>
    </div>
    
  </div>

  <script>
    let activeForm = null;

    function confirmDelete(button) {
      activeForm = button.closest('form');
      document.getElementById('confirmModal').style.display = 'flex';
    }

    function closeModal() {
      document.getElementById('confirmModal').style.display = 'none';
      activeForm = null;
    }

    function submitDelete() {
      if (activeForm) activeForm.submit();
    }
  </script>
</body>
</html>