<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Administration</title>
  <link rel="stylesheet" href="homepage.css">
  <link href="img/logoo.png" rel="icon" type="image/webp">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <script src="Navigation.js" defer></script>
  <style>
    /* Reuse the same grid and card styles as teacher page */
    body {
      font-family: Arial, sans-serif;
      background-image: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7)), url("img/build.jpg");
      background-size: cover;
      background-position: center;
      min-height: 100vh;
      color: white;
    }

    .admin-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 20px;
      padding: 40px;
    }

    .admin-card {
      background-color: #fff;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
      transition: transform 0.2s;
    }

    .admin-card:hover {
      transform: translateY(-5px);
    }

    .admin-photo {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }

    .admin-info {
      padding: 15px;
    }

    .admin-info h3 {
      margin-bottom: 10px;
      color: #007bff;
    }

    .admin-info p {
      margin: 5px 0;
      color: #555;
    }

    footer {
      background-color: #0c5130;
      padding: 20px;
      text-align: center;
      color: white;
      margin-top: 40px;
    }

    .back-btn {
  display: inline-block;
  padding: 10px 20px;
  background-color: #540026;
  color: white;
  text-decoration: none;
  border-radius: 8px;
  margin: 20px;
  font-weight: bold;
  transition: background-color 0.3s ease;
}

.back-btn:hover {
  background-color: #6d0033;
}


      @media (max-width: 768px) {
    .nav-links ul li {
      display: block;
    }

    nav .fas {
      display: block;
      color: #fff;
      font-size: 22px;
      cursor: pointer;
    }

    .nav-links {
      position: absolute;
      background: rgba(195, 255, 177, 0.8);
      height: 100vh;
      width: 200px;
      top: 0;
      right: -200px;
      z-index: 100;
      transition: 1s;
    }

    .nav-links ul {
      padding: 30px;
    }
  }
  </style>
</head>
<body>

<nav>
  <img src="img/logoo.png" alt="Logo" class="logo">
  <div class="nav-links" id="navLinks">
    <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i>
    <ul>
      <li><a href="homepage.php">HOME</a></li>
      <li><a href="course.php">COURSE</a></li>
      <li><a href="staff.php">STAFF</a></li>
      <li><a href="login.php">LOG IN</a></li>
    </ul>
  </div>
  <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i>
</nav>

<h2 style="text-align:center; margin-top: 30px;">Our Administration Team</h2>

<div class="admin-grid">
  <?php
  $admins = [
    ["name" => "Mr. Magnus Green", "email" => "magnusg203@gmail.com", "contact" => "54278902", "role" => "Student Admin", "photo" => "img/magnus.jpg"],
    ["name" => "Ms. Rachel Gomez", "email" => "rachelg12@gmail.com", "contact" => "51672901", "role" => "Course Admin", "photo" => "img/rachel.webp"],
    ["name" => "Mr. Joe Miller", "email" => "joemill7@gmail.com", "contact" => "45671209", "role" => "Teacher Admin", "photo" => "img/joel.webp"],
    ["name" => "Ms. Joesphine Thompson", "email" => "joshth09@gmail.com", "contact" => "72901234", "role" => "Coordinatior", "photo" => "img/josephine.webp"],
    ["name" => "Nisha Gajurel", "email" => "gnisha@gmail.com", "contact" => "91414141", "role" => "Department Admin", "photo" => "img/nisha.jpg"]
  ];

  foreach ($admins as $admin): ?>
    <div class="admin-card">
        <img src="<?=htmlspecialchars($admin['photo']) ?>" alt="Photo of <?=htmlspecialchars($admin['name']) ?>" class="admin-photo">
      <div class="admin-info">
        <h3><?= htmlspecialchars($admin['name']) ?></h3>
        <p><strong>Email:</strong> <a href="mailto:<?= htmlspecialchars($admin['email']) ?>"style="color: #2980b9; text-decoration: underline;"><?= htmlspecialchars($admin['email']) ?></a></p>
        <p><strong>Contact:</strong> <?= htmlspecialchars($admin['contact']) ?></p>
        <p><strong>Role:</strong> <?= htmlspecialchars($admin['role']) ?></p>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<p><a href="staff.php" class="back-btn">← Back to Staff Page</a></p>


<footer>
  <section class="about-contact">
    <h2>Contact Us</h2>
    <div class="contact-container">
      <div class="contact-details">
        <p>📍 Sankt Petri Passage 10, 1165 København, Denmark</p>
        <p>📧 Email: contact@greenfieldschool.com</p>
        <p>📞 Phone: +45 123 5678</p>
      </div>
    </div>
  </section>
</footer>

<script>
  function openMenu() {
    document.getElementById("navLinks").style.right = "0";
  }
  function closeMenu() {
    document.getElementById("navLinks").style.right = "-200px";
  }
</script>

</body>
</html>
