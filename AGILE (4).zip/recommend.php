<?php
include 'session.php';
include 'db.php'; // Must create and expose $pdo (see note below)

$typeStmt = $pdo->query("SELECT DISTINCT type FROM course ORDER BY type");
$types = $typeStmt->fetchAll(PDO::FETCH_ASSOC);



if (isset($_POST['recommend'])) {
    try {
        // Check if course code already exists
        $check = $pdo->prepare("SELECT 1 FROM course WHERE code = :code");
        $check->execute([':code' => $_POST['code']]);

        if ($check->fetch()) {
            $_SESSION['message'] = "<p style='color:red;font-size:2rem'>Course code already exists.</p>";
        } else {
            // Handle file upload
            $targetDir = "img/";
            $fileName = basename($_FILES["image"]["name"]);
            /*$uniqueName = uniqid() . "_" . $fileName;*/
            $targetFilePath = $targetDir . $fileName;
            $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

            // Validate file type
            $validTypes = ['jpg', 'jpeg', 'png', 'gif'];
            if (in_array($fileType, $validTypes)) {
                if (!is_dir($targetDir)) {
                    mkdir($targetDir, 0755, true);
                }

                if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
                    // Insert into DB
                    $stmt = $pdo->prepare("
                        INSERT INTO course 
                        (code, name, description, type, credits, is_active, admin_id, status, image) 
                        VALUES 
                        (:code, :name, :description, :type, :credits, 1, :admin_id,  'pending', :image)
                    ");
                    $stmt->execute([
                        ':code' => $_POST['code'],
                        ':name' => $_POST['name'],
                        ':description' => $_POST['description'],
                        ':type' => $_POST['type'],
                        ':credits' => $_POST['credits'],
                        ':admin_id' => $_POST['admin_id'],
                        
                        ':image' => $targetFilePath
                    ]);
                    $_SESSION['message'] = "<p style='color:white; font-size:3rem;'>Course recommended successfully.</p>";
                } else {
                    $_SESSION['message'] = "<p style='color:red;font-size:3rem'>Failed to upload image.</p>";
                }
            } else {
                $_SESSION['message'] = "<p style='color:red;font-size:3rem'>Invalid image format. Allowed: jpg, jpeg, png, gif.</p>";
            }
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = "<p style='color:red;'>Error: " . $e->getMessage() . "</p>";
    }

    header("Location: recommend.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Recommend Course</title> <!-- Display page title -->
   <link rel="stylesheet" href="homepage.css"> <!-- Link to the homepage CSS -->
   <link href="img/logoo.png" rel="icon" type="image/webp"> <!-- Set favicon for the page -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome icons -->
   <script src="Navigation.js" defer></script> <!-- External JavaScript for navigation -->
</head>
    <style>
 /* Recommend Course Form Container */
 .container {
    max-width: 500px; /* reduced from 800px */
    width: 90%;
    margin: 30px auto;
    background-color: rgba(255, 255, 255, 0.95);
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 6px 10px rgba(0, 0, 0, 0.1);
    color: #003366;
 
 }

.container h2 {
    text-align: center;
    font-size: 2rem;
    margin-bottom: 20px;
}

form label {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-bottom: 15px;
    font-weight: bold;
    color: #003366;
}


input, select, button {
    padding: 12px;
    font-size: 1rem;
    border-radius: 6px;
    border: 1px solid #ccc;
    width: 100%;
    box-sizing: border-box;
}

button {
    background-color: #003366;
    color: white;
    border: none;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #001f4d;
}

/* Flash message styling */
.message {
    text-align: center;
    font-weight: bold;
    padding: 10px;
    border-radius: 6px;
    margin: 20px auto;
    width: 90%;
    max-width: 800px;
}

.message.success {
    background-color: #28a745;
    color: white;
}

.message.error {
    background-color: #dc3545;
    color: white;
}

.back-link {
    display: inline-block;
    margin: 10px 0;
    padding: 10px 20px;
    text-align:center;
    color:white;
    background: #007bff; 
    text-decoration: none;
    border-radius: 5px;
    width:150px;
}

.back-link:hover {
    text-decoration: underline;
}

/* Mobile Responsiveness */
@media (max-width: 768px) {
    .container {
        padding: 20px 15px;
    }

    .container h2 {
        font-size: 1.5rem;
    }

    input,
    button {
        font-size: 0.95rem;
        padding: 10px;
    }

    nav img {
        width: 100px;
        height: 100px;
    }

    .nav-links {
        width: 160px;
    }

    .message {
        font-size: 1rem;
    }
}


</style>
</head>
<body>

<section class="header">  
    <nav>
      <img src="img/logoo.png" alt="Logo" class="logo"> <!-- Display the university logo -->
   
      <div class="nav-links" id="navLinks">
         <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i> <!-- Close menu icon -->
         <ul>
            <li><a href="homepage.php">HOME</a></li> <!-- Home link -->
            <li><a href="course.php">COURSE</a></li> <!-- Contact link -->
            <li><a href="staff.php">STAFF</a></li> <!-- About link -->
            <li><a href="login.html">LOG IN</a></li> <!-- Administrator link -->
         </ul>
      </div>
      <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i> <!-- Open menu icon -->
    </nav>

<!-- Display Flash Messages -->
<?php

if (isset($_SESSION['message'])) {
    echo $_SESSION['message'];
    unset($_SESSION['message']);
}
?>
 <div class =  "container">

<h2>Recommend New Course</h2>
<form method="POST" enctype="multipart/form-data">
    <label>Code: <input name="code" required></label><br>
    <label>Name: <textarea name="name" required></textarea></label><br>
    <label>Image: <input type="file" name="image" required><br>
    <label>Description:<textarea name="description"required></textarea></label><br>
       
<label>Type:</label>
<select name="type" required>
    <option value="">-- Select Type --</option>
    <?php foreach ($types as $type): ?>
        <option value="<?= htmlspecialchars($type['type']) ?>">
            <?= htmlspecialchars($type['type']) ?>
        </option>
    <?php endforeach; ?>
</select><br>

    <label>Credits: <input name="credits" type="number" step="0.5" required></label><br>
    <label>Admin ID: <input name="admin_id" required></label><br>
  
    <button name="recommend">Recommend Course</button><br><br>
</form>

<a href="course_dashboard.php" class="back-link">← Back </a>
    </div>
</section>

<!-- JavaScript for toggling the menu visibility -->
   <script>
      var navLinks = document.getElementById("navLinks");
      function openMenu() {
         navLinks.style.right = "0"; // Open the menu by setting the style to right = 0
      }
      function closeMenu() {
         navLinks.style.right = "-200px"; // Close the menu by shifting it off-screen
      }
   </script>


</body>
</html>
