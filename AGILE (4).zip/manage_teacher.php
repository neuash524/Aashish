<?php
include 'session.php';
include 'db.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin','Course Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();
// ===== UNASSIGN TEACHER FROM COURSE =====
$confirmationDetails = null;

// Handle Step 1: Display confirmation form
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['initiate_unassign'])) {
    $code = $_POST['course_code'];

    // Get course and teacher info
    $stmt = $pdo->prepare("
        SELECT c.code, c.name AS course_name, t.teacher_id, t.name AS teacher_name
        FROM course c
        LEFT JOIN teacher t ON c.teacher_id = t.teacher_id
        WHERE c.code = :code
    ");
    $stmt->execute(['code' => $code]);
    $confirmationDetails = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$confirmationDetails['teacher_id']) {
        $_SESSION['message'] = "This course does not have a teacher assigned.";
        $_SESSION['message_type'] = "error";
        header("Location: manage_teacher.php");
        exit();
    }
}

// Handle Step 2: Actually unassign the teacher
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['confirm_unassign'])) {
    $code = $_POST['code'];

    try {
        $pdo->beginTransaction();

        $stmt1 = $pdo->prepare("UPDATE course SET teacher_id = NULL WHERE code = :code");
        $stmt1->execute(['code' => $code]);

        $stmt2 = $pdo->prepare("UPDATE teacher SET code = NULL WHERE code = :code");
        $stmt2->execute(['code' => $code]);

        $pdo->commit();
        $_SESSION['message'] = "Teacher successfully unassigned from course.";
        $_SESSION['message_type'] = "success";
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['message'] = "Error unassigning teacher: " . $e->getMessage();
        $_SESSION['message_type'] = "error";
    }

    header("Location: manage_teacher.php");
    exit();
}
// ===== ASSIGN TEACHER TO COURSE =====
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['action']) && $_POST['action'] === 'assign') {
    $code = $_POST['code'] ?? null;
    $teacher_id = $_POST['teacher_id'] ?? null;

    if ($code && $teacher_id) {
        try {
            $pdo->beginTransaction();

            // Unassign any teacher from this course
            $stmt1 = $pdo->prepare("UPDATE teacher SET code = NULL WHERE code = :code");
            $stmt1->execute(['code' => $code]);

            // Unassign this teacher from any other course
            $stmt2 = $pdo->prepare("UPDATE course SET teacher_id = NULL WHERE teacher_id = :teacher_id");
            $stmt2->execute(['teacher_id' => $teacher_id]);

            // Assign teacher to course
            $stmt3 = $pdo->prepare("UPDATE course SET teacher_id = :teacher_id WHERE code = :code");
            $stmt3->execute(['teacher_id' => $teacher_id, 'code' => $code]);

            // Assign course to teacher
            $stmt4 = $pdo->prepare("UPDATE teacher SET code = :code WHERE teacher_id = :teacher_id");
            $stmt4->execute(['code' => $code, 'teacher_id' => $teacher_id]);

            $pdo->commit();
            $_SESSION['message'] = "Teacher assigned to course successfully.";
        } catch (Exception $e) {
            $pdo->rollBack();
            $_SESSION['message'] = "Error assigning teacher: " . $e->getMessage();
        }
    } else {
        $_SESSION['message'] = "Please select both a course and a teacher.";
    }
    header("Location: manage_teacher.php");
    exit();
}

// ===== FETCH DATA FOR FORMS =====
$courses = $pdo->query("SELECT code, name FROM course")->fetchAll(PDO::FETCH_ASSOC);
$teachers = $pdo->query("SELECT teacher_id, name FROM teacher")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Manage Teacher</title>
   <link rel="stylesheet" href="homepage.css">
   <link href="img/logoo.png" rel="icon" type="image/webp">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
   <style>
    body{
        padding:0;
    }
.container {
    width: 90%;
    max-width: 600px;
    background-color: rgba(255, 255, 255, 0.95);
    margin: 60px auto;
    padding: 20px 25px;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
    color: #003366;
}

h2 {
    text-align: center;
    font-size: 1.5rem;
    margin-bottom: 30px;
}

form {
    display: flex;
    flex-direction: column;
    gap: 15px;
    margin-bottom: 40px;
    font-weight: bold;
}

input, select, button {
    padding: 12px;
    font-size: 1rem;
    border-radius: 6px;
    border: 1px solid #ccc;
    width: 100%;
    box-sizing: border-box;
}

button {
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.assign-btn {
    background-color: #003366;
    color: white;
}

.assign-btn:hover {
    background-color: #002244;
}

.unassign-btn {
    background-color: #dc3545;
    color: white;
}

.unassign-btn:hover {
    background-color: #b52a3a;
}

.message {
    text-align: center;
    font-weight: bold;
    padding: 10px;
    border-radius: 6px;
    margin: 15px auto;
    width: 90%;
    max-width: 600px;
}

.message.success {
    background-color: #28a745;
    color: white;
}

.message.error {
    background-color: #dc3545;
    color: white;
}
.message.info{
     background-color: #28a745;
    color: white;
}
.back-btn {
    display: inline-block;
    padding: 12px 24px;
    background: blue;
    color: white;
    text-decoration: none;
    font-weight: bold;
    border-radius: 6px;
    transition: background 0.3s ease, transform 0.2s ease;
    box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
    border: 1px solid rgba(255, 255, 255, 0.3);
}
.confirmation {
    width: 90%;
    max-width: 600px;
    background-color: rgba(255, 255, 255, 0.95);
    margin: 60px auto;
    padding: 20px 25px;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
    color: #003366;


    
    background-color: #fff3cd; color:black; border: 1px solid #ffeeba;
}
.confirmation p{
    color:black;
}

.back-btn:hover {
    background: blue;
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
}

@media (max-width: 768px) {
    .container {
        padding: 20px 15px;
    }

    .container h2 {
        font-size: 1.5rem;
    }

    input,
    button {
        font-size: 1rem;
        padding: 10px;
    }

    nav img {
        width: 100px;
        height: 100px;
    }

    .nav-links {
        width: 160px;
    }

    .message {
        font-size: 1rem;
    }
}
   </style>
</head>
<body>
<section class="header">  
<nav>
    <img src="img/logoo.png" alt="Logo" class="logo">
    <div class="nav-links" id="navLinks">
        <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i>
        <ul>
            <li><a href="homepage.php">HOME</a></li>
            <li><a href="courses.php">COURSE</a></li>
            <li><a href="staff.php">STAFF</a></li>
            <li><a href="login.php">LOG IN</a></li>
        </ul>
    </div>
    <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i>
</nav>

<?php
if (isset($_SESSION['message'])) {
    $type = $_SESSION['message_type'] ?? 'info';
    echo "<div class='message $type'>{$_SESSION['message']}</div>";
    unset($_SESSION['message'], $_SESSION['message_type']);
}
?>

<?php if ($confirmationDetails): ?>
    <div class="confirmation">
        <h3>Confirm Deletion</h3>
        <p><strong>Course:</strong> <?= htmlspecialchars($confirmationDetails['code']. ' - ' . $confirmationDetails['course_name']) ?> </p>
        <p><strong>Assigned Teacher:</strong> <?= htmlspecialchars($confirmationDetails['teacher_id']. ' - ' . $confirmationDetails['teacher_name']) ?></p>

        <form method="post" style="display:inline;">
            <input type="hidden" name="confirm_unassign" value="true">
            <input type="hidden" name="code" value="<?= htmlspecialchars($confirmationDetails['code']) ?>">
            <button class="unassign-btn" style= "margin-left: 10px; width:25%">Confirm</button>
        </form>

        <a href="manage_teacher.php" class="back-btn" style="margin-left: 10px;">Cancel</a>
    </div>
<?php endif; ?>



<div class="container">
    <h1 style="color:blue; text-align:center;">Manage Teacher Assignment</h1> <br><br>

    <!-- ===== ASSIGN FORM ===== -->
    <h2>Assign Teacher To Course</h2>
    <form method="post">
        <input type="hidden" name="action" value="assign">

        <label>Course:</label>
        <select name="code" required>
            <option value="">-- Select Course --</option>
            <?php foreach ($courses as $course): ?>
                <option value="<?= htmlspecialchars($course['code']) ?>">
                    <?= htmlspecialchars($course['code'] . ' - ' . $course['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Teacher:</label>
        <select name="teacher_id">
            <option value="">-- Select Teacher --</option>
            <?php foreach ($teachers as $teacher): ?>
                <option value="<?= htmlspecialchars($teacher['teacher_id']) ?>">
                    <?= htmlspecialchars($teacher['teacher_id'] . ' - ' . $teacher['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button class="assign-btn">Assign Teacher</button>
    </form>

    <!-- ===== UNASSIGN FORM ===== -->
    <h2>Unassign Teacher from Course</h2>
   <form method="post" id="unassignForm">
    <input type="hidden" name="initiate_unassign" value="true">
    <label for="course_code">Course:</label>
    <select name="course_code" required>
        <option value="">-- Select Course --</option>
        <?php foreach ($courses as $course): ?>
            <option value="<?= htmlspecialchars($course['code']) ?>">
                <?= htmlspecialchars($course['code'] . ' - ' . $course['name']) ?>
            </option>
        <?php endforeach; ?>
    </select><br><br>

    <button type="button" class="unassign-btn" onclick="confirmUnassign()">Unassign Teacher</button>
</form>


    <div style="display: flex; justify-content:center">
        <a href="course_dashboard.php" class="back-btn">Back</a>
    </div>
    
</div>
</section>
<script>
function confirmUnassign() {
    const form = document.getElementById("unassignForm");
    const selectedCourse = form.course_code.value;

    if (!selectedCourse) {
        alert("Please select a course first.");
        return;
    }

    const confirmFirst = confirm("Are you sure you want to unassign the teacher from this course?");
    if (confirmFirst) {
        form.submit(); // proceeds to PHP and shows final confirmation
    }
}
</script>

</body>
</html>