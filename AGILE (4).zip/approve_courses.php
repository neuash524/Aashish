<?php
include 'session.php';
include 'db.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin','Department Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();

// Fetch pending courses
$stmt = $pdo->query("SELECT code, name FROM course WHERE status = 'pending'");
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle approval or rejection
if (isset($_POST['action']) && isset($_POST['code'])) {
    $code = $_POST['code'];
    $status = $_POST['action'] === 'approve' ? 'approved' : 'rejected';

    try {
        $stmt = $pdo->prepare("UPDATE course SET status = :status WHERE code = :code");
        $stmt->execute(['status' => $status, 'code' => $code]);
        $_SESSION['message'] = "<p style='color:green;'>Course $status successfully.</p>";
    } catch (PDOException $e) {
        $_SESSION['message'] = "<p style='color:red;'>Error updating course: " . $e->getMessage() . "</p>";
    }
    header("Location: approve_courses.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Approve Courses</title> <!-- Display page title -->
   <link rel="stylesheet" href="homepage.css"> <!-- Link to the homepage CSS -->
   <link href="img/logoo.png" rel="icon" type="image/webp"> <!-- Set favicon for the page -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome icons -->
   <script src="Navigation.js" defer></script> <!-- External JavaScript for navigation -->
</head>
    <style>
body {
  margin: 0;
  padding: 0;
  height: 100vh;
  width: 100vw;
  background-image: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7)), url('img/build.jpg');
  background-size: cover; /* covers entire screen */
  background-repeat: no-repeat;
  background-position: center center;
  background-attachment: fixed;
  font-family: sans-serif;
}

/* Page Heading */
h2 {
  text-align: center;
  color: #444;
  margin-bottom: 30px;
}

/* Table Styling */
table {
  width: 100%;
  border-collapse: collapse;
  background: white;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  overflow: hidden;
}

th, td {
  padding: 12px 16px;
  text-align: left;
}

th {
  background: linear-gradient(135deg, rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  color: white;
}

td {
  background-color: #fafafa;
}

tr:nth-child(even) td {
  background-color: #f0f0f0;
}

.button-container {
  text-align: center;
  margin-top: 30px;
}

button {
  background: linear-gradient(135deg, rgba(200, 45, 211, 0.8), rgba(68, 175, 109, 0.8));
  color: white;
  border: none;
  padding: 10px 25px;
  font-weight: bold;
  border-radius: 6px;
  cursor: pointer;
  transition: background 0.3s ease;
}

button:hover {
  background: linear-gradient(135deg, rgba(68, 175, 109, 0.9), rgba(200, 45, 211, 0.9));
}


/* Approve/Reject Button Styles */
form button {
  padding: 8px 14px;
  margin: 0 5px;
  background: linear-gradient(135deg, rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: bold;
  transition: background 0.3s ease;
}

form button:hover {
  background: linear-gradient(135deg, rgba(68, 175, 109, 0.8), rgba(200, 45, 211, 0.8));
}

/* Message Styling (if using sessions for feedback) */
.message {
  margin: 15px auto;
  padding: 10px 20px;
  background: #e0ffe5;
  border: 1px solid #70cf87;
  border-radius: 5px;
  color: #2a7035;
  width: fit-content;
  text-align: center;
}
</style>
</head>
<body>
    <section class="header">  
    <nav>
      <img src="img/logoo.png" alt="Logo" class="logo"> <!-- Display the university logo -->
   
      <div class="nav-links" id="navLinks">
         <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i> <!-- Close menu icon -->
         <ul>
            <li><a href="homepage.php">HOME</a></li> <!-- Home link -->
            <li><a href="courses.php">COURSE</a></li> <!-- Contact link -->
            <li><a href="staff.php">STAFF</a></li> <!-- About link -->
            <li><a href="login.php">LOG IN</a></li> <!-- Administrator link -->
         </ul>
      </div>
      <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i> <!-- Open menu icon -->
    </nav>
    <h2>Pending Course Approvals</h2>
    <?php
    if (isset($_SESSION['message'])) {
        echo $_SESSION['message'];
        unset($_SESSION['message']);
    }
    ?>
    <table border="1" cellpadding="10">
        <tr>
            <th>Course Code</th>
            <th>Course Name</th>
            <th>Action</th>
        </tr>
        <?php foreach ($courses as $course): ?>
        <tr>
            <td><?= htmlspecialchars($course['code']) ?></td>
            <td><?= htmlspecialchars($course['name']) ?></td>
            <td>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="code" value="<?= $course['code'] ?>">
                    <button name="action" value="approve">Approve</button>
                    <button name="action" value="reject">Reject</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <div class="button-container">
  <button onclick="window.location.href='all_users.php'">Go Back</button>
</div>
</section>
</body>
</html>
