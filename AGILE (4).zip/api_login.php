<?php
session_start();
require 'db.php'; // $pdo
require 'functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$user_name = $_POST['user_name'] ?? '';
$password = $_POST['password'] ?? '';

if (!$user_name || !$password) {
    echo json_encode(['success' => false, 'message' => 'Username and password are required']);
    exit;
}

$user_types = ['student', 'teacher', 'admin'];

foreach ($user_types as $user_type) {
    $stmt = $pdo->prepare("SELECT * FROM $user_type WHERE user_name = ?");
    $stmt->execute([$user_name]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        if (password_verify($password, $user['hash_password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user[$user_type . '_id'];
            $_SESSION['user_name'] = $user['user_name'];
            $_SESSION['user_type'] = $user_type;
            // If you store role in DB, otherwise set default
            $_SESSION['role'] = $user['role'] ?? $user_type;
            $_SESSION['last_activity'] = time();

            // OTP
            $_SESSION['otp'] = (string) random_int(100000, 999999);
            $_SESSION['otp_expires'] = time() + 300;
            logActivity($pdo, $_SESSION['user_id'], $user_type, 'Logged in');

            if ($user_type === 'admin') {
                $update = $pdo->prepare("UPDATE admin SET last_login = NOW() WHERE admin_id = ?");
                $update->execute([$_SESSION['user_id']]);
            }

            echo json_encode([
                'success' => true,
                'message' => 'Login successful, OTP sent',
                'otp' => $_SESSION['otp'] // For testing only! Remove in production.
            ]);
            exit;
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid credentials']);
            exit;
        }
    }
}

echo json_encode(['success' => false, 'message' => 'User not found']);
exit;
?>