<?php
require 'db.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();

// Allow both admin and teacher
if (!in_array($_SESSION['user_type'], ['admin', 'teacher'])) {
    header('Location: unauthorized.php');
    exit();
}

$userName = htmlspecialchars($_SESSION['user_name']);

try {
    $stmt = $pdo->query("SELECT teacher_id, name, email, qualification, user_name, code, admin_id FROM teacher");
    $teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database query failed: " . $e->getMessage());
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>All Teachers</title>
  <link rel="stylesheet" href="edit_teacher.css"> <!-- Optional -->
  <style>

    .header {
  display: flex;
  align-items: center;
  padding: 20px;
  background-color:linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7));
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.logo {
  height: 60px;
  width: auto;
  margin-right: 20px;
}

.system-title {
  font-size: 20px;
  font-weight: bold;
  color: #4a148c; /* Deep purple */
  align: center;
}
   .teacher-table-container {
  max-width: 1000px;
  margin: 40px auto;
  padding: 20px;
  background-color: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  overflow-x: auto;
}

.teacher-table {
  width: 100%;
  border-collapse: collapse;
  font-family: 'Segoe UI', sans-serif;
}

.teacher-table th, .teacher-table td {
  padding: 12px 16px;
  border-bottom: 1px solid #e0e0e0;
  text-align: left;
  font-size: 15px;
  color: #333;
}

.teacher-table th {
  background-color: #7b1fa2;
  color: #fff;
  font-weight: bold;
}

.teacher-table tr:hover {
  background-color: #f9f9f9;
}

@media screen and (max-width: 768px) {
  .teacher-table thead {
    display: none;
  }

  .teacher-table tr {
    display: block;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 8px;
    overflow: hidden;
  }

  .teacher-table td {
    display: flex;
    justify-content: space-between;
    padding: 12px;
    font-size: 14px;
    border-bottom: 1px solid #eee;
  }

  .teacher-table td::before {
    content: attr(data-label);
    font-weight: bold;
    color: #555;
    flex: 1;
  }
}

</style>
</head>
<body>

<div class="header">
  <img src="img/logoo.png" alt="School Logo" class="logo">
  <div class="system-title"><strong>All Registered Teachers</strong></div>
</div>
<div class="teacher-table-container">
<table class="teacher-table">
  <thead>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Email</th>
      <th>Qualification</th>
      <th>Username</th>
      <th>Code</th>
      <th>Admin ID</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($teachers as $row): ?>
      <tr>
        <td data-label="ID"><?= htmlspecialchars($row['teacher_id']) ?></td>
        <td data-label="Name"><?= htmlspecialchars($row['name']) ?></td>
        <td data-label="Email"><?= htmlspecialchars($row['email']) ?></td>
        <td data-label="Qualification"><?= htmlspecialchars($row['qualification']) ?></td>
        <td data-label="Username"><?= htmlspecialchars($row['user_name']) ?></td>
        <td data-label="Code"><?= htmlspecialchars($row['code']) ?></td>
        <td data-label="Admin ID"><?= htmlspecialchars($row['admin_id']) ?></td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<a class="back-btn" href="user_management.php" >← Go Back</a>

</body>
</html>
