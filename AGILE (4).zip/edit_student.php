<?php
require 'authentication_middleware.php';
require 'authorization_middleware.php';

allowOnlyUserType('student'); // Only student can access

require_once 'db.php';

$student = null;
$student_id = $_SESSION['user_id'] ?? null;

if ($student_id) {
    // If form is submitted, update the student record
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $newName = $_POST['name'] ?? '';
        $newEmail = $_POST['email'] ?? '';

        if (!empty($newName) && !empty($newEmail)) {
            $updateStmt = $pdo->prepare("UPDATE student SET name = ?, email = ? WHERE student_id = ?");
            $updateStmt->execute([$newName, $newEmail, $student_id]);

            $message = "Profile updated successfully!";
        } else {
            $message = "Please fill in all fields.";
        }
    }

    // Fetch (or re-fetch) student data
    $stmt = $pdo->prepare("SELECT student_id, name, email, class, admin_id, is_on_scholarship FROM student WHERE student_id = ?");
    $stmt->execute([$student_id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Profile</title>
  <style>
  * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Segoe UI', sans-serif;
  background-image: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7)), url("img/build.jpg");
  background-size: cover;
  background-position: center;
  color: #fff;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 80px 20px;
  position: relative;
}

body::before {
  content: '';
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
}

.form-container {
  background: rgba(255, 255, 255, 0.95);
  color: #333;
  padding: 40px 30px;
  border-radius: 16px;
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
  max-width: 500px;
  width: 100%;
  text-align: center;
}

h2 {
  font-size: 32px;
  margin-bottom: 25px;
}

label {
  display: block;
  margin-bottom: 8px;
  font-weight: bold;
  text-align: left;
}

input {
  width: 100%;
  padding: 12px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 16px;
}

button {
  width: 100%;
  padding: 12px;
  background-color: #0056b3;
  color: white;
  font-weight: bold;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.3s ease;
  font-size: 16px;
}

button:hover {
  background-color: #00408a;
}

.message {
  font-weight: bold;
  margin-bottom: 20px;
  color: green;
  text-align: center;
}

.error-message {
  color: red;
}

.back-btn {
  background: none;
  color: #333;
  border: none;
  font-weight: bold;
  cursor: pointer;
  text-decoration: underline;
  font-size: 14px;
  margin-top: 10px;
  width: auto;
  padding: 0;
}

.back-btn:hover {
  text-decoration: none;
  background-color: #0056b3;
  color: white;
  border-radius: 6px;
  padding: 6px 12px;
}

.header {
  width: 100%;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  position: absolute;
  top: 10px;
  left: 10px;
  z-index: 10;
}

.logo {
  height: 60px;
  width: auto;
}

</style>

</head>
<body>
<div class="header">
  <img src="img/logoo.png" alt="School Logo" class="logo">
</div>

<div class="form-container">
  <h2>Edit Your Profile</h2>

  <?php if (isset($message)): ?>
    <div class="message <?= strpos($message, 'successfully') === false ? 'error-message' : '' ?>">
      <?= htmlspecialchars($message) ?>
    </div>
  <?php endif; ?>

  <form method="POST">
    <label>Name:</label>
    <input type="text" name="name" value="<?= htmlspecialchars($student['name']) ?>" required>

    <label>Email:</label>
    <input type="email" name="email" value="<?= htmlspecialchars($student['email']) ?>" required>

    <button type="submit">Save Changes</button>
  </form>

    <form action="student_dashboard.php" method="get">
    <button type="submit" class="back-btn">⬅ Back to Student Dashboard</button>
  </form>
</div>

</body>
</html>
