<?php
header('Content-Type: application/json');

require_once 'UserManager.php';  // Include your class with updateUserStatus method

try {
    $pdo = new PDO('mysql:host=localhost;dbname=student_record_system;charset=utf8', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

// Get POST data
$id = $_POST['id'] ?? null;
$role = $_POST['role'] ?? '';
$action = $_POST['action'] ?? '';

// Basic validation
if (!$id || !$role || !$action) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

$userManager = new UserManager($pdo);  // Adjust if your class name is different

try {
    $updated = $userManager->updateUserStatus($id, $role, $action);
    if ($updated) {
        echo json_encode(['success' => true, 'message' => 'User status updated']);
    } else {
        echo json_encode(['success' => false, 'message' => 'User not found or no changes made']);
    }
} catch (InvalidArgumentException $ex) {
    echo json_encode(['success' => false, 'message' => $ex->getMessage()]);
} catch (Exception $ex) {
    echo json_encode(['success' => false, 'message' => 'Server error']);
}

?>