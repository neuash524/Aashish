
<?php
session_start();
require 'UserManager.php';
require 'db.php'; // replace with your PDO connection file
require 'sanitize_input_middleware.php';
require 'functions.php';

$role = $_GET['role'] ?? null;
$id = $_GET[$role . '_id'] ?? null;
$userManager = new UserManager($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $updateSuccess = $userManager->updateUser($_POST['user_role'], $_POST);

    if ($updateSuccess) {
        $_SESSION['success_message'] = ucfirst($_POST['user_role']) . " updated successfully!";
        $_SESSION['user_details'] = $_POST; // You can selectively pass sanitized fields
    } else {
        $_SESSION['error_message'] = "Update failed or no changes detected.";
    }

    header("Location: " . $_SERVER['PHP_SELF'] . "?role=" . $_POST['user_role'] . "&" . $_POST['user_role'] . "_id=" . ($_POST['student_id'] ?? $_POST['teacher_id'] ?? $_POST['admin_id']));
    exit;
} elseif ($role && $id) {
    switch ($role) {
        case 'admin':
            $user = $userManager->getUserById('admin', $id);
            if ($user) {
                // Admin form HTML
                ?>
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8" />
                    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
                    <link rel="stylesheet" href="userstyle.css">
                    <title>Update Admin</title>
                </head>
                <body>
                <div class="header">
                    <img src="img/logoo.png" alt="School Logo" class="logo">
                    <div class="system-title"><strong>User Management System</strong></div>
                </div>
                <div class="dashboard-container">
                    <div class="hamburger" onclick="toggleSidebar()">☰</div>
                    <aside class="sidebar">
                        <h2>Dashboard</h2>
                        <ul>
                            <li><a href="homepage.php">Home</a></li>
                            <li><a href="user_management.php">Manage Users</a></li>
                            <li><a href="dashboard.php">Courses</a></li>
                            <li><a href="about.php">About Us</a></li>
                        </ul>      
                    </aside>
                    <main class="main-content">
                        <div class="form-box">
                            <legend><strong>Update Admin</strong></legend>
                            <form method="post">
                                <input type="hidden" name="user_role" value="admin">
                                <input type="hidden" name="admin_id" value="<?= htmlspecialchars($user['admin_id']) ?>">
                                Name: <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>"><br>
                                Email: <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>"><br>
                                <label for="role">Admin Role:</label>
                                <input type="text" name="role" id="role" value="<?= htmlspecialchars($user['role'] ?? '') ?>" required><br>
                                Contact: <input type="text" name="contact" value="<?= htmlspecialchars($user['contact']) ?>"><br>
                                Username: <input type="text" name="user_name" value="<?= htmlspecialchars($user['user_name']) ?>"><br>
                                <label>Status:
                                <select name="status" required>
                                <option value="pending" <?= $user['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                                <option value="approved" <?= $user['status'] === 'approved' ? 'selected' : '' ?>>Approved</option>
                                <option value="rejected" <?= $user['status'] === 'rejected' ? 'selected' : '' ?>>Rejected</option>
                                </select>
                                </label><br>

                                <button type="submit">Update Admin</button>
                            </form>
                            <?php
                            if (isset($_SESSION['success_message'])) {
                                echo "<div class='success-message' style='background:#d4edda; border:1px solid #c3e6cb; padding:10px; margin-bottom:20px; color:#155724;'>";
                                echo "<h3>" . htmlspecialchars($_SESSION['success_message']) . "</h3>";
                                echo "<p><strong>Name:</strong> " . htmlspecialchars($_SESSION['user_details']['name']) . "</p>";
                                echo "<p><strong>Email:</strong> " . htmlspecialchars($_SESSION['user_details']['email']) . "</p>";
                                if (isset($_SESSION['user_details']['admin_role'])) {
                                    echo "<p><strong>Admin Role:</strong> " . htmlspecialchars($_SESSION['user_details']['admin_role']) . "</p>";
                                }
                                if (isset($_SESSION['user_details']['contact'])) {
                                    echo "<p><strong>Contact:</strong> " . htmlspecialchars($_SESSION['user_details']['contact']) . "</p>";
                                }
                                if (isset($_SESSION['user_details']['status'])) {
                                    echo "<p><strong>Status:</strong> " . htmlspecialchars($_SESSION['user_details']['status']) . "</p>";
                                }
                                echo "</div>";
                                unset($_SESSION['success_message']);
                                unset($_SESSION['user_details']);
                            }
                            ?>
                        </div>
                        <br><br>
                        <a href="user_management.php"><button>Go Back</button></a>
                    </main>
                </div>
                </body>
                </html>
                <?php
            } else {
                echo "Admin not found.";
            }
            break;

        case 'teacher':
            $user = $userManager->getUserById('teacher', $id);
            if ($user) {
                // Teacher form HTML
                ?>
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8" />
                    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
                    <link rel="stylesheet" href="/AGILE2025/userstyle.css">
                    <title>Update Teacher</title>
                </head>
                <body>
                <div class="header">
                    <img src="img/logoo.png" alt="School Logo" class="logo">
                    <div class="system-title"><strong>User Management System</strong></div>
                </div>
                <div class="dashboard-container">
                    <div class="hamburger" onclick="toggleSidebar()">☰</div>
                    <aside class="sidebar">
                        <h2>Dashboard</h2>
                        <ul>
                            <li><a href="homepage.php">Home</a></li>
                            <li><a href="user_management.php">Manage Users</a></li>
                            <li><a href="course.php">Courses</a></li>
                            <li><a href="about.php">About Us</a></li>
                        </ul>      
                    </aside>
                    <main class="main-content">
                        <div class="form-box">
                            <legend><strong>Update Teacher</strong></legend>
                            <form method="post">
                                <input type="hidden" name="user_role" value="teacher">
                                <input type="hidden" name="teacher_id" value="<?= htmlspecialchars($user['teacher_id']) ?>">
                                Name: <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>"><br>
                                Email: <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>"><br>
                                Qualification: <input type="text" name="qualification" value="<?= htmlspecialchars($user['qualification']) ?>"><br>
                                Username: <input type="text" name="user_name" value="<?= htmlspecialchars($user['user_name']) ?>"><br>
                                Photo(leave blank to keep existing): <input type="file" name="photo"><br>
                                 <?php if (!empty($user['photo'])): ?>
                                     <img src="uploads/<?= htmlspecialchars($user['photo']) ?>" width="100"><br>
                                  <?php endif; ?>
                                Description: <input type="text" name="description" value="<?= htmlspecialchars($user['description']) ?>"><br>
                                <label>Status:
                                <select name="status" required>
                                <option value="pending" <?= $user['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                                <option value="approved" <?= $user['status'] === 'approved' ? 'selected' : '' ?>>Approved</option>
                                <option value="rejected" <?= $user['status'] === 'rejected' ? 'selected' : '' ?>>Rejected</option>
                                </select>
                                </label><br>
                                <?php if (!empty($teacher['code'])): ?>
                                <label>Course Code</label>
                                <input type="text" name="code" value="<?= htmlspecialchars($teacher['code']) ?>" readonly>
                                <?php else: ?>
                                <p>No course assigned yet</p>
                                <input type="hidden" name="code" value="">
                                <?php endif; ?>
                                <input type="hidden" name="admin_id" value="<?= htmlspecialchars($user['admin_id']) ?>">
                                <p><strong>Admin ID:</strong> <?= htmlspecialchars($user['admin_id']) ?></p>
                                <button type="submit">Update Teacher</button>
                            </form>
                            <?php
                            if (isset($_SESSION['success_message'])) {
                                echo "<div class='success-message' style='background:#d4edda; border:1px solid #c3e6cb; padding:10px; margin-bottom:20px; color:#155724;'>";
                                echo "<h3>" . htmlspecialchars($_SESSION['success_message']) . "</h3>";
                                echo "<p><strong>Name:</strong> " . htmlspecialchars($_SESSION['user_details']['name']) . "</p>";
                                echo "<p><strong>Email:</strong> " . htmlspecialchars($_SESSION['user_details']['email']) . "</p>";
                                echo "<p><strong>Updated Qualification:</strong> " . htmlspecialchars($_SESSION['user_details']['qualification']) . "</p>";
                                 // Display photo as an image if available
                                if (!empty($_SESSION['user_details']['photo'])) {
                                $photo = htmlspecialchars($_SESSION['user_details']['photo']);
                                echo "<p><strong>Updated Photo:</strong></p>";
                                echo "<img src='uploads/$photo' alt='Teacher Photo' style='max-width:200px; height:auto; border:1px solid #ccc; padding:4px;'>";
                                } else {
                                echo "<p><strong>Updated Photo:</strong> N/A</p>";
                                }
    
                                echo "<p><strong>Updated Description:</strong> " . nl2br(htmlspecialchars($_SESSION['user_details']['description'] ?? 'N/A')) . "</p>";
                                echo "<p><strong>Updated Status:</strong> " . htmlspecialchars($_SESSION['user_details']['status'] ?? 'N/A') . "</p>";
                                echo "</div>";
                                unset($_SESSION['success_message']);
                                unset($_SESSION['user_details']);
                            }
                            ?>
                        </div>
                        <br><br>
                        <a href="user_management.php"><button>Go Back</button></a>
                    </main>
                </div>
                </body>
                </html>
                <?php
            } else {
                echo "Teacher not found.";
            }
            break;

        case 'student':
            $user = $userManager->getUserById('student', $id);
            if ($user) {
                // Student form HTML
                ?>
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8" />
                    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
                    <link rel="stylesheet" href="/AGILE2025/userstyle.css">
                    <title>Update Student</title>
                </head>
                <body>
                <div class="header">
                    <img src="img/logoo.png" alt="School Logo" class="logo">
                    <div class="system-title"><strong>User Management System</strong></div>
                </div>
                <div class="dashboard-container">
                    <div class="hamburger" onclick="toggleSidebar()">☰</div>
                    <aside class="sidebar">
                        <h2>Dashboard</h2>
                        <ul>
                            <li><a href="homepage.php">Home</a></li>
                            <li><a href="user_management.php">Manage Users</a></li>
                            <li><a href="dashboard.php">Courses</a></li>
                            <li><a href="about.php">About Us</a></li>
                        </ul>      
                    </aside>
                    <main class="main-content">
                        <div class="form-box">
                            <legend><strong>Update Student</strong></legend>
                            <form method="post">
                                <input type="hidden" name="user_role" value="student">
                                <input type="hidden" name="student_id" value="<?= htmlspecialchars($user['student_id']) ?>">
                                Name: <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>"><br>
                                Email: <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>"><br>
                                Class: <input type="text" name="class" value="<?= htmlspecialchars($user['class']) ?>"><br>
                                Scholarship: <select name="is_on_scholarship">
                                    <option value="1" <?= $user['is_on_scholarship'] ? 'selected' : '' ?>>Yes</option>
                                    <option value="0" <?= !$user['is_on_scholarship'] ? 'selected' : '' ?>>No</option>
                                </select><br>
                                Username: <input type="text" name="user_name" value="<?= htmlspecialchars($user['user_name']) ?>"><br>
                                <label>Status:
                                <select name="status" required>
                                <option value="pending" <?= $user['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                                <option value="approved" <?= $user['status'] === 'approved' ? 'selected' : '' ?>>Approved</option>
                                <option value="rejected" <?= $user['status'] === 'rejected' ? 'selected' : '' ?>>Rejected</option>
                                </select>
                                </label><br>
                                <input type="hidden" name="admin_id" value="<?= htmlspecialchars($user['admin_id']) ?>">
                                <p><strong>Admin ID:</strong> <?= htmlspecialchars($user['admin_id']) ?></p>
                                <button type="submit">Update Student</button>
                            </form>
                            <?php
                            if (isset($_SESSION['success_message'])) {
                                echo "<div class='success-message' style='background:#d4edda; border:1px solid #c3e6cb; padding:10px; margin-bottom:20px; color:#155724;'>";
                                echo "<h3>" . htmlspecialchars($_SESSION['success_message']) . "</h3>";
                                echo "<p><strong>Name:</strong> " . htmlspecialchars($_SESSION['user_details']['name']) . "</p>";
                                echo "<p><strong>Email:</strong> " . htmlspecialchars($_SESSION['user_details']['email']) . "</p>";
                                echo "<p><strong>Updated Class:</strong> " . htmlspecialchars($_SESSION['user_details']['class']) . "</p>";
                                echo "<p><strong>Updated Status:</strong> " . htmlspecialchars($_SESSION['user_details']['status']) . "</p>";
                                echo "<p><strong>On Scholarship:</strong> " . ($_SESSION['user_details']['is_on_scholarship'] ? 'Yes' : 'No') . "</p>";
                                echo "</div>";
                                unset($_SESSION['success_message']);
                                unset($_SESSION['user_details']);
                            }
                            ?>
                        </div>
                        <br><br>
                        <a href="user_management.php"><button>Go Back</button></a>
                    </main>
                </div>
                </body>
                </html>
                <?php
            } else {
                echo "Student not found.";
            }
            break;
            default:
            echo "Invalid role.";
        }
    } else {
    echo "Missing role or ID in URL.";
  }



 if (isset($_SESSION['info_message'])) {
    echo "<div class='info-message' style='background:#fff3cd; border:1px solid #ffeeba; padding:10px; margin-bottom:20px; color:#856404;'>";
    echo "<h3>" . htmlspecialchars($_SESSION['info_message']) . "</h3>";
    echo "<p><strong>Name:</strong> " . htmlspecialchars($_SESSION['user_details']['name']) . "</p>";
    echo "<p><strong>Email:</strong> " . htmlspecialchars($_SESSION['user_details']['email']) . "</p>";
    if (isset($_SESSION['user_details']['admin_role'])) {
        echo "<p><strong>Admin Role:</strong> " . htmlspecialchars($_SESSION['user_details']['admin_role']) . "</p>";
    }
    if (isset($_SESSION['user_details']['contact'])) {
        echo "<p><strong>Contact:</strong> " . htmlspecialchars($_SESSION['user_details']['contact']) . "</p>";
    }
    if (isset($_SESSION['user_details']['status'])) {
        echo "<p><strong>Status:</strong> " . htmlspecialchars($_SESSION['user_details']['status']) . "</p>";
    }
    echo "</div>";
    unset($_SESSION['info_message']);
    unset($_SESSION['user_details']);
}

if (isset($_SESSION['error_message'])) {
    echo '<div style="color: red; font-weight: bold; margin-bottom: 1em;">' . htmlspecialchars($_SESSION['error_message']) . '</div>';
    unset($_SESSION['error_message']);
}

?>

