<?php
include 'session.php';
include 'db.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
require_once 'UserManager.php';

allowOnlyUserType('admin');
allowRole(['Super Admin']);
checkSessionTimeout();

$userManager = new UserManager($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $role = $_POST['role'] ?? null;
    $action = $_POST['action'] ?? null;

    if ($id && $role && in_array($action, ['approve', 'reject'])) {
        try {
            $success = $userManager->updateUserStatus($id, $role, $action);
            if ($success) {
                $roleName = ucfirst($role); // Capitalize first letter
                $statusMsg = ($action === 'approve') ? 'verified' : 'rejected';
                $_SESSION['message'] = "<p style='color:black;'>$roleName user $statusMsg successfully.</p>";
            } else {
                $_SESSION['message'] = "<p style='color:red;'>Failed to update user status.</p>";
            }
        } catch (Exception $e) {
            $_SESSION['message'] = "<p style='color:red;'>" . htmlspecialchars($e->getMessage()) . "</p>";
        }
    } else {
        $_SESSION['message'] = "<p style='color:red;'>Invalid form data.</p>";
    }

    header('Location: verify_users.php');
    exit();
}

// Fetch pending users
$users = $userManager->getPendingUsers();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="userstyle.css">
  <title>USER MANAGEMENT</title>

<style>
/* Apply gradient to the form box */
.form-box {
  background: linear-gradient(135deg, rgba(68, 175, 109, 0.1), rgba(200, 45, 211, 0.1));
  padding: 20px;
  border-radius: 8px;
  /*box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);*/
}

/* Buttons: Approve & Reject */
.approve-btn, .reject-btn {
  padding: 8px 14px;
  margin: 0 5px;
  background: linear-gradient(135deg, rgba(68, 175, 109, 0.8), rgba(200, 45, 211, 0.8));
  color: white;
  border: none;
  border-radius: 0;
  cursor: pointer;
  font-weight: bold;
  transition: background 0.3s ease;
}

.approve-btn:hover, .reject-btn:hover {
  background: linear-gradient(135deg, rgba(200, 45, 211, 0.9), rgba(68, 175, 109, 0.9));
}

/* Table enhancements */
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
  background: white;
  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.05);
  border-radius: 6px;
  overflow: hidden;
}

th {
  background: linear-gradient(135deg, rgba(68, 175, 109, 0.8), rgba(200, 45, 211, 0.8));
  color: white;
  padding: 12px;
}

td {
  background: #fafafa;
  padding: 12px;
}

tr:nth-child(even) td {
  background: #f0f0f0;
}
</style>

</head>
<body>

<div class="header">
    <img src="img/logoo.png" alt="School Logo" class="logo">
    <div class="system-title"><strong>User Management System</strong></div>
</div>

<div class="dashboard-container">
    <div class="hamburger" onclick="toggleSidebar()">☰</div>
    <aside class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="homepage.php">Home</a></li>
            <li><a href="user_management.php">Manage Users</a></li>
            <li><a href="dashboard.php">Courses</a></li>
            <li><a href="about.php">About Us</a></li>
        </ul>      
    </aside>

    <main class="main-content">
        <div class="form-box">
            <legend><strong>Approve Users</strong></legend>

<?php 
if (isset($_SESSION['message'])) {
    echo '<div class="message">' . $_SESSION['message'] . '</div>';
    unset($_SESSION['message']);
}
?>

<?php if (count($users) === 0): ?>
    <p style="text-align:center;">No users pending verification.</p>
<?php else: ?>
<table>
    <thead>
        <tr>
            <th>Username</th>
            <th>Role</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($users as $user): ?>
        <tr>
            <td><?= htmlspecialchars($user['user_name']) ?></td>
            <td><?= htmlspecialchars(ucfirst($user['role'])) ?></td>
            <td>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="id" value="<?= htmlspecialchars($user['id']) ?>">
                    <input type="hidden" name="role" value="<?= htmlspecialchars($user['role']) ?>">
                    <button type="submit" name="action" value="approve" class="approve-btn">Approve</button>
                </form>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="id" value="<?= htmlspecialchars($user['id']) ?>">
                    <input type="hidden" name="role" value="<?= htmlspecialchars($user['role']) ?>">
                    <button type="submit" name="action" value="reject" class="reject-btn">Reject</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>

<br>
            <a href="user_management.php"><button>Go Back</button></a>
        </div>
    </main>
</div>

</body>
</html>
