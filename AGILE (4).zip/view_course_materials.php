<?php
require 'authentication_middleware.php';
require 'authorization_middleware.php';

allowOnlyUserType('teacher'); // Only teachers can access

require_once 'db.php';

$teacher = null;
$teacher_id = $_SESSION['user_id'] ?? null;
$course_code = $_GET['course_code'] ?? null;

// Validate inputs
if (!$teacher_id) {
    echo "Unauthorized access. Please log in.";
    exit;
}

//if (!$course_code) {
  //  echo "No course selected.";
    //exit;
//}

// Get course name for heading (optional)
$courseStmt = $pdo->prepare("SELECT name FROM course WHERE code = ? AND teacher_id = ?");
$courseStmt->execute([$course_code, $teacher_id]);
$course = $courseStmt->fetch();

if (!$course) {
    echo "Course not found or not assigned to you.";
    exit;
}

// Fetch materials for this course
$stmt = $pdo->prepare("SELECT file_name, file_path, uploaded_at, code FROM course_materials WHERE code = ?");
$stmt->execute([$course_code]);
$materials = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>

<head>
    <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="edit_teacher.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
   <link rel="icon" href="img/logoo.png" type="image/webp">
   <script src="Navigation.js" defer></script>
   <title>Materials for <?= htmlspecialchars($course['name']) ?></title>
<style>  
.materials-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 20px;
    padding: 30px;
    max-width: 1200px;
    margin: 0 auto;
}

.material-card {
    background-color: rgba(255, 255, 255, 0.9);
    color: #333;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    text-align: left;
}

.material-card h3 {
    font-size: 18px;
    margin-bottom: 10px;
    color: #2c3e50;
}

.material-card p {
    font-size: 14px;
    margin-bottom: 8px;
}

.download-btn {
    display: inline-block;
    padding: 8px 14px;
    background-color: #2980b9;
    color: white;
    text-decoration: none;
    border-radius: 6px;
    font-size: 14px;
    transition: background-color 0.3s ease;
}

.download-btn:hover {
    background-color: #3498db;
}

.no-materials {
    text-align: center;
    font-size: 18px;
    color: #fff;
    margin-top: 40px;
}

.page-title {
    text-align: center;
    margin-top: 40px;
    color: white;
    font-size: 32px;
}



</style>

</head>
<body>
<nav>
  <img src="img/logoo.png" alt="Logo" class="logo">
  <div class="nav-links" id="navLinks">
    <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i>
    <ul>
      <li><a href="homepage.php">HOME</a></li>
      <li><a href="dashboard.php">COURSE</a></li>
      <li><a href="staff.php">STAFF</a></li>
      <li><a href="login.php">LOG IN</a></li>
    </ul>
  </div>
  <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i>
</nav>
    <h2 class="page-title">Materials for: <?= htmlspecialchars($course['name']) ?> (<?= htmlspecialchars($course_code) ?>)</h2>

    <?php if (!empty($materials)): ?>
        <div class="materials-container">
  
    <?php foreach ($materials as $material): ?>
      <div class="material-card">
        <h3><?= htmlspecialchars($material['file_name']) ?></h3>
        <p>Course Code: <strong><?= htmlspecialchars($material['code']) ?></strong></p>
        
        <a href="<?= htmlspecialchars($material['file_path']) ?>" class="download-btn" target="_blank">📥 View/Download</a>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <p class="no-materials">No course materials found for this course.</p>
  <?php endif; ?>
</div>


    <p><a class="back-btn"href="view_teacher_classes.php">← Back to My Courses</a></p>



<script>
  var navLinks = document.getElementById("navLinks");
  function openMenu() {
    navLinks.style.right = "0";
  }
  function closeMenu() {
    navLinks.style.right = "-200px";
  }
</script>
</body>
</html>

