<?php
require 'authentication_middleware.php';
require 'authorization_middleware.php';

allowOnlyUserType('teacher'); // Only teachers can access

require_once 'db.php';

$teacher = null;
$teacher_id = $_SESSION['user_id'] ?? null;

if ($teacher_id) {
  $stmt = $pdo->prepare("SELECT teacher_id, name, email, qualification, code, admin_id FROM teacher WHERE teacher_id = ?");
  $stmt->execute([$teacher_id]);
  $teacher = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
  // If session is not valid or user is not a teacher, redirect or show error
  header("Location: login.php");
  exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Profile</title>
  <link rel="stylesheet" href="edit_teacher.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<style>
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  .header{
    min-height:100vh;
    width: 100%;
    background-image: linear-gradient(rgba(200, 45, 211, 0.7),rgba(68, 175, 109, 0.7) ), url("img/build.jpg"); 
    background-position:center;
    background-size: cover;
    position: relative;
  }

  body {
    font-family: Arial, sans-serif;
    background-image: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7)), url("img/build.jpg");
    background-size: cover;
    background-position: center;
    min-height: 100vh;
    color: white;
  }

  nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;
    
  }

  nav img {
    width: 100px;
    height: auto;
  }

  .nav-links {
    text-align: right;
  }

  .nav-links ul {
    list-style: none;
  }

  .nav-links ul li {
    display: inline-block;
    padding: 8px 12px;
    position: relative;
  }

  .nav-links ul li a {
    color: #f3f3f3;
    text-decoration: none;
    font-size: 23px;
  }

  .nav-links ul li::after {
    content: '';
    width: 0%;
    height: 2px;
    background: #540026;
    display: block;
    margin: auto;
    transition: 0.5s;
  }

  .nav-links ul li:hover::after {
    width: 100%;
  }

  footer {
    background-color: #0c5130;
    padding: 20px;
    text-align: center;
    color: white;
    margin-top: 40px;
  }

  .contact-container {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 30px;
  }

  .contact-details {
    font-size: 16px;
    color: #eee;
  }

  @media (max-width: 768px) {
    .nav-links ul li {
      display: block;
    }

    nav .fas {
      display: block;
      color: #fff;
      font-size: 22px;
      cursor: pointer;
    }

    .nav-links {
      position: absolute;
      background: rgba(195, 255, 177, 0.8);
      height: 100vh;
      width: 200px;
      top: 0;
      right: -200px;
      z-index: 100;
      transition: 1s;
    }

    .nav-links ul {
      padding: 30px;
    }
  }
h2 {
  color: #2c3e50;
  margin-bottom: 30px;
}

#profile {
  background-color: #fff;
  padding: 25px 40px;
  border-radius: 10px;
  box-shadow: 0 0 12px rgba(0, 0, 0, 0.1);
  max-width: 600px;
  margin: 0 auto 40px; /* Center and space below */
  text-align: left;
}

#profile p {
  font-size: 18px;
  margin: 12px 0;
}

#profile strong {
  color: #2c3e50;
  width: 150px;
  display: inline-block;
}

span {
  color: #2980b9;
}

    /* Styling for buttons */

    .buttons-container {
      display: flex;
      justify-content: center;
      gap: 20px;
      flex-wrap: wrap;
      margin-top: 20px; /* Add space between profile and buttons */
    }

    button {
      background-color: #2980b9; /* Button background color */
      color: white; /* Text color */
      font-size: 16px;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      margin: 10px;
      transition: background-color 0.3s ease, transform 0.3s ease;
      
    }

    button:hover {
      background-color: #3498db; /* Hover background color */
      transform: translateY(-2px); /* Slight upward movement on hover */
    }

    button:active {
      background-color: #1abc9c; /* Color when button is clicked */
      transform: translateY(1px); /* Pressed effect */
    }

    button a {
      color: white; /* Set link text color to white */
      text-decoration: none; /* Remove underline */
    }

    button a:hover {
      text-decoration: underline; /* Add underline on hover */
    }

  </style>
</head>
<body>
<nav>
  <img src="img/logoo.png" alt="Logo" class="logo">
  <div class="nav-links" id="navLinks">
    <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i>
    <ul>
      <li><a href="homepage.php">HOME</a></li>
      <li><a href="teacher_profile.php">COURSE</a></li>
      <li><a href="staff.php">STAFF</a></li>
      <li><a href="login.php">LOG IN</a></li>
    </ul>
  </div>
  <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i>
</nav>


  <h2>My Profile</h2>
  <div id="profile">
    <p><strong>Name:</strong> <span><?= htmlspecialchars($teacher['name']) ?></span></p>
    <p><strong>Email:</strong> <span><?= htmlspecialchars($teacher['email']) ?></span></p>
    <p><strong>Qualification:</strong> <span><?= htmlspecialchars($teacher['qualification']) ?></span></p>
    <p><strong>Course ID:</strong> <span><?= htmlspecialchars($teacher['code']) ?></span></p>
    <p><strong>Assigned Admin:</strong> <span><?= htmlspecialchars($teacher['admin_id']) ?></span></p>
  </div>


<a class="back-btn" href="view_teacher_dashboard.php" >← Go Back</a>
  </div>

<script>
  var navLinks = document.getElementById("navLinks");
  function openMenu() {
    navLinks.style.right = "0";
  }
  function closeMenu() {
    navLinks.style.right = "-200px";
  }
</script>

</body>
</html>
