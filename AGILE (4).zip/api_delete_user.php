<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

// api_delete_user.php
header('Content-Type: application/json');

try {
    $pdo = new PDO('mysql:host=localhost;dbname=student_record_system;charset=utf8mb4', 'root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'DB connection failed: ' . $e->getMessage()]);
    exit;
}

require 'UserManager.php';
require 'functions.php';

try {
    $userManager = new UserManager($pdo);

    $role = $_POST['role'] ?? '';
    $id = $_POST['id'] ?? '';

    if (empty($role) || empty($id)) {
        echo json_encode(['success' => false, 'message' => 'Missing role or id parameter.']);
        exit;
    }

    $result = $userManager->deleteUser($role, $id);

    if (isset($result['success'])) {
        echo json_encode(['success' => true, 'message' => $result['success']]);
    } elseif (isset($result['error'])) {
        echo json_encode(['success' => false, 'message' => $result['error']]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Unknown error occurred.']);
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>