<?php
include 'session.php';
include 'db.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin','Department Admin','Course Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();

$type = $_GET['type'] ?? '';
$is_active = isset($_GET['is_active']) ? $_GET['is_active'] : '';

$courses = [];
$filterSubmitted = isset($_GET['type']) || isset($_GET['is_active']);
$filterEmpty = $filterSubmitted && $type === '' && $is_active === '';

if (!$filterEmpty && ($type !== '' || $is_active !== '')) {
    $query = "SELECT * FROM course WHERE 1=1";
    $params = [];

    if ($type !== '') {
        $query .= " AND type = :type";
        $params[':type'] = $type;
    }

    if ($is_active !== '') {
        $query .= " AND is_active = :is_active";
        $params[':is_active'] = $is_active === '1' ? 1 : 0;
    }

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Filter Course</title>
   <link rel="stylesheet" href="homepage.css">
   <link href="img/logoo.png" rel="icon" type="image/webp">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
   <script src="Navigation.js" defer></script>
   <style>
        .filter-form {
            text-align: center;
            margin-top: 30x;
        }
        select, button {
            padding: 10px;
            margin: 0 10px;
            font-size: 1rem;
            border-radius: 5px;
            
        }
        label{
            font-size:1.5rem;
        }

button:hover {
    background-color: #0056b3;
}

/* Link next to button */
.reset-link {
    margin-left: 10px;
    color: #f3f3f3;
    text-decoration: none;
    font-size: 1.5rem;
}

.reset-link:hover {
    text-decoration: underline;
}

.grid-container {
    display: grid;
    grid-template-columns: repeat(3, 1fr); /* Always 3 per row */
    gap: 30px;
    justify-content: center;
    padding: 20px;
    max-width: 900px; /* To center the layout */
    margin: 0 auto;
}


.course-card {
    background: #f9f9f9;
    border-radius: 10px;
    padding: 16px;
    max-width: 240px;         /* controls box width */
    min-height: 320px;        /* controls box height */
    box-shadow: 0 6px 12px rgba(0, 123, 255, 0.3);  /* add highlight with blue glow */
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}


.course-card:hover {
    transform: translateY(-5px) scale(1.02);
    box-shadow: 0 12px 24px rgba(0, 123, 255, 0.4); /* brighter blue */
}


.course-card h2 {
    font-size: 1.4rem;
    color: #003366;
    margin-bottom: 12px;
    text-align: center;
}

.course-card .detail {
    text-decoration: none;
    color: #003366;
    font-size: 1.2rem;
    font-weight: bold;
    display: block;
    word-wrap: break-word;
}

.course-card .detail strong {
    display: inline-block;
    min-width: 90px;
    font-weight: 600;
    color: #000;
}

.course-card img {
    width: 100%;
    height: auto;
    border-radius: 12px;
    margin-bottom: 12px;
    object-fit: cover;
    max-height: 180px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}


.detail {
    margin: 4px 0;           /* Reduce vertical spacing */
    font-size: 0.95rem;      /* Slightly smaller font */
    padding: 2px 0;          /* Less internal padding */
    line-height: 1.3;        /* Tighter line spacing */
}


.detail strong {
    display: inline-block;
    min-width: 50px;
    color: #333;
}
.detail img {
    border-radius: 12px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    max-width: 100%;
    height: auto;
}
.back-link {
    display: inline-block;
    margin: 10px 0;
    padding: 10px 20px;
    text-align:center;
    color:white;
    background: #007bff; 
    text-decoration: none;
    border-radius: 5px;
    width:150px;
}

.back-link:hover {
    text-decoration: underline;
}
/* Responsive styles */
@media (min-width: 768px) {
    .container {
        max-width: 700px;
        
    }

    .detail {
        font-size: 1.1rem;
    }

    h2 {
        font-size: 2rem;
    }
}


.course-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
}

.course-card a {
    text-decoration: none;
    color: #003366;
    font-size: 1.2rem;
    font-weight: bold;
    display: block;
    word-wrap: break-word;
}

.course-card a:hover {
    color: #0055cc;
}

/* Responsive layout for extra flexibility */
.grid-container {
    display: grid;
    grid-template-columns: 1fr;
    gap: 20px;
    padding: 10px;
}
.back-btn {
  display: inline-block;
  padding: 12px 24px;
  background: blue;
  color: white;
  text-decoration: none;
  font-weight: bold;
  border-radius: 6px;
  transition: background 0.3s ease, transform 0.2s ease;
  box-shadow: 0 6px 15px rgba(68, 175, 109, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.back-btn:hover {
  background: blue;
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(68, 175, 109, 0.7);
}


/* Medium screens: 2 columns */
@media (min-width: 600px) {
    .grid-container {
        grid-template-columns: repeat(2, 1fr);
    }

    form {
            justify-content: center;
}
    }


/* Large screens: 3 columns */
@media (min-width: 900px) {
    .grid-container {
        grid-template-columns: repeat(3, 1fr);
    }
}

/* Mobile tweaks */
@media (max-width: 480px) {
    h1, h2 {
        font-size: 1.8rem;
    }

    form {
        flex-direction: column;
        align-items: stretch;
        text-align: center;
    }

    input[type="text"],
    select,
    button {
        width: 100%;
        margin: 5px 0;
    }
}

       
       .message {
           text-align: center;
           font-size: 1.5rem;
           padding: 10px;
           margin: 10px auto;
           width: fit-content;
           border-radius: 8px;
       }

       .message.success {
           background-color: #d4edda;
           color: #155724;
           border: 1px solid #c3e6cb;
       }

       .message.error {
           background-color: #f8d7da;
           color: #721c24;
           border: 1px solid #f5c6cb;
       }
   </style>
</head>
<body>
   <section class="header">  
    <nav>
      <img src="img/logoo.png" alt="Logo" class="logo">
      <div class="nav-links" id="navLinks">
         <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i>
         <ul>
            <li><a href="homepage.php">HOME</a></li>
            <li><a href="courses.php">COURSE</a></li>
            <li><a href="staff.php">STAFF</a></li>
            <li><a href="login.php">LOG IN</a></li>
         </ul>
      </div>
      <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i>
    </nav>

    <h1 style="text-align:center; font-size:5rem;">Filter Courses</h1><br><br>

    <?php
    if (isset($_SESSION['message'])) {
        $type = $_SESSION['message_type'] === 'success' ? 'success' : 'error';
        echo "<div class='message $type'>{$_SESSION['message']}</div>";
        unset($_SESSION['message'], $_SESSION['message_type']);
    }

    // Custom message if no filter is selected
    if ($filterEmpty) {
        echo "<div class='message error'>Please select at least one filter.</div>";
    }
    ?>

    <div class="filter-form">
        <form method="GET">
            <label>Type:</label>
            <select name="type">
                <option value="">All</option>
                <option value="theoretical" <?= $type === 'theoretical' ? 'selected' : '' ?>>Theoretical</option>
                <option value="practical" <?= $type === 'practical' ? 'selected' : '' ?>>Practical</option>
            </select>

            <label>Status:</label>
            <select name="is_active">
                <option value="">All</option>
                <option value="1" <?= $is_active === '1' ? 'selected' : '' ?>>Active</option>
                <option value="0" <?= $is_active === '0' ? 'selected' : '' ?>>Inactive</option>
            </select>

            <button type="submit">Filter</button>
             <button type="button" class="reset-btn" onclick="window.location.href='<?= $_SERVER['PHP_SELF'] ?>'">Reset</button>

        </form><br>
    </div>

    <div class="course-grid">
        <?php if (!empty($courses)): ?>
            <div class="grid-container">
                <?php foreach ($courses as $course): ?>
                    <div class="course-card container">
                        <h2><?= htmlspecialchars($course['name']) ?></h2>
                        <div class="detail">
                            <?php if (!empty($course['image']) && file_exists($course['image'])): ?>
                                <img src="<?= htmlspecialchars($course['image']) ?>" alt="Course Image" style="width:100%; height:auto; border-radius:12px; margin:auto;">
                            <?php endif; ?>
                        </div>
                        <div class="detail"><strong>Code:</strong> <?= htmlspecialchars($course['code']) ?></div>
                        <div class="detail"><strong>Description:</strong> <?= htmlspecialchars($course['description']) ?></div>
                        <div class="detail"><strong>Type:</strong> <?= htmlspecialchars($course['type']) ?></div>
                        <div class="detail"><strong>Credits:</strong> <?= htmlspecialchars($course['credits']) ?></div>
                        <div class="detail"><strong>Admin ID:</strong> <?= htmlspecialchars($course['admin_id']) ?></div>
                        <div class="detail"><strong>Teacher ID:</strong> <?= htmlspecialchars($course['teacher_id']) ?></div>
                        <div class="detail"><strong>Active:</strong> <?= $course['is_active'] ? 'Yes' : 'No' ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php elseif ($filterSubmitted && !$filterEmpty): ?>
            <p style="text-align:center; font-size: 2.5rem;">No courses found for the selected filter.</p>
        <?php endif; ?>
    </div>

    <div style="display: flex; justify-content:center">
        <a href="course_dashboard.php" class="back-btn"> Back</a>
    </div>
</section>

<script>
   var navLinks = document.getElementById("navLinks");
   function openMenu() {
       navLinks.style.right = "0";
   }
   function closeMenu() {
       navLinks.style.right = "-200px";
   }
</script>
</body>
</html>
