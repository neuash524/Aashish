<?php
include 'session.php';
include 'db.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin','Department Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['delete'])) {
    $code = $_POST['code'];

    // Prepare the delete statement
    $stmt = $pdo->prepare("DELETE FROM course WHERE code = ?");
    $stmt->execute([$code]);

    if ($stmt->rowCount() > 0) {
        $_SESSION['message'] = "<p style='color:green;'>Course '$code' has been deleted successfully.</p>";
    } else {
        $_SESSION['message'] = "<p style='color:red;'>Course '$code' does not exist or was already deleted.</p>";
    }

    header("Location: delete_course.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Delete Course</title>
   <link rel="stylesheet" href="homepage.css">
   <link href="img/logoo.png" rel="icon" type="image/webp">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
   <style>
        .container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }
        h2 {
            text-align: center;
            color: #d9534f;
        }
        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .delete-btn, .back-btn {
            display: inline-block;
            padding: 12px 24px;
            color: white;
            font-weight: bold;
            border-radius: 6px;
            transition: background 0.3s ease, transform 0.2s ease;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
            border: none;
            cursor: pointer;
        }
        .delete-btn {
            background: red;
        }
        .delete-btn:hover {
            background: darkred;
            transform: translateY(-2px);
        }
        .back-btn {
            background: blue;
            text-decoration: none;
            text-align: center;
        }
        .back-btn:hover {
            background: darkblue;
            transform: translateY(-2px);
        }
        .message {
            text-align: center;
            margin-bottom: 15px;
        }
        /* Modal styling */
        #confirmationModal {
            display: none;
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background-color: rgba(0,0,0,0.6);
            z-index: 999;
            justify-content: center;
            align-items: center;
        }
        #confirmationModal .modal-content {
            background: white;
            padding: 30px;
            border-radius: 10px;
            max-width: 400px;
            text-align: center;
        }
    </style>
</head>
<body>
<section class="header">  
    <nav>
        <img src="img/logoo.png" alt="Logo" class="logo">
        <div class="nav-links" id="navLinks">
            <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i>
            <ul>
                <li><a href="homepage.php">HOME</a></li>
                <li><a href="courses.php">COURSE</a></li>
                <li><a href="staff.php">STAFF</a></li>
                <li><a href="login.php">LOG IN</a></li>
            </ul>
        </div>
        <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i>
    </nav>

    <div class="container">
        <h2>Delete Course</h2>

        <?php
        if (isset($_SESSION['message'])) {
            echo '<div class="message">' . $_SESSION['message'] . '</div>';
            unset($_SESSION['message']);
        }
        ?>

        <form id="deleteForm">
            Code: <input name="code" id="courseCode" required><br><br>
            <button class="delete-btn" type="button" onclick="firstConfirmation()">Delete Course</button>
        </form><br>

        <div style="display: flex; justify-content:center">
            <a href="course_dashboard.php" class="back-btn">Back</a>
        </div>
    </div>
</section>

<!-- Modal for Final Confirmation -->
<div id="confirmationModal">
    <div class="modal-content">
         <h3>Confirm Deletion</h3></strong><br>Do you really want to delete this course?</p>
        <form method="POST">
            <input type="hidden" name="code" id="finalCode">
            <button type="submit" name="delete" class="delete-btn" style="margin-right: 10px;">Yes, Delete</button>
            <button type="button" onclick="closeModal()" class="back-btn">Cancel</button>
        </form>
    </div>
</div>

<script>
    function firstConfirmation() {
        const code = document.getElementById("courseCode").value.trim();
        if (!code) {
            alert("Please enter a course code.");
            return;
        }

        const proceed = confirm("Are you sure you want to initiate the deletion?");
        if (proceed) {
            document.getElementById("finalCode").value = code;
            document.getElementById("confirmationModal").style.display = "flex";
        }
    }

    function closeModal() {
        document.getElementById("confirmationModal").style.display = "none";
    }

    // Mobile menu toggle
    function openMenu() {
        document.getElementById("navLinks").style.right = "0";
    }

    function closeMenu() {
        document.getElementById("navLinks").style.right = "-200px";
    }
</script>
</body>
</html>
