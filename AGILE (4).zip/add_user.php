<?php
session_start();
require 'db.php';
require_once 'UserManager.php';
require 'functions.php';
require 'authentication_middleware.php';
require 'authorization_middleware.php';
require_once 'session_timeout_middleware.php';
allowOnlyUserType('admin');
allowRole(['Super Admin']);
// Use default timeout of 900 seconds (15 mins)
checkSessionTimeout();


// Database credentials - replace with your actual credentials
$host = 'localhost';
$dbname = 'student_record_system';
$dbuser = 'root';
$dbpass = '';


// Success message and credentials to display
$success_message = '';
$username = '';
$password = '';
$show_popup = false;
$popup_message = '';
$popup_options = []; 

if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST['action'] ?? '') === 'add') {
    try {
        $userManager = new UserManager($pdo);
        $result = $userManager->addUser($_POST, $_FILES);

        if ($result['popup']) {
            // show popup using your existing HTML block logic
            $popup_message = $result['popup']['message'];
            $popup_options = [
                'a' => "<a href='" . $result['popup']['links']['update'] . "'>a. Update existing user</a>",
                'b' => "<a href='" . $result['popup']['links']['cancel'] . "'>b. Cancel and return to form</a>",
            ];
            $show_popup = true;
            
        }

        $success_message = $result['message'];
        $username = $result['credentials']['username'] ?? '';
        $password = $result['credentials']['password'] ?? '';

    } catch (Exception $e) {
        $success_message = "Error: " . htmlspecialchars($e->getMessage());
    }
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="userstyle.css"> <!-- Link to the user CSS -->
<title>User Management System</title>
</head>
<body>

<div class="header">
    <img src="img/logoo.png" alt="School Logo" class="logo" />
    <div class="system-title">User Management System</div>
</div>

<div class="dashboard-container">
    <div class="hamburger" onclick="toggleSidebar()">☰</div>

    <aside class="sidebar" id="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="homepage.php">Home</a></li>
            <li><a href="user_management.php">Manage Users</a></li>
            <li><a href="course.php">Courses</a></li>
            <li><a href="about.php">About Us</a></li>
        </ul>
    </aside>

    <main class="main-content">

        <div class="form-container">
            <fieldset>
                <legend><strong>Add User</strong></legend>
                <form method="POST" action="" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="add" />

                    <label for="title">Title:</label>
                    <select id="title" name="title" required>
                        <option value="">Select Title</option>
                        <option value="Mr">Mr</option>
                        <option value="Mrs">Mrs</option>
                        <option value="Ms">Ms</option>
                    </select><br><br>

                    <label for="name">Full Name:</label>
                    <input type="text" id="name" name="name" required autocomplete="off" /><br><br>

                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required autocomplete="off" /><br><br>

                    <label for="add-role">As:</label>
                    <select id="add-role" name="role" onchange="toggleAddFields()" required>
                        <option value="">Select Role</option>
                        <option value="admin">Admin</option>
                        <option value="teacher">Teacher</option>
                        <option value="student">Student</option>
                    </select><br><br>

                    <!-- Admin Fields -->
                    <div id="add-admin-fields" class="role-section">
                        <label for="admin_role">Admin Role:</label>
                        <input type="text" id="admin_role" name="admin_role" autocomplete="off" /><br><br>

                        <label for="admin_contact">Contact:</label>
                        <input type="text" id="admin_contact" name="admin_contact" autocomplete="off" /><br><br>
                    </div>

                    <!-- Teacher Fields -->
                    <div id="add-teacher-fields" class="role-section">
                        <label for="qualification">Qualification:</label>
                        <input type="text" id="qualification" name="qualification" autocomplete="off" /><br><br>

                        <!--<label for="code">Code:</label>
                        <input type="text" id="code" name="code" autocomplete="off" /><br><br>-->

                        <label for="photo">Photo (filename or upload):</label>
                        <input type="file" name="photo" id="photo" accept="image/*">

                        <label for="description">Description:</label>
                        <textarea name="description" id="description"></textarea>
                    </div>

                    <!-- Student Fields -->
                    <div id="add-student-fields" class="role-section">

                        <label for="class">Class:</label>
                        <input type="text" id="class" name="class" autocomplete="off" /><br><br>

                        <label>
                            <input type="checkbox" id="is_on_scholarship" name="is_on_scholarship" />
                            Is on Scholarship
                        </label>
                    </div>

                    <button type="submit">Add User</button>
                </form>
            </fieldset>
        </div><br><br>
        <a href="user_management.php"><button>Go Back</button></a>

        <?php if ($show_popup): ?>
            
<div id="emailPopup" class="popup-overlay" role="dialog" aria-modal="true" aria-labelledby="popupTitle" aria-describedby="popupDesc">
    <div class="popup-content">
        <h3 id="popupTitle"><?= $popup_message ?></h3>
        <p id="popupDesc">Choose an option:</p>
        <ul>
            <?php foreach ($popup_options as $option): ?>
                <li><?= $option ?></li>
            <?php endforeach; ?>
        </ul>
        <button onclick="closePopup()">Close</button>
    </div>
</div>
<?php endif; ?>


        <?php if ($success_message): ?>
            <div class="success-message" role="alert" aria-live="polite">
                <h3><?= htmlspecialchars($success_message) ?></h3>
                <?php if (strpos($success_message, 'successfully') !== false): ?>
                    <p><strong>Username:</strong> <?= htmlspecialchars($username) ?></p>
                    <p><strong>Temporary Password:</strong> <?= htmlspecialchars($password) ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php
        if (isset($_SESSION['error_message'])) {
    echo '<div style="color: red; font-weight: bold; margin-bottom: 1em;">' . htmlspecialchars($_SESSION['error_message']) . '</div>';
    unset($_SESSION['error_message']);
}
?>

    </main>
    
</div>


<script>
    function toggleAddFields() {
        const role = document.getElementById('add-role').value;
        document.getElementById('add-admin-fields').style.display = 'none';
        document.getElementById('add-teacher-fields').style.display = 'none';
        document.getElementById('add-student-fields').style.display = 'none';

        if (role === 'admin') {
            document.getElementById('add-admin-fields').style.display = 'block';
        } else if (role === 'teacher') {
            document.getElementById('add-teacher-fields').style.display = 'block';
        } else if (role === 'student') {
            document.getElementById('add-student-fields').style.display = 'block';
        }
    }
    window.addEventListener('DOMContentLoaded', toggleAddFields);

    // Sidebar toggle for mobiles
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        if (sidebar.style.transform === 'translateX(-220px)') {
            sidebar.style.transform = 'translateX(0)';
        } else {
            sidebar.style.transform = 'translateX(-220px)';
        }
    }

    function closePopup() {
    const popup = document.getElementById('emailPopup');
    if (popup) {
        popup.style.display = 'none';
    }
}

window.onload = function() {
    if (document.getElementById('emailPopup')) {
        document.querySelector('form').addEventListener('submit', function(e) {
            e.preventDefault(); // disable submit while popup is visible
        });
    }
};


</script>


</body>
</html>

