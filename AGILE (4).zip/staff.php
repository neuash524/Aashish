<?php include 'db.php';

$stmt = $pdo->query("SELECT * FROM teacher");
$teachers = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Teachers</title>
  <link rel="stylesheet" href="homepage.css"> <!-- Link to the homepage CSS -->
   <link href="img/logoo.png" rel="icon" type="image/webp"> <!-- Set favicon for the page -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome icons -->
   <script src="Navigation.js" defer></script> <!-- External JavaScript for navigation -->
  <style>
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  body {
    font-family: Arial, sans-serif;
    background-image: linear-gradient(rgba(200, 45, 211, 0.7), rgba(68, 175, 109, 0.7)), url("img/build.jpg");
    background-size: cover;
    background-position: center;
    min-height: 100vh;
    color: white;
    
  }

  nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0rem;
    
  }

  nav img {
    width: 150px;
    height: auto;
  }

  .nav-links {
    text-align: right;
  }

  .nav-links ul {
    list-style: none;
  }

  .nav-links ul li {
    display: inline-block;
    padding: 8px 12px;
    position: relative;
  }

  .nav-links ul li a {
    color: #f3f3f3;
    text-decoration: none;
    font-size: 23px;
  }

  .nav-links ul li::after {
    content: '';
    width: 0%;
    height: 2px;
    background: #540026;
    display: block;
    margin: auto;
    transition: 0.5s;
  }

  .nav-links ul li:hover::after {
    width: 100%;
  }

  footer {
    background-color: #0c5130;
    padding: 20px;
    text-align: center;
    color: white;
    margin-top: 40px;
  }

  .contact-container {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 30px;
  }

  .contact-details {
    font-size: 16px;
    color: #eee;
  }

  @media (max-width: 768px) {
    .nav-links ul li {
      display: block;
    }

    nav .fas {
      display: block;
      color: #fff;
      font-size: 22px;
      cursor: pointer;
    }

    .nav-links {
      position: absolute;
      background: rgba(195, 255, 177, 0.8);
      height: 100vh;
      width: 200px;
      top: 0;
      right: -200px;
      z-index: 100;
      transition: 1s;
    }

    .nav-links ul {
      padding: 30px;
    }
  }



    h2 {
      color: #333;
      text-align: center;
      margin-bottom: 40px;
    }

    .teacher-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 20px;
    }

    .teacher-card {
      background-color: #fff;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
      transition: transform 0.2s;
    }

    .teacher-card:hover {
      transform: translateY(-5px);
    }

    .teacher-photo {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }

    .teacher-info {
      padding: 15px;
    }

    .teacher-info h3 {
      margin: 0 0 10px;
      color: #007bff;
    }

    .teacher-info p {
      margin: 5px 0;
      color: #555;
    }
    .back-btn {
  display: inline-block;
  padding: 10px 20px;
  background-color: #540026;
  color: white;
  text-decoration: none;
  border-radius: 8px;
  margin: 20px;
  font-weight: bold;
  transition: background-color 0.3s ease;
}

.back-btn:hover {
  background-color: #6d0033;
}

  </style>
</head>
<body>
  
<nav>
  <img src="img/logoo.png" alt="Logo" class="logo">
  <div class="nav-links" id="navLinks">
    <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i>
    <ul>
      <li><a href="homepage.php">HOME</a></li>
      <li><a href="course.php">COURSE</a></li>
      <li><a href="staff.php">STAFF</a></li>
      <li><a href="login.php">LOG IN</a></li>
    </ul>
  </div>
  <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i>
</nav>

<h2>Our Esteemed Staffs</h2>

<div class="teacher-grid">
  <?php foreach ($teachers as $teacher): ?>
    <div class="teacher-card">
    <img src="<?= htmlspecialchars($teacher['photo']) ?>" alt="Photo of <?= htmlspecialchars($teacher['name']) ?>" width="150">
    <div class="teacher-info">
        <h3><?= htmlspecialchars($teacher['name']) ?></h3>
        <p><strong>Email:</strong> <a href="mailto:<?= htmlspecialchars($teacher['email']) ?><?= htmlspecialchars($admin['email']) ?>"style="color: #2980b9; text-decoration: underline;"></a></p>
        <p><strong>Qualification:</strong> <?= htmlspecialchars($teacher['qualification']) ?></p>
        <p><strong>Description:</strong> <?= htmlspecialchars($teacher['description']) ?></p>
        </div>
    </div>
  <?php endforeach; ?>
</div>

<div style="text-align: center; margin: 40px 0;">
  <a href="view_our_administrators.php" style="
      display: inline-block;
      padding: 12px 25px;
      background-color: #fff;
      color: #007bff;
      font-size: 18px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: bold;
      box-shadow: 0 4px 6px rgba(0,0,0,0.2);
      transition: background-color 0.3s ease;
    "
    onmouseover="this.style.backgroundColor='#f0f0f0'"
    onmouseout="this.style.backgroundColor='#fff'">
    👨‍💼 Our Administration
  </a>
</div>

<p><a href="homepage.php" class="back-btn">← Back to Home Page</a></p>



<footer>
  <section class="about-contact">
    <h2>Contact Us</h2>
    <div class="contact-container">
      <div class="contact-details">
        <p>📍 Sankt Petri Passage 10, 1165 København, Denmark</p>
        <p>📧 Email: contact@greenfieldschool.com</p>
        <p>📞 Phone: +45 123 5678</p>
      </div>
    </div>
  </section>
</footer>

<script>
  var navLinks = document.getElementById("navLinks");
  function openMenu() {
    navLinks.style.right = "0";
  }
  function closeMenu() {
    navLinks.style.right = "-200px";
  }
</script>


</body>
</html>
