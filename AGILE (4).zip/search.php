<?php
include 'session.php';
include 'db.php';

// search.php
$search = $_GET['search'] ?? '';
$type = $_GET['type'] ?? '';
$is_active = isset($_GET['is_active']) ? $_GET['is_active'] : '';
$courses = [];

// Only run query if filters are applied (NOT on page reload)
$filtersApplied = $search !== '' || $type !== '' || $is_active === '0' || $is_active === '1';

if ($filtersApplied) {
    $query = "SELECT * FROM course WHERE 1";
    $params = [];

// Build query dynamically
if (!empty($search) || !empty($type) || $is_active === '0' || $is_active === '1') {
    $query = "SELECT * FROM course WHERE 1";
    $params = [];


    if (!empty($search)) {
    $query .= " AND (code LIKE :search_code OR name LIKE :search_name)";
    $params[':search_code'] = '%' . $search . '%';
    $params[':search_name'] = '%' . $search . '%';
}
   

if (!empty($type)) {
    $query .= " AND type = :type";
    $params[':type'] = $type;
   
}


    if ($is_active === '0' || $is_active === '1') {
        $query .= " AND is_active = :is_active";
        $params[':is_active'] = (int)$is_active;
       
    }

    // Prepare and execute query with bound parameters
    $stmt = $pdo->prepare($query);
    
    // Bind the parameters (PDO does this automatically when binding with named placeholders)
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }

    // Execute the query
    $stmt->execute();
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search/Filter Course</title> <!-- Display page title -->
    <link rel="stylesheet" href="homepage.css"> <!-- Link to the homepage CSS -->
    <link href="img/logoo.png" rel="icon" type="image/webp"> <!-- Set favicon for the page -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome icons -->
    <script src="Navigation.js" defer></script> <!-- External JavaScript for navigation -->
</head>
<body>
    <style>
/* Base styles for all screen sizes */
body {
    font-family: 'Segoe UI', sans-serif;
    background-color: #f4f4f9;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

h1{
    text-align: center;
    font-size: 2.5rem;
    margin-bottom: 20px;
     color: rgb(147, 212, 157);
}

/* Form styling */
.search-filter-form {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 10px;
    margin: 1rem;
}

.search-filter-form .form-row {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}


input[type="text"],
select {
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
    font-size: 1rem;
    width: 200px;
    max-width: 100%;
    align-items: center;
}

button {
    padding: 10px 16px;
    background-color: #007BFF;
    color: white;
    border: none;
    border-radius: 5px;
    font-size: 1rem;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}
.back-link {
    display: inline-block;
    margin: 10px 0;
    padding: 10px 20px;
    text-align:center;
    color:white;
    background: #007bff; 
    text-decoration: none;
    border-radius: 5px;
    width:150px;
}

.back-link:hover {
    text-decoration: underline;
}

/* Link next to button */
.reset-link {
    margin-left: 10px;
    color: #f3f3f3;
    text-decoration: none;
    font-size: 1.5rem;
}

.reset-link:hover {
    text-decoration: underline;
}
/* Grid for course cards */
.course-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(260px, 260px));
    gap: 20px;
    padding: 0 10px;
    margin: 0 auto;
    max-width: 1200px;
    justify-content: center;
}

/* Individual course card */
.course-card {
    background-color: #ffffff;
    border-radius: 12px;
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
    padding: 25px;
    text-align: center;
    transition: transform 0.2s, box-shadow 0.2s;
}

.course-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
}

.course-card a {
    text-decoration: none;
    color: #003366;
    font-size: 1.2rem;
    font-weight: bold;
    display: block;
    word-wrap: break-word;
}

.course-card a:hover {
    color: #0055cc;
}


/* Responsive layout for extra flexibility */
.grid-container {
    display: grid;
    grid-template-columns: 1fr;
    gap: 20px;
    padding: 10px;
}

/* Medium screens: 2 columns */
@media (min-width: 600px) {
    .grid-container {
        grid-template-columns: repeat(2, 1fr);
    }

    form {
            justify-content: center;
}
    }


/* Large screens: 3 columns */
@media (min-width: 900px) {
    .grid-container {
        grid-template-columns: repeat(3, 1fr);
    }
}


/* Mobile tweaks */
@media (max-width: 480px) {
    h1, h2 {
        font-size: 1.8rem;
    }

    form {
        flex-direction: column;
        align-items: stretch;
        text-align: center;
    }

    input[type="text"],
    select,
    button {
        width: 100%;
        margin: 5px 0;
    }

.reset-btn {
    background-color: #6c757d; /* A neutral gray */
    color: white;
    padding: 10px 16px;
    border: none;
    border-radius: 5px;
    font-size: 1rem;
    cursor: pointer;
}

.reset-btn:hover {
    background-color: #5a6268;
}

}
   
</style>
</head>
<body>

<section class="header">  
    <nav>
      <img src="img/logoo.png" alt="Logo" class="logo"> <!-- Display the university logo -->

  <div class="nav-links" id="navLinks">
     <i class="fas fa-times" id="menu-close" onclick="closeMenu()"></i> <!-- Close menu icon -->
     <ul>
        <li><a href="homepage.php">HOME</a></li> <!-- Home link -->
        <li><a href="courses.php">COURSE</a></li> <!-- Contact link -->
        <li><a href="staff.php">STAFF</a></li> <!-- About link -->
        <li><a href="login.php">LOG IN</a></li> <!-- Administrator link -->
     </ul>
  </div>
  <i class="fas fa-bars" id="menu-open" onclick="openMenu()"></i> <!-- Open menu icon -->
</nav>

<?php

if (isset($_SESSION['message'])) {
    echo $_SESSION['message'];
    unset($_SESSION['message']);
}
?>

<h1>Search Courses</h1>

<form method="GET" action="search_course.php" class="search-filter-form">
    <div class="form-row">
        <input type="text" name="search" placeholder="Search by code or name" value="<?= htmlspecialchars($search) ?>">
        <button type="submit">Search</button>
    </div>

    <div class="form-row">
        <label for="type">Type:</label>
        <select name="type" id="type">
            <option value="">All</option>
            <option value="theoretical" <?= $type === 'theoretical' ? 'selected' : '' ?>>Theoretical</option>
            <option value="practical" <?= $type === 'practical' ? 'selected' : '' ?>>Practical</option>
        </select>

        <label for="is_active">Active:</label>
        <select name="is_active" id="is_active">
            <option value="">All</option>
            <option value="1" <?= $is_active === '1' ? 'selected' : '' ?>>Active</option>
            <option value="0" <?= $is_active === '0' ? 'selected' : '' ?>>Inactive</option>
        </select>

        <button type="submit">Filter</button>
        <button type="button" class="reset-btn" onclick="window.location.href='<?= $_SERVER['PHP_SELF'] ?>'">Reset</button>
    </div>
</form>

<div class="course-grid">
    <?php if ($filtersApplied): ?>
    <?php if ($courses && count($courses) > 0): ?>
    <?php foreach ($courses as $row): ?>
        <div class="course-card">
            <?php if (!empty($row['image']) && file_exists($row['image'])): ?>
                <img src="<?= htmlspecialchars($row['image']) ?>" alt="Course Image" style="width:100%; height:150px; object-fit:cover; border-radius:8px; margin-bottom:10px;">
            <?php endif; ?>

            <a href="course_details.php?code=<?= urlencode($row['code']) ?>">
                <?= htmlspecialchars($row['code']) ?> - <?= htmlspecialchars($row['name']) ?>
            </a>

            <div>Type: <?= htmlspecialchars($row['type']) ?></div>
                <div>Active: <?= $row['is_active'] ? 'Yes' : 'No' ?></div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="text-align:center; color:white; font-size:2rem;">No courses found.</p>
    <?php endif; ?>
<?php endif; ?>
</div><br>
</div>
<a href="course_dashboard.php" class="back-link">← Back</a>
</section>

<script>
    var navLinks = document.getElementById("navLinks");
    function openMenu() {
        navLinks.style.right = "0"; // Open the menu by setting the style to right = 0
    }
    function closeMenu() {
        navLinks.style.right = "-200px"; // Close the menu by shifting it off-screen
    }
</script>
<script>
    // Detect if the page was reloaded
    if (performance.navigation.type === 1) {
        // Redirect to remove GET parameters after reload
        window.location.href = window.location.pathname;
    }
</script>

</body>
</html>
