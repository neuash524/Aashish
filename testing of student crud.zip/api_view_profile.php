<?php
require 'db_con.php';

$id = $_GET['id'] ?? '';

if ($id == '') {
    echo json_encode(["status" => "error", "message" => "ID is required"]);
    exit;
}

$sql = "SELECT * FROM student WHERE student_id = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    echo json_encode(["status" => "error", "message" => "Failed to prepare statement"]);
    exit;
}

$stmt->bind_param("s", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode(["status" => "success", "data" => $row]);
} else {
    echo json_encode(["status" => "error", "message" => "Student not found"]);
}

$stmt->close();
$conn->close();
