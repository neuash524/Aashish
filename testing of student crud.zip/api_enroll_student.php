<?php
require 'db_con.php';

$student_id = $_POST['student_id'] ?? '';
$course_code = $_POST['course_code'] ?? '';

if ($student_id == '' || $course_code == '') {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit;
}

// Optional: check if already enrolled
$check_sql = "SELECT * FROM enroll WHERE student_id = ? AND code = ?";
$check_stmt = $conn->prepare($check_sql);
$check_stmt->bind_param("ss", $student_id, $course_code);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows > 0) {
    echo json_encode(["status" => "error", "message" => "Already enrolled"]);
    exit;
}

$sql = "INSERT INTO enroll (student_id, code) VALUES (?, ?)";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Database error"]);
    exit;
}

$stmt->bind_param("ss", $student_id, $course_code);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Enrollment successful"]);
} else {
    echo json_encode(["status" => "error", "message" => "Enrollment failed"]);
}

$stmt->close();
$conn->close();
