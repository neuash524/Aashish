<?php
require 'db_con.php';

$id = $_POST['assignment_id'] ?? '';

if (!$id) {
    echo json_encode(["status" => "error", "message" => "Assignment ID required"]);
    exit;
}

$sql = "DELETE FROM assignments WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $id);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Assignment deleted"]);
} else {
    echo json_encode(["status" => "error", "message" => "Delete failed"]);
}
