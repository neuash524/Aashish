<?php
require 'db_con.php';

// Get POST data (adjust keys based on your front-end/test input)
$student_id = $_POST['student_id'] ?? '';
$file_name = $_POST['file_name'] ?? '';
$file_path = $_POST['file_path'] ?? '';     // You need to send this or generate it
$code = $_POST['code'] ?? '';               // Course code
$teacher_id = $_POST['teacher_id'] ?? '';   // Teacher id (must be provided)
$uploaded_at = date('Y-m-d H:i:s');

// Check required fields
if ($student_id == '' || $file_name == '' || $file_path == '' || $code == '' || $teacher_id == '') {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit;
}

// Prepare the INSERT statement
$sql = "INSERT INTO submitted_assignments (student_id, file_name, file_path, code, teacher_id, uploaded_at) 
        VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Failed to prepare statement"]);
    exit;
}

// Bind parameters
$stmt->bind_param("ssssss", $student_id, $file_name, $file_path, $code, $teacher_id, $uploaded_at);

// Execute and respond
if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Assignment submitted"]);
} else {
    echo json_encode(["status" => "error", "message" => "Submission failed"]);
}

$stmt->close();
$conn->close();
