<?php
header('Content-Type: application/json');

// Get input from POST request
$id    = $_POST['id'] ?? '';
$name  = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';

$errors = [];

// Validate ID
if (empty($id) || strlen($id) < 5) {
    $errors[] = "ID must be at least 5 characters long";
}

// Validate Name
if (empty($name)) {
    $errors[] = "Name is required";
}

// Validate Email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Invalid email format";
}

// Respond with validation result
if (!empty($errors)) {
    echo json_encode([
        "status" => "error",
        "errors" => $errors
    ]);
} else {
    echo json_encode([
        "status" => "success",
        "message" => "Validation passed"
    ]);
}
?>
