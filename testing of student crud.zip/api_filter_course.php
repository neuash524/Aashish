<?php
require 'db_con.php';

$type = $_GET['type'] ?? '';
$min_credits = isset($_GET['min_credits']) ? intval($_GET['min_credits']) : null;
$max_credits = isset($_GET['max_credits']) ? intval($_GET['max_credits']) : null;

$query = "SELECT code, name, type, credits, description FROM course WHERE is_active = 1";
$params = [];
$types = "";

if ($type !== '') {
    $query .= " AND type = ?";
    $params[] = $type;
    $types .= "s";
}

if ($min_credits !== null) {
    $query .= " AND credits >= ?";
    $params[] = $min_credits;
    $types .= "i";
}

if ($max_credits !== null) {
    $query .= " AND credits <= ?";
    $params[] = $max_credits;
    $types .= "i";
}

$stmt = $conn->prepare($query);

if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Failed to prepare statement"]);
    exit;
}

if (count($params) > 0) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();

$result = $stmt->get_result();

$courses = [];

while ($row = $result->fetch_assoc()) {
    $courses[] = $row;
}

if (count($courses) > 0) {
    echo json_encode(["status" => "success", "data" => $courses]);
} else {
    echo json_encode(["status" => "error", "message" => "No courses found"]);
}

$stmt->close();
$conn->close();
