<?php
require 'db_con.php';

$id = $_POST['student_id'] ?? '';
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';

if ($id == '' || $name == '' || $email == '') {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit;
}

$sql = "UPDATE student SET name = ?, email = ? WHERE student_id = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    echo json_encode(["status" => "error", "message" => "Failed to prepare statement"]);
    exit;
}

$stmt->bind_param("sss", $name, $email, $id);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Profile updated"]);
} else {
    echo json_encode(["status" => "error", "message" => "Update failed"]);
}

$stmt->close();
$conn->close();
