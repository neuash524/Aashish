<?php
require 'db_con.php';

$search_term = $_GET['search'] ?? '';

if ($search_term == '') {
    echo json_encode(["status" => "error", "message" => "Search term is required"]);
    exit;
}

$search_term = "%$search_term%";

$sql = "SELECT code, name, type, credits, description 
        FROM course 
        WHERE is_active = 1 AND (code LIKE ? OR name LIKE ?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Failed to prepare statement"]);
    exit;
}

$stmt->bind_param("ss", $search_term, $search_term);

$stmt->execute();

$result = $stmt->get_result();

$courses = [];

while ($row = $result->fetch_assoc()) {
    $courses[] = $row;
}

if (count($courses) > 0) {
    echo json_encode(["status" => "success", "data" => $courses]);
} else {
    echo json_encode(["status" => "error", "message" => "No courses found"]);
}

$stmt->close();
$conn->close();
