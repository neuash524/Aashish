<?php
date_default_timezone_set('UTC');

$base_url = "http://localhost/AGILE/"; // adjust to your project base path

function log_result($id, $op, $status, $message) {
    $log = "$id | $op | $status | $message | " . date("Y-m-d H:i:s") . "\n";
    file_put_contents("student_test_log.txt", $log, FILE_APPEND);
    echo $log;
}

function send_post($url, $data) {
    $opts = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ]
    ];
    $ctx = stream_context_create($opts);
    return file_get_contents($url, false, $ctx);
}

function send_get($url) {
    return file_get_contents($url);
}
//  1. Enroll Student
function test_enroll_student() {
    global $base_url;
    $data = [
        'student_id' => '40130',
        'course_code' => 'PV701'
    ];

    $res = send_post($base_url . "api_enroll_student.php", $data);

    if (strpos($res, 'success') !== false) {
        log_result('TC101', 'Enroll Student', 'PASS', 'Student enrolled');
    } else {
        log_result('TC101', 'Enroll Student', 'FAIL', $res);
    }
}


//  2. View Profile
function test_view_profile() {
    global $base_url;
    $student_id = '40130'; // example ID
    $res = send_get($base_url . "api_view_profile.php?id=" . urlencode($student_id));
    if (strpos($res, '40130') !== false || strpos($res, 'name') !== false) {
        log_result('TC102', 'View Profile', 'PASS', 'Profile loaded');
    } else {
        log_result('TC102', 'View Profile', 'FAIL', $res);
    }
}

//  3. Edit Profile
function test_edit_profile() {
    global $base_url;
    $data = [
        'student_id' => '40130', // Make sure this ID exists
        'name' => 'Nishan kc',
        'email' => 'nishan@gmail.com',
    ];
    $res = send_post($base_url . "api_edit_profile.php", $data);
    if (strpos($res, 'success') !== false) {
        log_result('TC103', 'Edit Profile', 'PASS', 'Profile updated');
    } else {
        log_result('TC103', 'Edit Profile', 'FAIL', $res);
    }
}


// 4. Submit Assignment Test
function test_submit_assignment() {
    global $base_url;

    $data = [
        'student_id' => '40130',
        'file_name' => 'assignment1.pdf',
        'file_path' => '/uploads/assignment1.pdf',   // You can simulate path
        'code' => 'PV701',
        'teacher_id' => '1010'
    ];

    $res = send_post($base_url . "api_submit_assignment.php", $data);

    if (strpos($res, 'success') !== false) {
        log_result('TC104', 'Submit Assignment', 'PASS', 'Assignment submitted');
    } else {
        log_result('TC104', 'Submit Assignment', 'FAIL', $res);
    }
}


//  5. Delete Assignment
function test_delete_assignment() {
    global $base_url;
    $data = [
        'assignment_id' => 'A001' // example ID
    ];
    $res = send_post($base_url . "api_delete_assignment.php", $data);
    if (strpos($res, 'success') !== false) {
        log_result('TC105', 'Delete Assignment', 'PASS', 'Assignment deleted');
    } else {
        log_result('TC105', 'Delete Assignment', 'FAIL', $res);
    }
}

// 6. Search Course
function test_search_course() {
    global $base_url;
    $search = "AM"; // search term example
    $res = file_get_contents($base_url . "api_search_course.php?search=" . urlencode($search));

    if (strpos($res, 'success') !== false) {
        log_result('TC106', 'Search Course', 'PASS', 'Courses found');
    } else {
        log_result('TC106', 'Search Course', 'FAIL', $res);
    }
}


// 7. Filter Course
function test_filter_course() {
    global $base_url;
    $params = http_build_query([
        'type' => 'theoretical',
        'min_credits' => 1,
        'max_credits' => 5,
    ]);
    $res = file_get_contents($base_url . "api_filter_course.php?" . $params);

    if (strpos($res, 'success') !== false) {
        log_result('TC107', 'Filter Course', 'PASS', 'Courses filtered');
    } else {
        log_result('TC107', 'Filter Course', 'FAIL', $res);
    }
}
// validate student input
function test_validation() {
    global $base_url;
    $data = [
        'student_id' => '40130',
        'name' => 'Nishan kc',
        'email' => 'nishan@gmail.com',
    ];
    $res = send_post($base_url . "api_validate_input.php", $data);
    if (strpos($res, 'error') !== false) {
        log_result('TC108', 'Validate Input', 'PASS', 'Validation correct');
    } else {
        log_result('TC108', 'Validate Input', 'FAIL', $res);
    }
}



// 🔄 Run All Student Tests
test_enroll_student();
test_view_profile();
test_edit_profile();
test_submit_assignment();
test_delete_assignment();
test_search_course();
test_filter_course();
test_validation();

?>
